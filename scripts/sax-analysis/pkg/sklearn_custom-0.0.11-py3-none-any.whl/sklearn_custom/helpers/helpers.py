import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
import random
from math import floor
import string
from functools import reduce
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer


def _add_new_cats(self):
    """
    adds new feature columns to pandas DataFrame or numpy array
    """
    # TODO: respect order in case of ordinal data with parameter 'ordered=True'
    if isinstance(self.X, pd.DataFrame):

        # get old order in each column
        # categories = {}    # list of categories per column
        # for key, value in self.X.iteritems():
        #     cats = value.values.categories.values.tolist()  # same order as in original, but new_cat on first place
        #     if value.values.ordered is False:
        #         cats= sorted(value.values.categories.values.tolist()) # same order as in original, but new_cat on first place
        #     cats.insert(0, self.fill_value)
        #     categories.update({key: cats})

        # add new row with value 'of parameter 'fill_value'
        new_row = pd.Series([self.fill_value] * self.X.shape[1], index=self.X.columns)
        self.X = self.X.append(new_row, ignore_index=True)
        self.X = self.X.apply(lambda x: pd.Categorical(x), axis=0)  # convert all columns to type 'category'

        # for key, value in self.X.iteritems():
        #     self.X[key] = pd.Categorical(self.X[key].values, categories=categories[key], ordered=True)

    else:
        self.X = pd.DataFrame(data=self.X, columns=['X_' + str(item) for item in range(0, self.X.shape[1])])
        new_row = pd.Series([self.fill_value] * self.X.shape[1], index=self.X.columns)
        self.X = self.X.append(new_row, ignore_index=True)
        # TODO: if ordered is False -> alphabetical order, but new_cat on first place
        self.X = self.X.apply(lambda x: pd.Categorical(x), axis=0)  # convert all columns to type 'category'

    return self


def _apply_new_cats(self, X):
    X = X.apply(lambda x: pd.Categorical(x), axis=0)  # convert all columns to type 'category'

    # check if there are new categorical values in X
    items_to_repace = {}
    for col in X:
        cats_actual = list(X[col].cat.categories)
        cats_learned = list(self.X[col].cat.categories)
        intersect = [value for value in cats_actual if value not in cats_learned]
        if len(intersect) != 0:
            items_to_repace.update({col: intersect})

    # if there are new categories, set them to fill_value
    if len(items_to_repace) != 0:
        for key, value in items_to_repace.items():
            vals = {key: self.fill_value for key in items_to_repace[key]}
            X[key].replace(to_replace=vals, inplace=True)
        X = X.apply(lambda x: pd.Categorical(x), axis=0)  # renew categories

    return X


def store_old_names(df):
    """
    stores original column names as dict {x0: name, x1: name2 ,...}
    :param df: original pandas DataFrame
    :return: dict with x0 to xN as key and original name as value
    """
    name_dict = {}
    keys = ['x' + str(i) for i in list(range(0, df.shape[1]))]
    values = df.columns.to_list()
    for i, keys in enumerate(keys):
        name_dict[keys] = values[i]
    return name_dict


def replace_xN_column_names(new_names, **kwargs):
    """
    replaces x0 to xN in column names after encoding with original column-name suffix (ex. x0_yes -> gender_yes)
    :param df: pandas DataFrame after applying OneHotRecoder
    :param kwargs: dict with key x0 to xN and feature = old column names of original df)
    :return: pandas DataFrame with columns renamed
    """
    names = kwargs['dict']
    cols = []
    for item in new_names:
        pos_ = item.find('_')
        key = item[0:pos_]
        rest = item[pos_:len(item)]
        value = names[key]
        item = value + rest
        cols.append(item)
    return cols


def build_classification_data(samples=100, num_features=None, fraction_num_features=None,
                              cat_features=None, fraction_cat_features=None,
                              random_na=(0, 0, 0), seed=1000):
    '''
    builds classification data with numerical and/or categorical features for sklearn_custom
    :param samples: number of observations as int
    :param num_features:  number of numerical features
    :param fraction_num_features: list of 3 floats as percentage with infos to n_informative, n_redundant and n_repeated
    :param seed: random seed as int
    :param cat_features: number of categorical (random) features (no correlation to target)
    :param fraction_cat_features: ...
    :param random_na: insert fraction of np.nan in num_features, cat_features and target. (0, 0, 0) =no missing values is default
    :return: pandas DataFrame

    exp.     X,y = build_classification_data(samples=20, num_features=10, fraction_num_features=[0.2, 0.3, 0.4],
                                    cat_features=4, fraction_cat_features=[2, 7, 3, 1],
                                    random_na=(0.2, 0.0, 0.05), seed=1000)
    '''

    store = []  # stores categorical and/or numerical DataFrame

    if num_features is not None:

        if fraction_num_features is None:
            fraction_num_features = [0.3, 0.2, 0.2]  # default values
        else:
            assert len(fraction_num_features) == 3, 'length of list have to be 3'
            assert all([isinstance(s, float) for s in fraction_num_features]), 'all 3 entries in list have to be floats'
            assert 0 <= sum(
                fraction_num_features) <= 1, 'sum have to be equal or less than 1 and equal or bigger than 0'

        X1, y = make_classification(n_samples=samples, n_features=num_features,
                                    n_informative=floor(fraction_num_features[0] * num_features),
                                    n_redundant=floor(fraction_num_features[1] * num_features),
                                    n_repeated=floor(fraction_num_features[2] * num_features),
                                    n_clusters_per_class=2, class_sep=0.5,
                                    random_state=seed, shuffle=False)

        # Numpy array to pandas DataFrame
        labels = [f"Feature_{ii + 1}" for ii in range(X1.shape[1])]
        X1 = pd.DataFrame(X1, columns=labels)
        y = pd.DataFrame(y, columns=["Target"])
        store.append(X1)

        if random_na[0] != 0:
            assert 0 <= random_na[0] <= 1
            assert isinstance(random_na[0], float)
            no_na = int(samples * num_features * random_na[0])

            random.seed(seed)
            available_positions = [(i, j) for j in range(0, num_features) for i in range(0, samples)]
            picked_values = random.sample(available_positions, k=no_na)

            for item in picked_values:
                X1.iloc[item[0], item[1]] = np.nan

    if cat_features is not None:

        assert isinstance(cat_features, int)
        assert 0 <= cat_features <= 24

        if fraction_cat_features is None:
            random.seed(seed)
            fraction_cat_features = [random.randint(1, 5) for i in range(0, cat_features)]  # default values
        else:
            assert len(fraction_cat_features) == cat_features, 'length of list have to same as number of cat_features'
            assert all([isinstance(s, int) for s in fraction_cat_features]), 'all entries have to be int'

        letters = list(string.ascii_uppercase)

        column_values = []
        random.seed(seed)
        for item in range(0, cat_features):
            groups = random.choices(letters, k=fraction_cat_features[item])
            column_values.append(random.choices(groups, k=samples))

        headers = letters[0:cat_features]
        dictionary = dict(zip(headers, column_values))
        X2 = pd.DataFrame(dictionary, dtype='category')
        store.append(X2)

        if num_features is None:  # only a y has to be produced!
            X0, y = make_classification(n_samples=samples, n_features=10, n_informative=5, n_redundant=2,
                                        n_repeated=1, n_clusters_per_class=2, class_sep=0.5, random_state=seed,
                                        shuffle=False)

        if random_na[1] != 0:
            assert 0 <= random_na[1] <= 1
            assert isinstance(random_na[1], float)
            no_na = int(samples * cat_features * random_na[1])

            random.seed(seed)
            available_positions = [(i, j) for j in range(0, cat_features) for i in range(0, samples)]
            picked_values = random.sample(available_positions, k=no_na)

            for item in picked_values:
                X2.iloc[item[0], item[1]] = np.nan

    def concat_df(df1, df2):
        return pd.concat([df1, df2], axis=1)

    if len(store) != 0:
        X = reduce(concat_df, store)
    else:
        X, y = None, None

    if random_na[2] != 0:
        assert 0 <= random_na[2] <= 1
        assert isinstance(random_na[2], float)
        no_na = int(samples * random_na[2])

        random.seed(seed)
        picked_values = random.sample(list(range(0, samples)), k=no_na)
        for item in picked_values:
            y.iloc[item, 0] = np.nan

    return X, y


# works for OneHotEncoder and VarianceThreshold and for those Encoders with no new additional columns
def _get_column_names(transformer, X):

    name = transformer.__class__.__name__

    if name == 'VarianceThreshold':
        cols = X.columns[transformer.variances_ > transformer.threshold].to_list()  # due reduced columns! (ACHTUNG fitted - transformer)
    elif name == 'OneHotEncoder':
        old_names = store_old_names(X)
        new_names = list(transformer.get_feature_names())
        cols = replace_xN_column_names(new_names, dict=old_names)
    else:
        cols = X.columns.to_list()
    return cols