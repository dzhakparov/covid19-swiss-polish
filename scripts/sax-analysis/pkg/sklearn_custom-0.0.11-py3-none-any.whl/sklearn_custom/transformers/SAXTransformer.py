from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd
from saxpy.paa import paa
from saxpy.sax import ts_to_string
from saxpy.alphabet import cuts_for_asize
import numpy as np
import math
from pandas.api.types import CategoricalDtype
import string
import scipy.stats as st
import re
import plotly.graph_objects as go
import os


class SAX_Transformer(BaseEstimator, TransformerMixin):
    """
    transforms columns with same beginning followed by '_' ('__') (exp. sax_1, sax_2, ...) to a string representation
    (exp.: aa, ab, ba, bb) of all same length
    """

    def __init__(self, n_letters=2, n_length=2, scaler='z_all', thresholds=None, split=None, cat_ordered=False):
        """

        :param n_letters: number of letters to transform a time-series
        :param n_length: length of letter sequence to transform a time-series
        :param scaler: one out of ['z_all', 'z_series' or None]
        :param thresholds: dictionary with name of column as key and its thresholds as values. if thresholds is
               not None but the name of a column to transform the scaler for this columns will be set automatically
               to None and the individual thresholds will be taken for this feature
        :param split:
        :param cat_ordered:
        """
        self.n_letters = n_letters
        self.n_length = n_length
        self.scaler = scaler
        self.thresholds = thresholds
        self.split = split  # categorical feature
        self.features = set()
        self.stats = {}
        self.cats = []
        self.transformed_data = []
        self.sax_coded_data = []
        self.final_data = None
        self.y = None
        self.X = None
        self.na_coerced = set()
        self.borders = {}
        self.cat_ordered = cat_ordered  # categorical feature (ordered = False or ordered = True)

    def fit(self, X, y=None):

        if y is not None:
            self.y = y
        self.X = X

        self._validate_input(X)

        self._get_features(X)

        self._get_all_sax_combinations(list(string.ascii_lowercase[0:self.n_letters]), self.n_length, self.cats)

        if self.scaler == 'z_all':
            for item in list(self.features):
                filter_col = [col for col in X if col.startswith(item)]  # extract specific columns to transform

                if self.split is not None:
                    filter_col.append(self.split)

                data = X[filter_col]

                # na.omit non numerical cells
                data = self._coerce_numerical(data, item)

                data = data.values
                mean = np.nanmean(data)
                sd = math.sqrt(np.nanvar(data))
                self.stats[f"{item}"] = {}
                self.stats[f"{item}"]['mean'] = mean
                self.stats[f"{item}"]['sd'] = sd

        if self.na_coerced:
            print(f"ATTENTION: 'nas' coerced in feature_groups: {self.na_coerced}")

        return self

    def transform(self, X, y=None):

        self.transformed_data = []
        self.sax_coded_data = []

        # normalize (z-transformation) data
        self._normalize_data(X)

        # apply sax-coding
        for data_normalized in self.transformed_data:
            self.sax_coded_data.append(
                data_normalized.apply(self._sax_transformation, args=(self.n_letters, self.n_length), axis=1))

        # concat list of series to one pandas DataFrame
        self.final_data = pd.concat(self.sax_coded_data, axis=1, keys=self.features)

        # convert columns to categorical with all possible combinations
        cat_type = CategoricalDtype(categories=self.cats, ordered=self.cat_ordered)
        self.final_data = self.final_data.astype(cat_type)

        if self.na_coerced:
            print(f"ATTENTION: 'nas' coerced in feature_groups: {self.na_coerced}")

        return self.final_data

    def get_borders(self):
        """
        get border between each pair of letters of each feature
        :return: a dictionary
        """
        if self.scaler != 'z_all':
            self.borders = 'None'
        else:
            for item in self.stats:
                if self.thresholds is None or item not in self.thresholds.keys():
                    self.borders[item] = self._calculate_borders(self.n_letters, mean=self.stats[item]['mean'],
                                                                 sd=self.stats[item]['sd'])
                else:
                    self.borders[item] = self._calculate_borders(self.n_letters, thresholds=self.thresholds, item=item)

        return self.borders

    @staticmethod
    def _calculate_borders(n_letters, **kwargs):
        if 'mean' in kwargs:
            th = 1/n_letters
            ptc = [i * th for i in range(n_letters)]
            del ptc[0]

            z_values = [st.norm.ppf(i) for i in ptc]

            borders = [(i * kwargs['sd']) + kwargs['mean'] for i in z_values]

        else:  # manually fixed threshold(s) for this item
            borders = kwargs['thresholds'][kwargs['item']]

        letters = list(string.ascii_lowercase[:n_letters])

        comb = []
        for i in range(n_letters - 1):
            comb.append(letters[i] + letters[i + 1])

        dictionary = dict(zip(comb, borders))
        return dictionary

    def _validate_input(self, X):
        assert self.n_letters > 0
        assert self.n_length > 0
        assert self.scaler in ['z_all', 'z_series', 'None']
        if self.split is not None:
            assert self.split in X.columns.to_list()
            assert X[self.split].dtype.name == 'category'
        if self.thresholds is not None:
            assert all([isinstance(i, list) for i in list(self.thresholds.values())])
            assert all([len(i) + 1 == self.n_letters for i in list(self.thresholds.values())])

    def _normalize_data(self, X):

        for item in list(self.features):
            filter_col = [col for col in X if col.startswith(item)]  # extract specific columns to transform
            data = X[filter_col]

            # na.omit non numerical cells
            data = self._coerce_numerical(data, item)

            if self.scaler == 'None' or self.scaler is None:
                data_normalized = data
            elif self.thresholds is not None and item in list(self.thresholds.keys()):
                data_normalized = data
            elif self.scaler == 'z_all':
                data_normalized = data.apply(self._z_transformation,
                                             mean=self.stats[item]['mean'],
                                             sd=self.stats[item]['sd'],
                                             axis=1)
            elif self.scaler == 'z_series':
                data_normalized = data.apply(self._z_transformation, axis=1)

            self.transformed_data.append(data_normalized)

    def _coerce_numerical(self, data, item):
        no_na = data.isna().sum().sum()
        data = data.apply(lambda s: pd.to_numeric(s, errors='coerce'))  # coerce to numeric
        no_na_after_coerce = data.isna().sum().sum()
        if no_na != no_na_after_coerce:
            self.na_coerced.add(item)
        return data

    def _get_features(self, X):
        """
        extracts feature names by clipping last occurrence of '_xy'
        :param X: pandas DataFrame
        :return: list of unique feature names
        """
        colnames = X.columns.to_list()
        for item in colnames:
            idx = item.rfind('_')  # TODO: extend to pattern '__' in column-name to prevent bad single '_'
            if idx != -1:
                self.features.add(item[:idx])

    @staticmethod
    def _z_transformation(x, mean=None, sd=None):
        val = x.dropna().values

        if len(val) >= 2:
            if mean is None:
                mean = val.mean()
                sd = val.std()

            val = pd.Series(list(np.array(
                [(xi - mean) / sd for xi in x if xi is not np.nan])))  # runtime warning...  -> division by ZERO

            val.index = x.index
            x = val
        return x

    # @staticmethod
    def _sax_transformation(self, x, n_letters, n_length):
        item = re.split('_', x.index[0])[0]
        val = x.dropna().values
        if len(val) >= 2:
            dat_paa = paa(val, n_length)

            if self.thresholds is None:
                res = ts_to_string(dat_paa, cuts_for_asize(n_letters))  # cuts from normal z-transformed distribution
            else:
                if item not in list(self.thresholds.keys()):
                    res = ts_to_string(dat_paa, cuts_for_asize(n_letters))  # cuts from normal z-transformed distribution
                else:
                    cuts = np.array([-np.inf] + [i for i in self.thresholds[item]])  # cuts from manual thresholds
                    res = ts_to_string(dat_paa, cuts)
        else:
            res = np.nan
        return res

    # https://www.geeksforgeeks.org/print-all-combinations-of-given-length/
    def _get_all_sax_combinations_rec(self, set, prefix, n, k, cats):

        if k == 0:
            cats.append(prefix)
            return

        for i in range(n):
            new_prefix = prefix + set[i]
            self._get_all_sax_combinations_rec(set, new_prefix, n, k - 1, cats)

    def _get_all_sax_combinations(self, set, k, cats):
        n = len(set)
        self._get_all_sax_combinations_rec(set, "", n, k, cats)

    def get_transformed_data(self):
        return self.final_data

    def survivalplot_sax_features(self, positive_group='survived', features=None, path=None):

        if path is not None:
            path = os.path.join(path, 'survivalcurve')
            if not os.path.isdir(path):
                os.mkdir(path)

        if self.y is None:
            raise Exception(f"There is no y! Provide y-values in fit method!")

        if isinstance(self.y, np.ndarray):
            y = pd.DataFrame({'target': self.y})
        else:
            y = self.y

        y_name = list(y.columns.values)[0]
        y = y.reset_index()
        x = self.final_data.reset_index()

        if positive_group not in y.values:
            raise Exception(f"'positive_group' has to be a value of y")

        data = pd.merge(x, y, on='index')

        if features is not None:

            cols_found = [col for col in data.columns if col in features]
            if cols_found:
                cols_found = cols_found + [y_name, 'index']
                data = data[cols_found]

        for item in [i for i in data.columns if i not in ['index', y_name]]:
            data_filtered = data[[item, y_name, 'index']]
            counted_subgroup = data_filtered.groupby([item, y_name]).count()
            counted_subgroup = counted_subgroup.replace(np.nan, 0)

            counted_subgroup['index'] = counted_subgroup['index'].astype(int)

            subtitle = ""
            df = counted_subgroup.reset_index(level=1)
            df = df.pivot(columns=y_name, values='index')
            dict_for_subtitle = df.to_dict(orient='index')

            header = list(dict_for_subtitle[list(dict_for_subtitle.keys())[0]].keys())
            subtitle = subtitle + '(' + '/'.join(header) + ") -> "
            for k, v in dict_for_subtitle.items():
                subtitle = subtitle + ''.join(f"<b>{k}: </b>")
                values = list(v.values())
                values = [str(i) for i in values]
                subtitle = subtitle + '/'.join(values) + "  "

            counted_subgroup['relative'] = counted_subgroup.groupby(level=0).apply(lambda x: x / float(x.sum()))

            survival_rate = counted_subgroup[counted_subgroup.index.get_level_values(y_name) == positive_group]
            survival_rate = survival_rate.sort_values('relative', ascending=False)

            fig = go.Figure()
            fig.add_trace(go.Scatter(x=survival_rate.index.get_level_values(item), y=survival_rate['relative'],
                                     mode='lines+markers',
                                     name='rate'))

            fig.update_layout(
                title={
                    'text': f"survivalcurve feature <b>'{item}'</b> <br> {subtitle}",
                    'font': {'size': 24}
                },
                template='plotly_white',
                yaxis=dict(range=[0, 1], title_text=f'{positive_group} [%]'),
            )

            fig.update_xaxes(title_text=f"sax-coding '{item}'")
            if path is None:
                return fig
            else:
                fig.write_html(f"{path}/sax_feature_{item}.html")

    def boxplot_sax_features(self, numeric_feature, features=None):
        pass
        # TODO: problem due numerical_feature which is not provided be Transformer (ColumnSelector)
        # TODO: merge by index numerical_feature and X_data first

