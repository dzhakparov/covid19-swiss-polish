import pandas as pd
from sklearn.base import TransformerMixin
from sklearn.compose import ColumnTransformer


class ColumnTransformer(ColumnTransformer, TransformerMixin):
    """
    wrapper for ColumnTransformer, which returns a pandas DataFrame and not a np.ndarray
    """
    def __init__(self, transformers, **kwargs):
        super().__init__(transformers, **kwargs)
        # super().__init__(transformers)

    def fit(self, X, y=None):
        super().fit(X, y)
        return self

    def transform(self, X):
        Xs = super().transform(X)
        return Xs

    def _hstack(self, Xs):
        if all([isinstance(item, pd.DataFrame) for item in Xs]):
            return pd.concat(Xs, axis=1)
        else:
            return super()._hstack(Xs)