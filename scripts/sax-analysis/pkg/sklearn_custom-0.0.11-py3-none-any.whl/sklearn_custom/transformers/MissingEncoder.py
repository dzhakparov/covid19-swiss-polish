from sklearn.base import BaseEstimator, TransformerMixin
from sklearn_custom.transformers.dfTransformer import TransformerDataFrame
import pandas as pd
from sklearn_custom.helpers.helpers import _get_column_names


class MissingEncoder(BaseEstimator, TransformerMixin):
    """
    MissingEncoder is a Wrapper for an other Encoder as OneHotEncoder or OrdinalEncoder. It solves the problem
    of categorical values only occuring in a test set of data. It creates a additional Feature 'MISSING' to each
    existing feature in train. All 'new' values in test will be encoded as MISSING. If a ZeroVariance (VarianceThreshold)
    is used in a pipe after this MissingEncoder, the new feature columns with only 0 in MISSING can be removed.
    """

    def __init__(self, transformer, fill_value='MISSING'):
        self.transformer = transformer
        self.fill_value = fill_value

    def fit(self, X, y=None):
        """
        adds an additional row to X (categorical columns) with value 'MISSING' and add this new category to the
        existing categories, so it can be used for transformation with an other Estimator
        :param X: train data as pandas DataFrame
        :param y: not supported, not needed
        :return: self with categories of all columns incl. newly build MISSING category for all columns
        """
        # add new row with value 'MISSING'
        new_row = pd.Series([self.fill_value] * X.shape[1], index=X.columns)
        self.X = X.append(new_row, ignore_index=True)
        self.X = self.X.apply(lambda x: pd.Categorical(x), axis=0)  # convert all columns to type 'category'

        self.transformer.fit(self.X)
        return self

    def transform(self, X, y=None):
        X = X.apply(lambda x: pd.Categorical(x), axis=0)  # convert all columns to type 'category'

        # check if there are new categorical values in X
        items_to_repace = {}
        for col in X:
            cats_actual = list(X[col].cat.categories)
            cats_learned = list(self.X[col].cat.categories)
            intersect = [value for value in cats_actual if value not in cats_learned]
            if len(intersect) != 0:
                items_to_repace.update({col: intersect})

        # if there are new categories, set them to fill_value (MISSING)
        if len(items_to_repace) != 0:
            for key, value in items_to_repace.items():
                vals = {key: self.fill_value for key in items_to_repace[key]}
                X[key].replace(to_replace=vals, inplace=True)
            X = X.apply(lambda x: pd.Categorical(x), axis=0)  # renew categories

        # TODO: replace missing values by fill_value!

        values = self.transformer.transform(X)
        idx = X.index
        cols = _get_column_names(self.transformer, X)  # take care of column names (pandas DataFrame)

        data_transformed = pd.DataFrame(data=values, index=idx, columns=cols)
        return data_transformed
