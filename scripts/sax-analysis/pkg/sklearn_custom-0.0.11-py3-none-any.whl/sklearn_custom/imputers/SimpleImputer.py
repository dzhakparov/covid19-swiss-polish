from sklearn.impute import SimpleImputer
import pandas as pd
import numpy as np

# TODO: refactoring of 'for item in Xs:...' for other classes (OneHotEncoder,...) -> new parent class

class SimpleImputer(SimpleImputer):

    def __init__(self, df_out=True, strategy='constant', fill_value='MISSING',  **kwargs):
        super().__init__(**kwargs)
        self.df_out = df_out
        self.strategy = strategy
        self.fill_value = fill_value
        self.categories = None

    def fit(self, X, y=None):
        super().fit(X, y=y)
        self.categories = X.dtypes
        return self

    def transform(self, X):
        Xs = super().transform(X)

        if self.df_out and isinstance(X, pd.DataFrame):
            idx = X.index
            cols = X.columns.to_list()
            Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)

            for item in Xs:
                if self.categories[item].name == 'category':
                    values = list(self.categories[item].categories.values)
                    values.append(self.fill_value)
                    Xs[item] = pd.Categorical(Xs[item], categories=values, ordered = self.categories[item].ordered)
                    Xs[item].fillna(self.fill_value, inplace=True)
            Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)
        return Xs