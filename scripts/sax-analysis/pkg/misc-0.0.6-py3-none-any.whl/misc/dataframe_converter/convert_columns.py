import numpy as np
import pandas as pd
import logging


def convert_columns(file, columns, coerce='force', logger=None, log_level='column'):

    # numeric
    #   float64
    #   int64
    # object
    # datetime64[ns]
    # category

    # coerce= 'force', 'error'

    columns = {"A": ('category', ["1", "2", "3"]), "B": ('numeric', 'int')}
    columns = {}

    return file

# def convert_categorical(file, logging):
#     categorical = prep['convert_categorical']
#     logging.info(f"try to convert to categorical: \n{format(categorical)}\n")
#     file[categorical] = file[categorical].apply(lambda x: x.astype('category'))
#     logging.info(f"'convert_categorical' successfully finished!\n")
#     return file
#
#
# def convert_date(file, logging):
#     date = prep['convert_date']
#     logging.info(f"try to convert to date: \n{format(date)}\n")
#     file[date] = file[date].apply(lambda x: pd.to_datetime(x, format='%Y-%m-%d'))
#     logging.info(f"'convert_date' successfully finished!\n")
#     return file
#
# def convert_numerical(file, logging):
#     categorical = prep['convert_categorical']
#     date = prep['convert_date']
#     object = [col for col in file.columns if 'mews_' in col]
#     numerical = [item for item in file.columns.to_list() if
#                  item not in categorical and item not in date and item not in object]  # numerical columns (all the rest)
#     logging.info(f"try to convert to numerical: \n{format(numerical)}\n")
#     file[numerical] = file[numerical].apply(pd.to_numeric,
#                                             errors='ignore')  # If 'ignore', then invalid parsing will return the input
#     logging.info(f"'convert_numerical' successfully finished!\n")
#     return file
#
#
# def convert_object(file, logging):
#     object = [col for col in file.columns if 'mews_' in col]
#     logging.info(f"try to convert to type object: \n{format(object)}\n")
#     file[object] = file[object].apply(lambda x: x.astype('object'))
#     logging.info(f"'convert_object' successfully finished!\n")
#     return file


if __name__ == '__main__':
    pass