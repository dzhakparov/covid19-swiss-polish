import pandas as pd


def rename_columns(file, rename_dict, logger=None):
    """
    This function will rename columns of a pandas DataFrame
    Args:
        file: pd.DataFrame
        rename_dict: dictionary with old names as key and new names as value
        logger: instance of a logger (default: None)

    Returns: pandas DataFrame with renamed columns

    """

    return file


if __name__ == '__main__':
    pass