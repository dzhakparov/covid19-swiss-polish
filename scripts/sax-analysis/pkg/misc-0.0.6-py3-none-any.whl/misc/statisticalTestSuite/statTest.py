from scipy.stats import shapiro
import numpy as np
import numpy_indexed as npi
from scipy.stats import f
import pandas as pd
from scipy.stats import chi2_contingency, ttest_ind, mannwhitneyu, stats
from statsmodels.formula.api import ols
import scikit_posthocs as sp


class Error(Exception):
    pass


class NumberObservationTooSmallError(Error):
    pass  # TODO: implement


class StatTest:
    """
    gets 2 pandas Series (target and feature) and builds the statistics for
    """

    def __init__(self, col_by, col_feature, normality_manual=False, test_significance_level=0.05):

        self.col_by = col_by  # pandas Series
        self.col_feature = col_feature  # pandas Series
        self.normality_manual = normality_manual
        self.test_significance_level = test_significance_level
        self.feature = self.col_feature.name
        self.data = None

        self.type_target = self.col_by.dtype.name
        self.type_feature = self.col_feature.dtype.name

        self.test = None  # which test should be calculated (depending of distribution, homogeneity of variance etc.)?

        self.group_names = None  # names of subgroups as list: ['A', 'B', 'C']
        self.group_sizes = None  # sizes of subgroups in order of group_names: [12, 18, 6]
        self.group_means = None  # means of all subgroups (only if numerical)

        self.normality_test = 'shapiro-wilk'  # set test for normality assumptions
        self.normality_sig_level = 0.05  # TODO: refactor
        self.normality_values = None  # list of p-values of feature per group (if feature is numeric)
        self.normality_status = False  # will be set to True if assumptions are met or if is set to True manually

        self.var_homogeneity_test = 'levene'
        self.var_homogeneity_sig_level = 0.05  # # TODO: refactor
        self.var_homogeneity_value = None  # p_value of test for homogeneity of variance
        self.var_homogeneity_status = False  # will be set to True if assumptions are met or if is set to True manually

        # results
        self.pvalue = None
        self.pvalue_corrected = None
        self.expected_freq = None
        self.stats = None
        self.post_hoc = None
        self.post_hoc_test = None

        self._execute_method()

    def get_testresults(self):
        return self.results

    def get_data(self):
        return self.data

    def _execute_method(self):

        self._build_series()  # builds self.data as pandas Series with group as index and feature as values

        try:
            self._build_groups()
        except NumberObservationTooSmallError:
            # if number of observations is below 3 (per subgroup)
            self.feature = f"{self.col_feature.name} ERROR"
            return

        self._build_test_type()
        self._run_stat_test()

    def _build_series(self):
        """
        build pandas series with target as index and feature as values with all missing values removed
        """
        data = pd.concat([self.col_by, self.col_feature], axis=1)
        data.dropna(inplace=True)
        data = data.set_index(data.columns[0])
        self.data = data[data.columns[0]]  # convert to pandas series

    def _build_groups(self):
        """
        calculates the number of observations in each subgroup
        :param data: pandas series with groups as index
        :return: number of observation per subgroup as a list
        """

        grp = self.data.index.value_counts()
        self.group_sizes = grp.to_list()
        self.group_names = grp.index.to_list()

        group_sizes = [i for i in self.group_sizes if i <= 3]
        if len(group_sizes) >= 1:
            raise NumberObservationTooSmallError

        if self.type_feature in ['float64', 'int64']:
            self.group_means = self.data.groupby(level=0).mean()

    def _build_test_type(self):
        """
        determines which kind of statistical test should be applied on data depending on assumptions (normality,
        equality of variance, number of groups)
        """
        if self.type_feature in ['float64', 'int64']:  # for numerical feature

            self._test_normality()
            self._set_normality_status()
            self._test_var_homogenity()  # TODO: calculate 'levene' for non-normality values and 'bartlett'
            # for normal distributed values
            self._set_var_homogeneity_status()

            if len(self.group_names) == 2:
                if self.normality_status is False and self.normality_manual is False:
                    self.test = 'mann_whitney'  # wilcox  (non parameteric alternative to t-test)
                else:
                    self.test = 't_test'
            else:
                if self.normality_status is False and self.normality_manual is False:
                    self.test = 'kruskal'  # non parametric alternative to one-way anova
                else:
                    self.test = 'anova'

        else:
            self.test = 'chi_square'

    def _test_normality(self):
        """
        test for normality of each subgroup
        :return: list of p-values for each subgroup
        """
        if self.normality_test == 'shapiro-wilk':
            def shapiro_wilk(data):
                stat, p = shapiro(data.values)
                return p

            p_values = self.data.groupby(level=0).apply(shapiro_wilk)
            self.normality_values = p_values.values.tolist()

    def _set_normality_status(self):
        """
        sets status to False if at least one value of the list is below promoted sig_level
        """
        if self.normality_values is not None:
            sig_values = [i for i in self.normality_values if i <= self.normality_sig_level]
            if len(sig_values) >= 1:
                self.normality_status = False
            else:
                self.normality_status = True

    def _test_var_homogenity(self):

        if self.var_homogeneity_test == 'levene':
            self.var_homogeneity_value = levene(self.data)

    def _set_var_homogeneity_status(self):

        if self.var_homogeneity_value < self.var_homogeneity_sig_level:
            self.var_homogeneity_status = False
        else:
            self.var_homogeneity_status = True

    def _run_stat_test(self):
        """
        calculates the statistical test
        :return: dictionary (self.res) with named results {'name': 't-test', 'p-value': 0.04352, ...}
        """

        kwargs = {"normality": self.normality_status, "normality_manual": self.normality_manual,
                  "homogeneity": self.var_homogeneity_status, 'sig_level': self.test_significance_level}

        func = eval(self.test)
        func(self, **kwargs)


def chi_square(self, **kwargs):
    """
    calculates chi-square test for categorical feature
    https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2_contingency.html
    :param data: pandas series with groups as index and (categorical) feature as value
    :return: chi-square statistics: test statistics, p-value of the test, degrees of freedom, expected frequencies
     based on the marginal sums of the table.
    """

    data = self.data
    obs = pd.crosstab(data.index, data)
    res = chi2_contingency(obs)

    self.pvalue = res[1]
    self.expected_freq = res[3]
    self.stats = res[0]


def t_test(self, **kwargs):
    """
    calculates a t-test for numerical feature
    (https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_ind.html)
    :param data: pandas series with 2 groups (index is group, value is feature)
    :param kwargs: dict with normality, homogeneity
    :return: calculated t-statistic, p-value
    """

    data = self.data
    grouped = data.groupby(level=0)  # .indices
    grouped_list = [grouped.get_group(x) for x in grouped.groups]

    res = ttest_ind(grouped_list[0], grouped_list[1], equal_var=kwargs['homogeneity'])

    self.pvalue = res[1]
    self.stats = res[0]


def mann_whitney(self, **kwargs):
    """
    calculates a mann-whitney-u test (wilcox) for 2 not normally distributed numerical features
    :param data: pandas series with 2 groups (index is group, value is feature)
    :param kwargs: not supported for this test
    :return:  calculated t-statistic, p-value
    """

    data = self.data
    grouped = data.groupby(level=0)  # .indices
    grouped_list = [grouped.get_group(x) for x in grouped.groups]

    res = mannwhitneyu(grouped_list[0], grouped_list[1])

    self.pvalue = res[1]
    self.stats = res[0]


def anova(self, **kwargs):
    """
    https://towardsdatascience.com/1-way-anova-from-scratch-dissecting-the-anova-table-with-a-worked-example-170f4f2e58ad
    :param data:
    :param kwargs:
    :return:
    """
    data = self.data
    post_hoc_test = None

    data = data.to_frame().reset_index()
    data.rename(columns={data.columns[0]: "index", data.columns[1]: "values"}, inplace=True)
    lm = ols('values ~ index', data=data).fit()
    # table = sm.stats.anova_lm(lm)

    if lm.f_pvalue <= kwargs['sig_level']:
        ps, post_hoc_test = post_hoc(data, **kwargs)
    else:
        ps = None

    self.pvalue = lm.f_pvalue
    self.stats = lm.fvalue
    self.post_hoc_test = post_hoc_test
    self.post_hoc = ps


def kruskal(self, **kwargs):
    data = self.data
    post_hoc_test = None

    data = data.to_frame().reset_index()
    data.rename(columns={data.columns[0]: "index", data.columns[1]: "values"}, inplace=True)
    groupednumbers = {}
    for grp in data['index'].unique():
        groupednumbers[grp] = data['values'][data['index'] == grp].values

    args = [groupednumbers[grp] for grp in sorted(data['index'].unique())]
    kw = stats.kruskal(*args)

    if kw.pvalue <= kwargs['sig_level']:
        ps, post_hoc_test = post_hoc(data, **kwargs)
    else:
        ps = None

    self.pvalue = kw.pvalue
    self.stats = kw.statistic
    self.post_hoc = ps
    self.post_hoc_test = post_hoc_test


def levene(data):
    """
    calculates p_value of variance homogenity by levene for 2 or more subgroup
    source: https://aaronschlegel.me/levenes-test-equality-variances-python.html
    :return: p_value of tests statistics
    """

    data = data.to_frame().reset_index().to_numpy()

    group_obs = np.array([i for _, i in npi.group_by(data[:, 0], data[:, 0], len)])

    group_medians = []

    for i in data[:, 0]:
        group_medians.append(np.median(data[np.where(data[:, 0] == i)][:, 1]))

    data = np.column_stack([data, np.array(group_medians)])

    zij = np.abs(np.array(data[:, 1] - data[:, 2]))
    data = np.column_stack([data, zij])

    zij_group_means = []

    for i in data[:, 0]:
        zij_group_means.append(np.mean(data[np.where(data[:, 0] == i)][:, 3]))

    data = np.column_stack([data, np.array(zij_group_means)])

    n = data.shape[0]
    k = len(np.unique(data[:, 0]))

    zij_group_means = np.array([i for _, i in npi.group_by(data[:, 0], data[:, 3], np.mean)])

    total_mean = np.mean(data[:, 3])

    numerator = np.sum(group_obs * (zij_group_means - total_mean) ** 2)

    denominator = np.sum((data[:, 3] - data[:, 4]) ** 2)

    w = (n - k) / (k - 1) * (numerator / denominator)

    p_value = 1 - f.cdf(w, k - 1, n - k)

    return p_value


def post_hoc(data, **kwargs):
    """
    If an ANOVA test has identified that not all groups belong to the same population, then methods may be used to
    identify which groups are significantly different to each other
    :param data:
    :param kwargs:
    :return:
    """
    # data = data.to_frame().reset_index()
    # data.rename(columns={data.columns[1]: "values"}, inplace=True)
    if not kwargs['normality'] and not kwargs['normality_manual']:
        # Post hoc pairwise test for multiple comparisons of mean rank sums (Dunn’s test).
        # May be used after Kruskal-Wallis one-way analysis of variance by ranks to do pairwise comparisons
        post_hoc = sp.posthoc_dunn(data, group_col='index', val_col='values', p_adjust='holm')
        post_hoc_test = 'dunn'
    else:
        # Performs Tukey’s all-pairs comparisons test for normally distributed data with equal group variances.
        post_hoc = sp.posthoc_tukey(data, group_col='index', val_col='values')
        post_hoc_test = 'tukey'

    return post_hoc, post_hoc_test
