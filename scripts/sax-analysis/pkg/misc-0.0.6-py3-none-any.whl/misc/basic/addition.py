def addition(a: int, b: int) -> int:
    """
    calculates the sum of two numbers

    Args:
        a: first argument
        b: second argument

    Returns: addition of a and b

    """
    return a + b
