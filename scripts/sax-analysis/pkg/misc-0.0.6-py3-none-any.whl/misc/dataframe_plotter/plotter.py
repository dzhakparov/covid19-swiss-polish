from abc import ABC, abstractmethod


class Plotter:
    def __init__(self, df):
        self.df = df

    @abstractmethod
    def get_plot(self):
        pass

    def _get_title(self):
        return f"{self.__class__.__name__}"

    def _update_layout(self, title):

        self.fig.update_layout(
            title={
                'text': title,
                'font': {'size': 24}
            },
            template='plotly_white',
        )