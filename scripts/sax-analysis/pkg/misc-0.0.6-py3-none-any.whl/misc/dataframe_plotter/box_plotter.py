import pandas as pd
import plotly.express as px
import math
import pprint
import re
from datetime import datetime
import os

from misc.dataframe_plotter.plotter import Plotter
from plotly.subplots import make_subplots
import plotly.graph_objects as go


class BoxPlotter(Plotter):

    def __init__(self, data, split=None, y=None, x=None, **kwargs):
        self.data = data
        self.split = split
        self.y = y
        self.x = x
        self.kwargs = kwargs
        self.linebreak = 2000
        self.split_unique_cats = None
        self.figure_data = []
        self.style = {'boxpoints': 'all', 'boxmean': True}  # Boxplot
        # self.style = {}
        # self.grid = {'horizontal_spacing': 0.05, 'vertical_spacing': 0.05}  # make_subplot
        self.grid = {}
        self.rows = 1
        self.cols = 2
        self.figs = []
        self._build_figures()

    def _build_figures(self):

        """
        calculates the sum of two numbers

        Args:
            a: first argument
            b: second argument

        Returns: addition of a and b

        """

        prep_data = self._prepare_data()
        self._split_data(prep_data)  # self.figure_data
        self._initial_grid()  # self.subplot_position  (OKAY)
        self._update_figure_data_grid_annotation()  # self.figure_data
        self._create_figure()  # returns list of figures according to dimensions

    def _prepare_data(self):

        numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
        num_data = self.data.select_dtypes(include=numerics)
        self.data['index'] = self.data.index

        if self.y is not None:
            cols = [i for i in num_data.columns if i in self.y]
        else:
            cols = num_data.columns.to_list()

        self.y = cols.copy()
        cols.append('index')
        if self.split is not None:
            cols.append(self.split)
            prep_data = pd.melt(self.data[cols], id_vars=[self.split, 'index'], var_name='y', value_name='value')
        else:
            prep_data = pd.melt(self.data[cols], id_vars=['index'], var_name='y', value_name='value')

        self.data.drop('index', axis=1, inplace=True)
        return prep_data

    def _split_data(self, data):

        if self.split is not None:
            self.split_unique_cats = list(data[self.split].unique())

        for feature in self.y:
            feature_data = data[data['y'] == feature]
            if data.shape[1] == 4:  # with split
                split_group = []
                for split in self.split_unique_cats:
                    split_feature_data = feature_data[feature_data[self.split] == split]
                    split_group.append(split_feature_data)
                self.figure_data.append(split_group)
            else:  # without split
                self.figure_data.append([feature_data])

    def _initial_grid(self):
        """
        returns list of grid position
        """
        n_figures = len(self.figure_data)

        def _calc_combination(n_cols, n_rows, repetitions=1):
            res = []
            for rep in range(repetitions):
                subs = []
                for i in range(1, n_rows + 1):
                    for j in range(1, n_cols + 1):
                        subs.append((i, j))
                res.append(subs)
            return res

        # one figure
        if self.rows is None and self.cols is None:
            # default with all subplots in one figure
            n_cols = math.ceil(math.sqrt(n_figures))
            n_rows = math.floor(math.sqrt(n_figures))
            if n_cols * n_rows < n_figures:
                n_rows = n_rows + 1
            self.subplots_position = _calc_combination(n_cols=n_cols, n_rows=n_rows, repetitions=1)

        # one figure with defined number of cols or rows
        if (self.cols is not None and self.rows is None) or (self.cols is None and self.rows is not None):
            if self.cols is not None:
                n_cols = self.cols
                n_rows = math.ceil(n_figures / n_cols)
            if self.rows is not None:
                n_rows = self.rows
                n_cols = math.ceil(n_figures / n_rows)
            self.subplots_position = _calc_combination(n_cols=n_cols, n_rows=n_rows, repetitions=1)

        # possibly multiple figures/sheets
        if (self.cols is not None) and (self.rows is not None):
            if self.cols * self.rows < n_figures:
                repetitions = math.ceil(n_figures / (self.cols * self.rows))
            else:
                repetitions = 1
            self.subplots_position = _calc_combination(n_cols=self.cols, n_rows=self.rows, repetitions=repetitions)

    def _update_figure_data_grid_annotation(self):
        data = []
        grid = []
        annotations = []
        counter = 0  # counter
        for i in self.subplots_position:
            sub_data = []
            sub_grid = []
            sub_annotations = []
            for y in i:
                if counter < len(self.figure_data):
                    sub_data.append(self.figure_data[counter])
                    sub_grid.append(y)
                    sub_annotations.append(self.y[counter])
                    counter += 1
            data.append(sub_data)
            grid.append(sub_grid)
            annotations.append(sub_annotations)
        self.figure_data = data
        self.subplots_position = grid
        self.annotations = annotations

    def _create_figure(self):

        COLOR = ['blue', 'indianred', 'green', 'orange',
                 'black']  # TODO (COLORS_MAPPER = {"A": "#38BEC9", "B": "#D64545"})

        for figure, data, annotation in zip(self.subplots_position, self.figure_data, self.annotations):

            n_row = max([i[0] for i in figure])
            n_col = max([i[1] for i in figure])

            fig = make_subplots(rows=n_row, cols=n_col, subplot_titles=annotation, **self.grid)

            for idx, subplot in enumerate(figure):
                for i, trace in enumerate(data[idx]):

                    if self.split is None:
                        label = 'data'
                    else:
                        label = trace.iloc[0, 0]

                    if idx == 0:  #
                        fig.add_trace(

                            # go.Scatter(y=trace['value'],
                            #            x=x,
                            #            mode='markers',
                            #            name=label,
                            #            legendgroup=label,
                            #            marker_color=COLOR[i],
                            #            **self.style
                            #            ),
                            # row=subplot[0], col=subplot[1]

                            go.Box(y=trace['value'],
                                   name=label,
                                   legendgroup=label,
                                   marker_color=COLOR[i],
                                   text=trace['index'],
                                   showlegend=True,
                                   **self.style),
                            row=subplot[0], col=subplot[1]
                        )
                    else:
                        fig.add_trace(

                            # go.Scatter(y=trace['value'],
                            #            x=x,
                            #            mode='markers',
                            #            name=label,
                            #            legendgroup=label,
                            #            showlegend=False,
                            #            marker_color=COLOR[i],
                            #            **self.style
                            #            ),
                            # row=subplot[0], col=subplot[1]

                            go.Box(y=trace['value'],
                                   name=label,
                                   legendgroup=label,
                                   marker_color=COLOR[i],
                                   text=trace['index'],
                                   showlegend=False,
                                   **self.style),
                            row=subplot[0], col=subplot[1]
                        )

            fig.update_layout(
                title={
                    'text': f'<b>Boxplot</b>',
                    'font': {'size': 25}
                },
                template='plotly_white'
            )

            self.figs.append(fig)

    def show(self):
        """

        Returns:

        """
        for fig in self.figs:
            fig.show()

    def get_figures(self):
        """

        Returns:

        """
        return self.figs

    def store(self, path=None, name=None):
        """

        Args:
            path:
            name:

        Returns:

        """
        if path is None:
            path = os.getcwd()

        if name is None:
            name = f"boxplot_{datetime.now()}"

        try:
            no_figs = len(self.figs)
            for idx, fig in enumerate(self.figs):
                if no_figs == 1:
                    fig.write_html(f"{path}/{name}.html")
                else:
                    fig.write_html(f"{path}/{name}_{idx}.html")
        except():
            pass

    def get_features(self):
        """

        Returns:

        """
        return self.y


# class Boxplot:
#
#     def __init__(self, data, split=None, y=None, x=None, **kwargs):
#         """
#
#         Args:
#             data: blabla
#             split: blabla
#             y:
#             x:
#             **kwargs:
#         """
#
#         self.data = data
#         self.split = split
#         self.y = y
#         self.x = x
#         self.kwargs = kwargs
#         self.linebreak = 2000
#         self.split_unique_cats = None
#         self.figure_data = []
#         self.style = {'boxpoints': 'all', 'boxmean': True}  # Boxplot
#         # self.style = {}
#         # self.grid = {'horizontal_spacing': 0.05, 'vertical_spacing': 0.05}  # make_subplot
#         self.grid = {}
#         self.rows = 2
#         self.cols = 3
#         self.figs = []
#         self._build_figures()
#
#     def _build_figures(self):
#
#         """
#         calculates the sum of two numbers
#
#         Args:
#             a: first argument
#             b: second argument
#
#         Returns: addition of a and b
#
#         """
#
#         prep_data = self._prepare_data()
#         self._split_data(prep_data)  # self.figure_data
#         self._initial_grid()  # self.subplot_position  (OKAY)
#         self._update_figure_data_grid_annotation()  # self.figure_data
#         self._create_figure()  # returns list of figures according to dimensions
#
#     def _prepare_data(self):
#
#         numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
#         num_data = self.data.select_dtypes(include=numerics)
#         self.data['index'] = self.data.index
#
#         if self.y is not None:
#             cols = [i for i in num_data.columns if i in self.y]
#         else:
#             cols = num_data.columns.to_list()
#
#         self.y = cols.copy()
#         cols.append('index')
#         if self.split is not None:
#             cols.append(self.split)
#             prep_data = pd.melt(self.data[cols], id_vars=[self.split, 'index'], var_name='y', value_name='value')
#         else:
#             prep_data = pd.melt(self.data[cols], id_vars=['index'], var_name='y', value_name='value')
#
#         self.data.drop('index', axis=1, inplace=True)
#         return prep_data
#
#     def _split_data(self, data):
#
#         if self.split is not None:
#             self.split_unique_cats = list(data[self.split].unique())
#
#         for feature in self.y:
#             feature_data = data[data['y'] == feature]
#             if data.shape[1] == 4:  # with split
#                 split_group = []
#                 for split in self.split_unique_cats:
#                     split_feature_data= feature_data[feature_data[self.split] == split]
#                     split_group.append(split_feature_data)
#                 self.figure_data.append(split_group)
#             else:  # without split
#                 self.figure_data.append([feature_data])
#
#     def _initial_grid(self):
#         """
#         returns list of grid position
#         """
#         n_figures = len(self.figure_data)
#
#         def _calc_combination(n_cols, n_rows, repetitions=1):
#             res = []
#             for rep in range(repetitions):
#                 subs = []
#                 for i in range(1, n_rows + 1):
#                     for j in range(1, n_cols + 1):
#                         subs.append((i, j))
#                 res.append(subs)
#             return res
#
#         # one figure
#         if self.rows is None and self.cols is None:
#             # default with all subplots in one figure
#             n_cols = math.ceil(math.sqrt(n_figures))
#             n_rows = math.floor(math.sqrt(n_figures))
#             if n_cols * n_rows < n_figures:
#                 n_rows = n_rows + 1
#             self.subplots_position = _calc_combination(n_cols=n_cols, n_rows=n_rows, repetitions=1)
#
#         # one figure with defined number of cols or rows
#         if (self.cols is not None and self.rows is None) or (self.cols is None and self.rows is not None):
#             if self.cols is not None:
#                 n_cols = self.cols
#                 n_rows = math.ceil(n_figures / n_cols)
#             if self.rows is not None:
#                 n_rows = self.rows
#                 n_cols = math.ceil(n_figures / n_rows)
#             self.subplots_position = _calc_combination(n_cols=n_cols, n_rows=n_rows, repetitions=1)
#
#         # possibly multiple figures/sheets
#         if (self.cols is not None) and (self.rows is not None):
#             if self.cols * self.rows < n_figures:
#                 repetitions = math.ceil(n_figures / (self.cols * self.rows))
#             else:
#                 repetitions = 1
#             self.subplots_position = _calc_combination(n_cols=self.cols, n_rows=self.rows, repetitions=repetitions)
#
#     def _update_figure_data_grid_annotation(self):
#         data = []
#         grid = []
#         annotations = []
#         counter = 0  # counter
#         for i in self.subplots_position:
#             sub_data = []
#             sub_grid = []
#             sub_annotations = []
#             for y in i:
#                 if counter < len(self.figure_data):
#                     sub_data.append(self.figure_data[counter])
#                     sub_grid.append(y)
#                     sub_annotations.append(self.y[counter])
#                     counter += 1
#             data.append(sub_data)
#             grid.append(sub_grid)
#             annotations.append(sub_annotations)
#         self.figure_data = data
#         self.subplots_position = grid
#         self.annotations = annotations
#
#     def _create_figure(self):
#
#         COLOR = ['blue', 'indianred', 'green', 'orange',
#                  'black']  # TODO (COLORS_MAPPER = {"A": "#38BEC9", "B": "#D64545"})
#
#         for figure, data, annotation in zip(self.subplots_position, self.figure_data, self.annotations):
#
#             n_row = max([i[0] for i in figure])
#             n_col = max([i[1] for i in figure])
#
#             fig = make_subplots(rows=n_row, cols=n_col, subplot_titles=annotation, **self.grid)
#
#             for idx, subplot in enumerate(figure):
#                 for i, trace in enumerate(data[idx]):
#
#                     if self.split is None:
#                         label = 'data'
#                     else:
#                         label = trace.iloc[0, 0]
#
#                     if idx == 0:  #
#                         fig.add_trace(
#
#                             # go.Scatter(y=trace['value'],
#                             #            x=x,
#                             #            mode='markers',
#                             #            name=label,
#                             #            legendgroup=label,
#                             #            marker_color=COLOR[i],
#                             #            **self.style
#                             #            ),
#                             # row=subplot[0], col=subplot[1]
#
#                             go.Box(y=trace['value'],
#                                    name=label,
#                                    legendgroup=label,
#                                    marker_color=COLOR[i],
#                                    text=trace['index'],
#                                    showlegend=True,
#                                    **self.style),
#                             row=subplot[0], col=subplot[1]
#                         )
#                     else:
#                         fig.add_trace(
#
#                             # go.Scatter(y=trace['value'],
#                             #            x=x,
#                             #            mode='markers',
#                             #            name=label,
#                             #            legendgroup=label,
#                             #            showlegend=False,
#                             #            marker_color=COLOR[i],
#                             #            **self.style
#                             #            ),
#                             # row=subplot[0], col=subplot[1]
#
#                             go.Box(y=trace['value'],
#                                    name=label,
#                                    legendgroup=label,
#                                    marker_color=COLOR[i],
#                                    text=trace['index'],
#                                    showlegend=False,
#                                    **self.style),
#                             row=subplot[0], col=subplot[1]
#                         )
#
#             fig.update_layout(
#                 title={
#                     'text': f'<b>Boxplot</b>',
#                     'font': {'size': 25}
#                 },
#                 template='plotly_white'
#             )
#
#             self.figs.append(fig)
#
#     def show(self):
#         """
#
#         Returns:
#
#         """
#         for fig in self.figs:
#             fig.show()
#
#     def get_figures(self):
#         """
#
#         Returns:
#
#         """
#         return self.figs
#
#     def store(self, path=None, name=None):
#         """
#
#         Args:
#             path:
#             name:
#
#         Returns:
#
#         """
#         if path is None:
#             path = os.getcwd()
#
#         if name is None:
#             name = f"boxplot_{datetime.now()}"
#
#         try:
#             no_figs = len(self.figs)
#             for idx, fig in enumerate(self.figs):
#                 if no_figs == 1:
#                     fig.write_html(f"{path}/{name}.html")
#                 else:
#                     fig.write_html(f"{path}/{name}_{idx}.html")
#         except():
#             pass
#
#     def get_features(self):
#         """
#
#         Returns:
#
#         """
#         return self.y


if __name__ == '__main__':

    raw_data = pd.read_csv('../../data/working_data.csv', index_col=0)
    # fig = Boxplot(data=raw_data, split='group', features=['albumin_', 'ck_', 'aptt_', 'ferritin_', 'ck_mb_'])

    fig = BoxPlotter(data=raw_data, split='sex', y=['albumin_', 'ck_', 'aptt_', 'ferritin_', 'ck_mb_'])

    # fig = Boxplot(data=data, split='group')    # fig = Boxplot(data=data, split='group')

    # fig.set_style(n_cols=3, n_rows=2, facet_col_spacing=0.05, facet_row_spacing=0.1, points='suspectedoutliers')
    # fig.set_style(n_cols=4, n_rows=4, facet_col_spacing=0.05, facet_row_spacing=0.1)
    # fig.set_style_annotations(style={'font': {'size': 12}}, linebreak=100)
    # fig.add_additional_annotation(annotation='mean')
    # fig.add_additional_annotation(annotation={'albumin_': 'AAAA kjdf  sjdfh fng nsdfgjn', 'ck_': 'reeer'})
    # print(fig.get_features())
    fig.show()
    # fig.store(path="/home/marco/Desktop", name="outlier")

    # figs = fig.get_figures()
    #
    # figs[0].update_layout(  # height=500, width=700,
    #     title_text="Multiple Subplots with Titles",
    #     margin=dict(l=0, r=0, b=0, t=300, pad=0))
    #
    # figs[0].update_layout(
    #     title={
    #         # 'text': f"{y}",
    #         'font_size': 28,
    #         'xanchor': 'center',
    #         'yanchor': 'top'},
    #     template='plotly_white',
    #     #  yaxis_title=y
    # )
    # figs[0].show()
