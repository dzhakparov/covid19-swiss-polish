import numpy as np
import numpy_indexed as npi
from scipy.stats import f
import pandas as pd
from scipy.stats import chi2_contingency, ttest_ind, mannwhitneyu, stats
from statsmodels.formula.api import ols
import scikit_posthocs as sp


def chi_square(self, **kwargs):
    """
    calculates chi-square test for categorical feature
    https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2_contingency.html
    :param data: pandas series with groups as index and (categorical) feature as value
    :return: chi-square statistics: test statistics, p-value of the test, degrees of freedom, expected frequencies
     based on the marginal sums of the table.
    """

    data = self.data
    obs = pd.crosstab(data.index, data)
    res = chi2_contingency(obs)

    self.pvalue = res[1]
    self.expected_freq = res[3]
    self.stats = res[0]


def t_test(self, **kwargs):
    """
    calculates a t-test for numerical feature
    (https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_ind.html)
    :param data: pandas series with 2 groups (index is group, value is feature)
    :param kwargs: dict with normality, homogeneity
    :return: calculated t-statistic, p-value
    """

    data = self.data
    grouped = data.groupby(level=0)  # .indices
    grouped_list = [grouped.get_group(x) for x in grouped.groups]

    res = ttest_ind(grouped_list[0], grouped_list[1], equal_var=kwargs['homogeneity'])

    self.pvalue = res[1]
    self.stats = res[0]


def mann_whitney(self, **kwargs):
    """
    calculates a mann-whitney-u test (wilcox) for 2 not normally distributed numerical features
    :param data: pandas series with 2 groups (index is group, value is feature)
    :param kwargs: not supported for this test
    :return:  calculated t-statistic, p-value
    """

    data = self.data
    grouped = data.groupby(level=0)  # .indices
    grouped_list = [grouped.get_group(x) for x in grouped.groups]

    res = mannwhitneyu(grouped_list[0], grouped_list[1])

    self.pvalue = res[1]
    self.stats = res[0]


def anova(self, **kwargs):
    """
    https://towardsdatascience.com/1-way-anova-from-scratch-dissecting-the-anova-table-with-a-worked-example-170f4f2e58ad
    :param data:
    :param kwargs:
    :return:
    """
    data = self.data
    post_hoc_test = None

    data = data.to_frame().reset_index()
    data.rename(columns={data.columns[0]: "index", data.columns[1]: "values"}, inplace=True)
    lm = ols('values ~ index', data=data).fit()
    # table = sm.stats.anova_lm(lm)

    if lm.f_pvalue <= kwargs['sig_level']:
        ps, post_hoc_test = post_hoc(data, **kwargs)
    else:
        ps = None

    self.pvalue = lm.f_pvalue
    self.stats = lm.fvalue
    self.post_hoc_test = post_hoc_test
    self.post_hoc = ps


def kruskal(self, **kwargs):
    data = self.data
    post_hoc_test = None

    data = data.to_frame().reset_index()
    data.rename(columns={data.columns[0]: "index", data.columns[1]: "values"}, inplace=True)
    groupednumbers = {}
    for grp in data['index'].unique():
        groupednumbers[grp] = data['values'][data['index'] == grp].values

    args = [groupednumbers[grp] for grp in sorted(data['index'].unique())]
    kw = stats.kruskal(*args)

    if kw.pvalue <= kwargs['sig_level']:
        ps, post_hoc_test = post_hoc(data, **kwargs)
    else:
        ps = None

    self.pvalue = kw.pvalue
    self.stats = kw.statistic
    self.post_hoc = ps
    self.post_hoc_test = post_hoc_test


def levene(data):
    """
    calculates p_value of variance homogenity by levene for 2 or more subgroup
    source: https://aaronschlegel.me/levenes-test-equality-variances-python.html
    :return: p_value of tests statistics
    """

    data = data.to_frame().reset_index().to_numpy()

    group_obs = np.array([i for _, i in npi.group_by(data[:, 0], data[:, 0], len)])

    group_medians = []

    for i in data[:, 0]:
        group_medians.append(np.median(data[np.where(data[:, 0] == i)][:, 1]))

    data = np.column_stack([data, np.array(group_medians)])

    zij = np.abs(np.array(data[:, 1] - data[:, 2]))
    data = np.column_stack([data, zij])

    zij_group_means = []

    for i in data[:, 0]:
        zij_group_means.append(np.mean(data[np.where(data[:, 0] == i)][:, 3]))

    data = np.column_stack([data, np.array(zij_group_means)])

    n = data.shape[0]
    k = len(np.unique(data[:, 0]))

    zij_group_means = np.array([i for _, i in npi.group_by(data[:, 0], data[:, 3], np.mean)])

    total_mean = np.mean(data[:, 3])

    numerator = np.sum(group_obs * (zij_group_means - total_mean) ** 2)

    denominator = np.sum((data[:, 3] - data[:, 4]) ** 2)

    w = (n - k) / (k - 1) * (numerator / denominator)

    p_value = 1 - f.cdf(w, k - 1, n - k)

    return p_value


def post_hoc(data, **kwargs):
    """
    If an ANOVA test has identified that not all groups belong to the same population, then methods may be used to
    identify which groups are significantly different to each other
    :param data:
    :param kwargs:
    :return:
    """
    # data = data.to_frame().reset_index()
    # data.rename(columns={data.columns[1]: "values"}, inplace=True)
    if not kwargs['normality'] and not kwargs['normality_manual']:
        # Post hoc pairwise test for multiple comparisons of mean rank sums (Dunn’s test).
        # May be used after Kruskal-Wallis one-way analysis of variance by ranks to do pairwise comparisons
        post_hoc = sp.posthoc_dunn(data, group_col='index', val_col='values', p_adjust='holm')
        post_hoc_test = 'dunn'
    else:
        # Performs Tukey’s all-pairs comparisons test for normally distributed data with equal group variances.
        post_hoc = sp.posthoc_tukey(data, group_col='index', val_col='values')
        post_hoc_test = 'tukey'

    return post_hoc, post_hoc_test


def post_hoc_to_tuple(df):
    if df is not None:
        a = np.tril(df.values)  # get lower left triangle matrix
        b = np.where((a <= 0.05) & (a > 0))  # filter
        result = []
        for i in range(0, b[0].shape[0]):
            a1 = df.columns[b[0][i]]
            a2 = df.columns[b[1][i]]
            result.append((a1,a2,round(a[b[0][i], b[1][i]], 3)))
    return result


def means_to_string(s):
    """

    :param s:
    :return:
    """
    if s is not None:
        result = ""
        for index, value in s.items():
            result = result + str(index) + '=' + str(round(value, 3)) + ' / '
        result = result[:-2]
        return result


def post_hoc_to_string(df, level=0.05):
    """
    converts matrix with p-values to a simple string representation
    :param df: pandas DataFrame

              AD_Rural  AD_Urban  HC_Rural  HC_Urban
    AD_Rural -1.000000  0.040802  0.073529  0.532397
    AD_Urban  0.040802 -1.000000  1.000000  0.819494
    HC_Rural  0.073529  1.000000 -1.000000  1.000000
    HC_Urban  0.532397  0.819494  1.000000 -1.000000

    :return: string of significant p-values with groupnames   # AD_Urban <-> AD_Rural (0.041) / HC_Rural <-> AD_Rural (0.074)
    """
    if df is not None:
        a = np.tril(df.values)  # get lower left triangle matrix
        b = np.where((a <= level) & (a > 0))  # filter
        result = ""
        for i in range(0, b[0].shape[0]):
            a1 = df.columns[b[0][i]]
            a2 = df.columns[b[1][i]]
            result = result + a1 + ' <-> ' + a2 + f' ({round(a[b[0][i], b[1][i]], 3)}) / '

        result = result[:-2]
        return result