import os
import time
from sklearn.model_selection import TimeSeriesSplit, KFold, ShuffleSplit, StratifiedKFold, GroupShuffleSplit, \
    GroupKFold, StratifiedShuffleSplit
from sklearn.model_selection import BaseCrossValidator, GridSearchCV, cross_val_score, train_test_split
import sklearn.model_selection as ms
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, RandomForestRegressor, VotingClassifier
from pprint import pformat
from joblib import dump, load
from pathlib import Path
from itertools import product
import random
import math
import pandas as pd
from sklearn.pipeline import Pipeline
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
import numpy as np
import copy
from datetime import datetime
import itertools


class Model:

    def __init__(self, pipe, params=None, cv=None, random_state=None, scoring='accuracy', hp_optimizer='GridSearchCV',
                 overall=False, fs_config=None, n_jobs=-1, **kwargs):
        """
        Args:
            pipe: sklearn Pipeline with estimator (DummyEstimator) as last transformer
                    exp:  Pipeline([('imputer', SimpleImputer()),
                                    ('min_max', MinMaxScaler()),
                                    ('zero_var', VarianceThreshold(threshold=(.95 * (1 - .95)))),
                                    ('estimator', RandomForestClassifier())
                                    ])
            params: tuple with model_params and base_params as list of dictionaries,
                    exp:
                    ([{ 'prep__num__imputer__strategy': ['mean', 'median'],
                        'prep__num_rest__imputer__strategy': ['mean', 'median']}
                     ],
                     [{ 'estimator': [KNeighborsClassifier()], 'estimator__n_neighbors': [1, 2, 3],
                       'estimator__weights': ['uniform', 'distance']},
                       {'estimator': [RandomForestClassifier()], 'estimator__n_estimators': [200, 300]},
                       {'estimator': [VotingClassifier(estimators=None, voting='hard')]}
                     ]
                    )
                    if None is selected, only a default base Estimator (RandomForestClassifier for classification and
                    RandomForestRegressor for regression) is applied
            cv: BaseCrossValidator-Object, integer or None
            random_state: integer to build reproducible splits in CrossValidation (used if cv is type integer or None)
            hp_optimizer: hyper-parameter optimizer. One out of GridSearchCV (default), HalvingGridSearchCV,
            ParameterGrid, ParameterSampler, RandomizedSearchCV, HalvingRandomSearchCV
            overall: boolean. If False (default) best model of each promoted algorithm is returned else only the best
            model overall is evaluated
            fs_config: None or configuration for object FeatureSelector as dict. If None or empty dict
            feature_selection will not be applied
        """
        self.X = None  # stores X with that models have been fitted
        self.y = None  # stores y with that models have been fitted
        self.labels = None  # stores labels in case of classification problems
        self.hp_optimizer = self.HyperParameterOptimizer(hp_optimizer=hp_optimizer)
        self.pipe = self.Pipe(pipe=pipe)  # pipe-object with actual pipe as parameter pipe
        self.params = self.GridParams(params=params)  # grid_object with actual grid
        self.cv = self.CrossValidation(cv=cv, random_state=random_state)
        self.scoring = self.Scoring(scoring=scoring)
        self.n_jobs = n_jobs
        self.feature_selector = None  # holds a instance of FeatureSelector with results and cv-results
        self.fs_config = fs_config  # None or dict with config
        self.overall = overall  # boolean, best estimator of all or (True) or best of each algorithm (False)
        self.search_obj_store = []  # stores cross-validated algorithms
        self.nested_cv_scores = []  # stores nested cv-scores as better approximation for real model prediction capacity
        self.model_names = []  # stores name of applied algorithm
        self.fitting_type = self._detect_fitting_type()  # regression or classification problem?
        self.voting_estimator = self._update_voting_estimator()
        self.initialisation_time = self._setting_initialisation_time()
        self.fitting_time = [None, None]  # stores start- and end-time of fitting-process
        self.best_models = []
        self.predictions = {}  # dictionary with name of algorithm as name and predictions as values
        self.probas = {}  # dictionary with name of algorithm as key and a array of values as indicator for probability

    class CrossValidation:
        """ cross_validation object which holds information about splits
        """

        def __init__(self, cv, random_state):
            self.cv = cv  # holds valid cv-object
            self.random_state = random_state  # if random state is None and cv is of type int, a normal un-shuffled KFold-Object is generated
            self.train_indices = []
            self.test_indices = []
            self._validate_cv()

        def __repr__(self):
            f = f"{str(self.cv)}"
            return f

        def _validate_cv(self):
            """
            """
            if self.cv is not None:
                if not (isinstance(self.cv, int) or isinstance(self.cv, BaseCrossValidator)):
                    raise Exception(
                        f"cv has to be of type integer for number of splits' or of class 'BaseCrossValidator'")
            if isinstance(self.cv, int):
                if self.random_state is None:
                    self.cv = KFold(n_splits=self.cv, shuffle=False)
                else:
                    self.cv = KFold(n_splits=self.cv, random_state=self.random_state, shuffle=True)

        def calculate_cv_indices(self, X):
            for (tr, tt) in self.cv.split(X=X):
                self.train_indices.append(tr)
                self.test_indices.append(tt)

    # TODO: change to property?
    class HyperParameterOptimizer:
        """
        builds and validates an hyper-parameter optimizer of Class BaseSearchCV. Default is GridSearchCV.
        """

        def __init__(self, hp_optimizer):
            self.hp_optimizer = self._validate_optimizer(hp_optimizer)

        def __repr__(self):
            f = f"{str(self.hp_optimizer)}"
            return f

        @staticmethod
        def _validate_optimizer(hp_optimizer):
            if hp_optimizer not in ['GridSearchCV', 'RandomizedSearchCV']:
                raise Exception("hp_optimizer has to be one out of ['GridSearchCV', 'RandomizedSearchCV']")
            else:
                return hp_optimizer

    class GridParams:
        def __init__(self, params):
            self.params = params
            self._build_param_grid()

        def __repr__(self):
            f = f"{str(self.params)}"
            return f

        def _build_param_grid(self):
            # TODO: update in case of missing params[0] or params[1]-> set default estimator
            # TODO: synchronize ParamGrid for hp_Optimizer (exp. RandomGridCV needs param_distributions not param_grid)
            self.params = [{**base, **d} for base in self.params[1] for d in self.params[0]]

    class Pipe:
        def __init__(self, pipe):
            # TODO: evaluate Pipe -> is estimator as last transformer etc.
            self.pipe = pipe

        def __repr__(self):
            f=f"{str(self.pipe)}"
            return f

    class Scoring:
        def __init__(self, scoring):
            """
            :param scoring: string or scoring ob
            """
            # TODO: evaluate -> own scoring object
            self.scoring = scoring

        def __repr__(self):
            f = f"{str(self.scoring)}"
            return f

    class FeatureSelector:
        """
        processes stepwise feature selection on cross-validation parts of X and detects which features are chosen first
        """

        def __init__(self, models, cross_validation=None, **kwargs):
            """
            :param models: dictionary with name of model as key and the model or pipeline with final estimator as value
            :param cv: BaseCrossValidator-Object or None
            """
            self.models = self._validate_models(models)
            self.cross_validation = self._validate_cv(cross_validation)  # cv-obj
            self.X = None
            self.y = None
            self.results = {}
            self.config = kwargs  # dictionary of arguments for SFS-obj, as 'k_features', 'forward', 'scoring', ...

        def __repr__(self):
            f=f"{str(self.config)}"
            return f

        @staticmethod
        def _validate_models(models):
            return models

        @staticmethod
        def _validate_cv(cv):
            return cv
            # if cv is not None:
            #     if not (isinstance(cv, int) or isinstance(cv, BaseCrossValidator)):
            #         raise Exception(
            #             f"cv has to be of type integer for number of splits' or of class 'BaseCrossValidator'")
            # return cv

        @staticmethod
        def _check_input(X, y):
            if not isinstance(X, pd.DataFrame):
                raise Exception(f"X must be an instance of pd.DataFrame. If you used Pipelines in combination with "
                                f"sklearn-estimators watch that these estimators are from sklearn-custom package with "
                                f"support of pd.DataFrame")
            # if not isinstance(y, pd.Series) or not isinstance(y, pd.DataFrame):
            #     raise Exception(f"y must be an instance of pd.Series or pd.DateFrame")
            return X, y

        def _update_config(self):
            """ config is not executed in _init__ due shape of X is necessary"""
            if self.config:
                if 'k_features' in self.config:
                    self.config['k_features'] = min(self.config['k_features'], self.X.shape[1])
                if 'n_jobs' not in self.config:
                    self.config['n_jobs'] = -1  # use all cores per default

        def fit(self, X, y):
            """
            fits feature selection for all algorithms except for VotingEstimators
            :param X: X as pandas DataFrame
            :param y: y as pandas Series or DataFrame
            :return: a dictionary with results per algorithm
            """
            result_algorithm = {}
            self.X, self.y = self._check_input(X, y)

            self._update_config()

            if self.cross_validation is not None:
                self.cross_validation.calculate_cv_indices(self.X)
                indices = self.cross_validation.train_indices

            model_names = list(self.models.keys())
            for model_name in model_names:

                model = self.models[model_name]
                if 'Voting' not in model_name and 'Dummy' not in model_name:  # exclude 'Voting' and 'Dummy' estimators
                    position_estimator = [idx for idx, i in enumerate(list(model.named_steps)) if i == 'estimator'][0]
                    best_estimator = model.steps.pop(position_estimator)[1]
                    # best_estimator = copy.deepcopy(best_estimator)
                    preprocessed_x = model.fit_transform(self.X)  # apply preprocessing steps to X (imputing aso.)

                    sfs = SFS(estimator=best_estimator, **self.config)
                    sfs = sfs.fit(np.array(preprocessed_x), np.ravel(self.y), custom_feature_names=list(preprocessed_x))
                    result_algorithm['X'] = sfs

                    # apply feature selector on each split of cross-validation object. This is to watch stability of
                    # selecting features in small datasets (does it change with different subsets?)
                    if self.cross_validation is not None:
                        for counter, idx in enumerate(indices):
                            X = self.X.iloc[idx, :]
                            y = self.y.iloc[idx]
                            preprocessed_x = model.fit_transform(X)
                            sfs_cv = SFS(estimator=best_estimator, **self.config)
                            sfs_cv = sfs_cv.fit(np.array(preprocessed_x), np.ravel(y),
                                                custom_feature_names=list(preprocessed_x))
                            result_algorithm[f'X_{counter}'] = sfs_cv

                    self.results[model_name] = copy.deepcopy(result_algorithm)

        def get_results(self):
            return self.results

    def __repr__(self):
        f = f"\n\nModel-object initialisation: {str(self.initialisation_time)}\n\n" \
            f" - fitted for: {pformat(self.model_names)}\n" \
            f" - total parameters tuned: to_calculate...\n" \
            f" - feature selector: {True if self.feature_selector is not None else False}\n" \
            f" - fitting-time: {round(self.fitting_time[1] - self.fitting_time[0], 2)}s\n"
        return f

    @staticmethod
    def _setting_initialisation_time():
        now = datetime.now()
        dt_string = now.strftime("%Y-%m-%d %H:%M:%S")
        return dt_string

    @staticmethod
    def _build_weights_grid(no_algorithms, fraction, max_no_weights=None, random_seed=None):
        """
        builds a grid of weight distribution for hyper-parameter tuning a VotingEstimator
        :param fraction: float number between 0 and 1 which indicates the gap between weights of each algorithm. The smaller the gap the more possible combinations occurs!
        :param no_algorithms: length of each produced tuple as int. Must agree with number of algorithms to be included in VotingEstimator
        :param max_no_weights: int fore maximal number of tuples to be used for tuning. If fraction is small and no_algorithms is large a huge amount of combinations occurs. This can be limited on a random samle of all possible distributions with max_no_weights
        :param random_seed: int. Only works if max_no_weights is not None and max_no_weights is not smaller as all combinations occurs
        :return: a list of tuples with weights for each algorithm
        """
        if not 0 < fraction < 1:
            raise Exception(f"fraction has to be float between 0 and 1")

        all_combinations = list(product(range(1, math.floor(1 / fraction) + 1), repeat=no_algorithms))

        valid_unique_combinations = set()
        for comb in all_combinations:
            checksum = sum(comb)
            single_combination = []
            for item in comb:
                single_combination.append(item / checksum)
            valid_unique_combinations.add(tuple(single_combination))
        valid_unique_combinations = list(valid_unique_combinations)

        if max_no_weights is not None:
            random.seed(a=random_seed)
            valid_unique_combinations = random.sample(valid_unique_combinations,
                                                      min(max_no_weights, len(valid_unique_combinations)))
        return valid_unique_combinations

    def _update_voting_estimator(self):
        """
        pops 'VotingEstimator' out of params and and builds own voting_estimator-list with estimator and its parameters
        :return: listed dictionary with VotingEstimator-object ('estimator') and it's parameters
        """
        fitting_types = [(idx, type(i['estimator'][0]).__name__) for idx, i in enumerate(self.params.params)]
        bool_voting = [(idx, True) if 'Voting' in i else (idx, False) for (idx, i) in fitting_types]
        position = [idx if i is True else None for (idx, i) in bool_voting]
        position = [i for i in position if i is not None]

        if position:
            voting_estimator = []
            for idx in sorted(position,
                              reverse=True):  # it's necessary to start from behind do not influence remaining position
                voting_estimator.append(self.params.params.pop(idx))

            for item in voting_estimator:
                # remove unnecessary prep steps etc. -> remain only keys containing 'estimator'
                key = [i for i in list(item.keys()) if 'estimator' in i]
                unwanted = set(item) - set(key)
                for unwanted_key in unwanted: del item[unwanted_key]

                # remove 'estimator__' from fitting parameters (except for 'estimator' itself)
                key = list(voting_estimator[0].keys())
                values = list(voting_estimator[0].values())
                key = [i for i in key]
                key = [s.split('estimator__') for s in key]
                key = [item for sublist in key for item in sublist]
                key = list(filter(None, key))
                voting_estimator = dict(zip(key, values))

            if 'weights' in voting_estimator:
                no_algorithms = len(fitting_types) - len(position)

                if any([True for i in voting_estimator['weights'] if 'weightGrid' in i]):
                    bool_voting = [(idx, True) if 'weightGrid' in i else (idx, False) for (idx, i) in
                                   enumerate(voting_estimator['weights'])]
                    position = [idx if i is True else None for (idx, i) in bool_voting]
                    position = [i for i in position if i is not None]
                    x = voting_estimator['weights'].pop(position[0])
                    weight_grid = self._build_weights_grid(no_algorithms=no_algorithms, **x['weightGrid'])
                    voting_estimator['weights'] = voting_estimator['weights'] + weight_grid

                # check if length of weights equals number of estimators
                same_length = all([len(i) == no_algorithms for i in voting_estimator['weights']])
                if same_length is False:
                    raise Exception(f"'weights' in {type(voting_estimator['estimator'][0]).__name__} "
                                    f"has not same length as number of algorithms!")

            return [voting_estimator]
        else:
            return None

    def _detect_fitting_type(self):
        fitting_types = [type(i['estimator'][0]).__name__ for i in self.params.params]
        fitting_type = set(['Classification' if 'Classifier' in x else 'Regression' for x in fitting_types])
        if len(fitting_type) != 1:
            raise Exception(f"You are not allowed to apply mixed estimators for the same problem!")
        else:
            return list(fitting_type)[0]

    def _build_nested_scores(self, search_obj):
        """
        determine performance of model on cross-validated data (double/nested cross validation)
        :param search_obj:
        :return:
        """
        nested_scores = cross_val_score(search_obj, X=self.X, y=self.y,
                                        cv=KFold(n_splits=5, shuffle=True, random_state=2), n_jobs=-1,
                                        verbose=0, scoring=self.scoring.scoring)
        self.nested_cv_scores.append(nested_scores)

    def _run_cv(self, method_to_call, **kwargs):

        if self.overall:
            search_obj = method_to_call(self.pipe.pipe, self.params.params, cv=self.cv.cv, scoring=self.scoring.scoring,
                                        n_jobs=-1, refit=True, return_train_score=True, verbose=1, **kwargs)
            search_obj.fit(X=self.X, y=self.y)
            self.search_obj_store.append(search_obj)
            self._build_nested_scores(search_obj)
            self.model_names.append(type(self.search_obj_store[-1].best_estimator_.named_steps.estimator).__name__)
        else:
            for param in self.params.params:
                search_obj = method_to_call(self.pipe.pipe, param, cv=self.cv.cv, scoring=self.scoring.scoring,
                                            n_jobs=self.n_jobs, refit=True, return_train_score=True, verbose=1, **kwargs)
                search_obj.fit(X=self.X, y=self.y)
                self.search_obj_store.append(search_obj)
                self._build_nested_scores(search_obj)
                self.model_names.append(type(self.search_obj_store[-1].best_estimator_.named_steps.estimator).__name__)

    def _run_voting_estimator(self):

        if self.overall is False:  # no different algorithms, a VotingEstimator makes no sense...
            estimators = [(name, obj.best_estimator_) for (name, obj) in zip(self.model_names, self.search_obj_store)]
            est = self.voting_estimator[0].pop('estimator')[0]  # removes 'estimator' instance from voting_estimator
            est_name = type(est).__name__
            est.estimators = estimators  # adds best_models of each algorithm as estimator est
            grid = GridSearchCV(estimator=est, param_grid=self.voting_estimator, cv=self.cv.cv,
                                scoring=self.scoring.scoring,
                                n_jobs=-1, refit=True, return_train_score=True, verbose=1)  # fitting hyper-parameters
            grid.fit(X=self.X, y=self.y)
            self.best_models[est_name] = grid.best_estimator_  # add best VotingEstimator to best_models
            self._build_nested_scores(grid)  # calculates nested cv-score for new VotingEstimator
            self.model_names.append(est_name)

    def fit(self, X, y, **kwargs):
        """
        fit one or several hyper-tuned models
        :param X: pandas DataFrame or numpy array?
        :param y: pandas Series or numpy array?
        :param kwargs: multiple arguments to modify HyperParameterOptimizer-object (GridSearchCV)
        """
        self.fitting_time[0] = time.time()

        self.y = y
        self.X = X

        method_to_call = getattr(ms, self.hp_optimizer.hp_optimizer)
        self._run_cv(method_to_call, **kwargs)  # calculates cv incl nested cv-scores

        # build best_models
        self.best_models = {name: obj.best_estimator_ for (obj, name) in zip(self.search_obj_store, self.model_names)}

        if self.fitting_type == 'Classification':
            self.labels = list(self.best_models.get(self.model_names[0]).classes_)

        # adds best VotingEstimator to self.best_models if Estimator is picked in params
        if self.voting_estimator:
            self._run_voting_estimator()

        if self.fs_config:
            best_models = copy.deepcopy(self.best_models)
            self.feature_selector = self.FeatureSelector(models=best_models, cross_validation=self.cv, **self.fs_config)
            self.feature_selector.fit(self.X, self.y)

        self.fitting_time[1] = time.time()

    def store(self, file=None):
        if file is None:
            filename = 'model.joblib'
            file = os.path.join(os.getcwd(), filename)
        else:
            file = Path(file)
        try:
            dump(self, filename=file)
            print(f"model successfully stored in {file}")
        except FileNotFoundError as e:
            raise Exception(f"could not store model with this path: {e}")

    def predict(self, X):
        """
            calculates predictions
            :param X: pandas DataFrame with data to predict
            :return: return predictions as dictionary with name of algorithm as key and predictions as values
        """
        for name, model in self.best_models.items():
            self.predictions.update({name: self.best_models.get(name).predict(X=X)})
            try:
                self.probas.update({name: self.best_models[name].predict_proba(X=X)})
            except:
                self.probas.update(({name: None}))

    def get_predictions(self, type=None, security_level=None):
        """
        :param type: None (default) for dict with name of algorithm as key and prediction as values or
        'df' for pandas DataFrame
        :param security_level: float value between 0 and 1. Predictions for classifications with probabilities
        below security_level will be set to 'unknown'.
        :return: either dict or pandas DataFrame depending on type
        """

        predictions = copy.deepcopy(self.predictions)

        if self.fitting_type == 'Classification' and security_level is not None:
            if not isinstance(security_level, float) or (security_level > 1 or security_level < 0):
                raise Exception(f"security_level has to be of instance 'float' and it's value have to be between 0 and 1!")
            preds = pd.DataFrame.from_dict(predictions)
            probas = self.get_probabilities(type='max')
            for idx, item in enumerate(probas.columns):
                mask = probas[item] < security_level
                indices = mask[mask].index
                preds.iloc[indices, idx] = 'unknown'
            predictions = preds.to_dict(orient='list')

        if type is None:
            return predictions
        elif type == 'df':
            return pd.DataFrame.from_dict(predictions)

    def get_probabilities(self, type=None):
        """ returns dict with name of algorithm as key and an array of probabilities"""
        if type is None:
            return self.probas
        elif type == 'df':
            values = []
            for key, value in self.probas.items():
                if key not in ['VotingClassifier', 'DummyClassifier']:
                    values.append(value)
            arr = np.hstack(values)
            model_names = [i for i in self.model_names if i not in ['VotingClassifier', 'DummyClassifier']]
            labels =  list(itertools.product(model_names, self.labels))
            probas_df= pd.DataFrame(data=arr,columns=labels)
            return probas_df
        elif type == 'max':
            values = {}
            for key, value in self.probas.items():
                if key not in ['VotingClassifier', 'DummyClassifier']:
                    max = value.max(axis=1)
                    values.update({key: max})
            probas_max = pd.DataFrame.from_dict(values)
            return probas_max


    def get_config(self):
        # TODO: better str representation
        config = {'pipe': self.pipe, 'params': self.params, 'cv': self.cv,
                  'scoring': self.scoring, 'hp_optimizer': self.hp_optimizer, 'overall': self.overall,
                  'fs_config': self.fs_config}
        return config
