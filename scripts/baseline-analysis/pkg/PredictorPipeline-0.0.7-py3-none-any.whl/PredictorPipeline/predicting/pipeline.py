from sklearn.base import BaseEstimator
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, VotingClassifier
from sklearn.ensemble import RandomForestRegressor, AdaBoostRegressor, VotingRegressor
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler

# own transformers
from sklearn_custom.feature_selection.VarianceThreshold import VarianceThreshold
from sklearn_custom.imputers.SimpleImputer import SimpleImputer
from sklearn_custom.encoders.OneHotEncoder import OneHotEncoder
from sklearn_custom.encoders.OrdinalEncoder import OrdinalEncoder
from sklearn_custom.transformers.ColumnTransformer import ColumnTransformer
from sklearn_custom.preprocessing.MinMaxScaler import MinMaxScaler
from sklearn_custom.preprocessing.StandardScaler import StandardScaler
from sklearn_custom.transformers.SAXTransformer import SAX_Transformer


# tuple with model_params and base_params -> will build params_grid internally
params = (
    [{'prep__num__imputer__strategy': ['mean', 'median'],
      'prep__num_rest__imputer__strategy': ['mean', 'median']}
     ],

    [
        {'estimator': [KNeighborsClassifier()], 'estimator__n_neighbors': [1, 3],
         'estimator__weights': ['distance']},
        {'estimator': [RandomForestClassifier()], 'estimator__n_estimators': [200]},
        # {'estimator': [VotingClassifier(estimators=None)], 'estimator__voting': ['hard']},
        # {'estimator': [VotingClassifier(estimators=None)], 'estimator__voting': ['soft', 'hard'], 'estimator__weights': [(1,1,1), (2,1,2), (1,2,1)]},
        # {'estimator': [VotingRegressor(estimators=None)], 'estimator__weights': [(1, 1, 1), (2, 1, 1), (1, 0, 1)]},
        # {'estimator': [VotingClassifier(estimators=None)], 'estimator__weights':
        #    [({'weightGrid': {'fraction': 0.1, 'max_no_weights': 5}}), (1,1,1), (1,2,3)]},
        #  'estimator__voting':  ['hard']},
        {'estimator': [VotingClassifier(estimators=None, voting='hard')]}
        # {'estimator': [AdaBoostClassifier()], 'estimator__learning_rate': [0.001, 0.01, 0.05]}
        # {'estimator': [VotingRegressor(estimators=None)], 'estimator__weights':
        #    [(1,1,), (1,2), (2,1)]},
    ]
)

pipe = Pipeline(steps=[('prep',
                        ColumnTransformer(transformers=[('num',
                                                         Pipeline(steps=[('imputer',
                                                                          SimpleImputer(df_out=True)),
                                                                         ('min_max',
                                                                          MinMaxScaler(df_out=True)),
                                                                         ]),
                                                         ['a', 'c']),

                                                        ('num_rest',
                                                         Pipeline(steps=[('imputer', SimpleImputer(df_out=True)),
                                                                         ('std_scaler', StandardScaler(df_out=True))]),
                                                         ['b', 'd', 'e']),
                                                        ],
                                          remainder='drop',
                                          n_jobs=-1)),
                       ('estimator', None),
                       ])

# ___ only estimator
# pipe = Pipeline([('estimator', None)])
#
# params = ([{}],
#           [{'estimator': [RandomForestClassifier()], 'estimator__n_estimators': [200,400]}])

# params = ([{}],
#           [{'estimator': [RandomForestClassifier()]}])

# ___  single pipeline
# pipe = Pipeline([
#     ('imputer', SimpleImputer()),
#     ('min_max', MinMaxScaler()),
#     ('zero_var', VarianceThreshold(threshold=(.95 * (1 - .95)))),
#     ('estimator', None)
# ])
#
# params = ([{'imputer__strategy': ['mean', 'median']}],
#           [{'estimator': [RandomForestClassifier()], 'estimator__n_estimators': [200, 300]}])

# ___ columns transformer
# pipe = Pipeline(steps=[('prep',
#                         ColumnTransformer(transformers=[('num',
#                                                          Pipeline(steps=[('imputer',
#                                                                           SimpleImputer()),
#                                                                          ('min_max',
#                                                                           MinMaxScaler()),
#                                                                          ]),
#                                                          ['a', 'b']),
#
#                                                         ('num_rest',
#                                                          Pipeline(steps=[('imputer', SimpleImputer()),
#                                                                          ('min_max', MinMaxScaler())]),
#                                                          ['c']),
#                                                         ],
#                                           remainder='drop',
#                                           n_jobs=-1)),
#                        ('estimator', None),
#                        ])
#
# params = ([
#               {'prep__num__imputer__strategy': ['mean', 'median'],
#                'prep__num_rest__imputer__strategy': ['mean', 'median']}
#           ],
#           [
#               {'estimator': [RandomForestClassifier()], 'estimator__n_estimators': [200, 300],
#                'estimator__max_features': ["auto", "sqrt"]}
#           ]
# )


# SAX_PIPELINE

# params = (
#     [{
#         'prep__num_pipeline__imputer_num__strategy': ['mean', 'median'],
#     }],
#
#     [
#         {'estimator': [KNeighborsClassifier()], 'estimator__n_neighbors': [1, 5],
#          'estimator__weights': ['distance']},
#         {'estimator': [RandomForestClassifier()], 'estimator__n_estimators': [200]},
#         {'estimator': [VotingClassifier(estimators=None)], 'estimator__voting': ['hard']},
#     ]
# )
#
#
# # DEFINE: 'pipe'!
# # path_to_sax = self.obj.best_models['KNeighborsClassifier'].named_steps['prep'].named_transformers_['sax_pipeline'].named_steps.['sax']
# pipe = Pipeline(steps=[('prep',
#                         ColumnTransformer(transformers=[('num_pipeline',
#                                                          Pipeline(steps=[
#                                                              ('imputer_num', SimpleImputer(strategy='median')),
#                                                              ('min_max', MinMaxScaler()),
#                                                              ('zero_var', VarianceThreshold(threshold=(.95 * (1 - .95))))
#                                                          ]),
#                                                          ['age']
#                                                          ),
#
#                                                         ('sax_pipeline',
#                                                         Pipeline(steps=[
#                                                             ('sax', SAX_Transformer(n_letters=2, n_length=2,
#                                                                           scaler='z_all',
#                                                                           thresholds={'Troponin': [2]},
#                                                                           cat_ordered=False)),
#                                                             ('imputer_sax', SimpleImputer(strategy='constant', fill_value='MISSING',
#                                                                          df_out=True)),
#                                                             ('oh', OneHotEncoder(sparse=False, df_out=True, new_cats=True,
#                                                                                fill_value='MISSING', drop='first'))
#                                                         ]),
#                                                          ['Crp_1', 'Crp_2', 'Crp_3', 'Crp_4', 'Troponin_1', 'Troponin_2', 'Troponin_3', 'Troponin_4']
#                                                          ),
#                                                         ],
#                                           remainder='drop',
#                                           n_jobs=-1)),
#                        ('estimator', None),
#                        ])

