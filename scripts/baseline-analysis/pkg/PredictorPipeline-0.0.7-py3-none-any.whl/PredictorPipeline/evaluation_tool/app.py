from flask import render_template
from evaluation_tool import app


@app.route('/')
def home():
    return render_template('home.html')


if __name__ == '__main__':

    app.run(debug=True, port=5002)
