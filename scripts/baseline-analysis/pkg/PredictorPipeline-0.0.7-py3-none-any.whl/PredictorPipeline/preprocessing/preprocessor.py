import os
import pandas as pd
import numpy as np
from pprint import pformat
from pathlib import Path
from datetime import datetime
from pandas.api.types import CategoricalDtype
import sys
import math
from functools import wraps
import json
from itertools import count
from joblib import dump

from misc.df_plotter.matrix_plotter import MatrixPlotter
from misc.df_plotter.mv_plotter import MissingValuePlotter
from misc.df_plotter.column_plotter import ColumnPlotter
from misc.df_plotter.type_plotter import TypePlotter
from misc.df_plotter.box_plotter import BoxPlotter


# log = True/False
# log_modes = (io, files, details, summary)
# each function can overwrite behavior of global log_modes

class Preprocessor:

    _ids = count(0)  # counts number of instances (for naming logger instances)

    def __init__(self, df, log=True, path=None, log_modes=('io', 'summary', 'details', 'files'), show_no_entries='all'):
        """
        'preprocessing' is a class which helps preprocessing and logging pandas data.frame. The behaviour of 'log' and
        'log_modes' can be overridden be each method. Before a method is called it's own Validator is activated and
        returns a dictionary of same length and with same items as in input of according method. Each method returns a
        dictionary that is used for logging-reasons. The real modification will take place in the corresponding method
        itself.

        Args:
            df: pandas DataFrame
            log: boolean (default: True)
            path: path as string (for log instance). If path is None actual working directory will be taken and a
            folder 'log' is build
            log_modes: one or more out of 'io', 'summary', 'details', 'files' as tuple
            show_no_entries: int or 'all' (default) to show according number of items in logging
        """

        id_count = next(self._ids)  # counts number of instances
        self.validator = Validator(obj=self)  # validates input-values and correct/adjusts them if possible
        self.logger = Logger(obj=self, log=log, path=path, log_modes=log_modes,
                             show_no_entries=show_no_entries, id_count=id_count)

        if isinstance(df, pd.DataFrame):
            self.df_actual = df.copy()  # actual df
            self.df_original = df.copy()  # original df (unchanged)
            self.df_step = df.copy()  # stores pre-last processed DataFrame
        else:
            raise Exception("df has to by an instance of pd.DataFrame!")

        self.last_called_function = None  # name of last called function (by decorator)
        self.called_functions = []  # stores names of each function applied in correct order (for comparing df's)
        self.df_development = []  # stores actual df after each transformation (for comparing df's)
        self.input = {}  # stores updated/validated inputs of called function
        self.output = {}  # stores generated output for logging reason (will be used in Logger.details)
        self.columns = {}  # stores which columns are found and which are not found to apply given method

    def store(self, path=None):
        """
        stores instance as .joblib file
        :param path: path and filename (include .joblib) or None
        """
        if path is None:
            path = Path(self.logger.get_path(), 'preprocessor.joblib')
            dump(self, path)
        else:
            try:
                dump(self, path)
            except FileNotFoundError:
                print(f"Couldn't find directory")

    # decorator
    def call_function(fn):
        @wraps(fn)
        def call_function_intern(self, *args, **kwargs):
            self.df_step = self.df_actual.copy()  # stores actual df before applying function (difference Plotter)
            self.last_called_function = fn.__name__
            # gets a validated/updated input dictionary with parameters of same length as original
            self.input = self.validator.input(self.last_called_function,
                                              **kwargs)  # returns all input parameters as dictionary
            log, log_modes = self.logger.get_function_log_and_log_modes(**kwargs)
            show_no_entries = self.logger.get_no_entries(**kwargs)

            # function-call
            self.output = fn(self, *args, **self.input)  # output is a dictionary with all output for logging reasons

            self.called_functions.append(self.last_called_function)
            self.df_development.append(self.df_actual)

            if log:
                self.logger.logging(self.last_called_function, log_modes, show_no_entries)

            self.columns = {}  # reset columns
            return None

        return call_function_intern

    @staticmethod
    def _combine_features(x, mode):
        """
        Args:
            x: pandas Series of various number of columns (cells)
            mode: one out of ['binary']

        Returns: value of combined feature cell
        """
        if mode == 'binary':
            if 1 in x.values:
                return 1
            elif math.isnan(sum(x.values)):
                return np.nan
            else:
                return 0
        else:
            return x

    def _calc_grouped_summary(self, group):
        grouped_summary = []
        grouped_data = self.df_actual.groupby(group)
        for gr, data in grouped_data:
            df = data.agg(['count', 'size']).T
            df['group'] = gr
            df['na_fraction'] = 1 - (df['count'] / df['size'])
            grouped_summary.append(df)
        df = pd.concat(grouped_summary)
        df.sort_index(axis=0, inplace=True)
        return df


    @call_function
    def fetch_duplicates(self, axis=0, mode='drop', **kwargs):
        """ shows/drops duplicated rows (axis=0) or columns (axis=1)
        :param axis: 0 (default) looks for duplicated rows and 1 looks for duplicated columns
        :param mode: one out of ['drop' (default), 'show']
        :param kwargs: keep = 'first', 'last', False (drops all duplicated rows/columns)
        :return: pandas DataFrame with optionally removed duplicated rows/columns
        """
        drops = None

        if axis == 1:  # columns
            df = self.df_actual.T
            duplicates = df[df.duplicated(keep=False)].T
        else:  # rows
            df = self.df_actual
            duplicates = df[df.duplicated(keep=False)]

        # sort duplicated
        # groups = []
        # if duplicates.shape != (0,0):
        #     for item in duplicates.columns:
        #         all(duplicates.iloc[:, 0] == duplicates.iloc[:, 2])

        if mode == 'drop':
            if axis == 1:
                drops = df[df.duplicated(**kwargs)].T
                self.df_actual = df.drop_duplicates(**kwargs).T
            else:
                drops = df[df.duplicated(**kwargs)]
                self.df_actual = df.drop_duplicates(**kwargs)

        return {'duplicates': duplicates, 'drops': drops}


    # OKAY / TESTED
    @call_function
    def rename_columns(self, rename_dict, **kwargs):
        """
        renames column names of dataframe
        Args:
            rename_dict: a dictionary with old column-name asa key and new column-name as value
            log: boolean (default: None). 'log' can override the class behaviour for this method
            log_modes: tuple (default: None) with one or more values of 'io', 'summary', 'details', 'files'.
            local 'log_modes' overwrites class behavior for this method
        """

        if rename_dict:
            cols_found = [i for i in list(rename_dict.keys()) if i in self.df_actual.columns]
            cols_not_found = [i for i in list(rename_dict.keys()) if i not in self.df_actual.columns]
            self.columns.update({'columns not found': cols_not_found, 'columns found': cols_found})
            rename_dict_mod = {your_key: rename_dict[your_key] for your_key in cols_found}
            self.df_actual.rename(columns=rename_dict_mod, inplace=True)

        return {'columns names before': self.df_step.columns.to_list(),
                'columns names after': self.df_actual.columns.to_list()}

    # OKAY / TESTED
    @call_function
    def arrange_columns(self, mode='alpha', **kwargs):
        """
        arranges columns in DataFrame alphabetically, reversed alphabetically, by type, original or by list
        Args:
            mode: one out of 'alpha', 'alpha_rev', 'original', 'type' or a list or sublist with column-names
            log: boolean (default: None). 'log' can override the class behaviour for this method
            log_modes: tuple (default: None) with one or more values of 'io', 'summary', 'details', 'files'.
                local 'log_modes' overwrites class behavior for this method
        """

        colnames = self.df_actual.columns.to_list()
        if mode == 'alpha':
            sorted_colnames = sorted(colnames)

        elif mode == 'alpha_rev':
            sorted_colnames = sorted(colnames, reverse=True)

        elif mode == 'original':
            original_colnames = self.df_original.columns.to_list()
            existing_colnames = [i for i in self.df_actual if i in original_colnames]
            additional_colnames = [i for i in self.df_actual if i not in original_colnames]
            sorted_colnames = existing_colnames + additional_colnames

        elif mode == 'type':
            cols = self.df_actual.columns.to_list()
            type = [str(i) for i in self.df_actual.dtypes.to_list()]
            df = pd.DataFrame({'cols': cols,
                               'type': type})

            df.sort_values(by=['type', 'cols'], inplace=True)
            sorted_colnames = df['cols'].values.tolist()

        else:  # in case of list
            colnames = [i for i in mode if i in self.df_actual.columns]
            sorted_colnames = colnames + self.df_actual.drop(colnames, axis=1).columns.to_list()

        # arrange columns
        self.df_actual = self.df_actual[sorted_colnames]

        return {'old order': [i for i in self.df_step.columns], 'new_order': [i for i in self.df_actual.columns]}

    @call_function
    def drop_columns(self, cols=None, startswith=None, endswith=None, contains=None, empty=None, thresh=None,
                     group=None, thresh_gap=None, coltype=None, method='drop', **kwargs):
        """
        drops certain column by name or type
        :param method: one out of 'drop' (default) or 'show'. In case of 'show' the features will only be showed
        (returned) and not dropped
        :param cols: list of columns names to be dropped. exp: cols = ['ID', 'code']
        :param startswith: str. exp: startswith = "co"
        :param endswith:  str. exp: endswith = "co"
        :param contains:  str. exp: contains = "co"
        :param empty: bool,
        :param thresh: float: maximal fraction missing values or int (0, shape(df)): maximal number missing values
        :param group: combination with thresh. If thresh is defined as float and group is defined
         (as categorical column) the given 'thresh' is applied on defined group (subgroup)
        :param thresh_gap: combination with group. Excludes these columns where fraction of missing values between
         these groups is larger than 'thresh_gap'
        :param coltype:
        :param kwargs:
        :return:

        >> exp: drop_columns(thresh_gap=0.1, group='feature1')
        """

        columns_to_drop = None
        columns_not_found = None
        additional_info = None

        if cols:
            columns_to_drop = [i for i in cols if i in self.df_actual.columns]
            columns_not_found = [i for i in cols if i not in self.df_actual.columns]
        if startswith:
            columns_to_drop = [i for i in self.df_actual.columns if i.startswith(startswith)]
        if endswith:
            columns_to_drop = [i for i in self.df_actual.columns if i.endswith(endswith)]
        if contains:
            columns_to_drop = [i for i in self.df_actual.columns if contains in i]
        if empty:
            columns_to_drop = [i for i in self.df_actual.columns if self.df_actual[i].isnull().all()]

        if thresh:
            if group is None:
                if isinstance(thresh, float):
                    thresh = np.floor(thresh * self.df_actual.shape[0])
                columns_to_drop = [i for i in self.df_actual.columns if self.df_actual[i].isnull().sum() >= thresh]
            else:
                df = self._calc_grouped_summary(group=group)
                if isinstance(thresh, float):
                    columns_to_drop = list(set(df[df['na_fraction'] >= thresh].index.to_list()))
                elif isinstance(thresh, int):
                    columns_to_drop = list(set(df[df['size']-df['count'] >= thresh].index.to_list()))
                additional_info = df[df['na_fraction'] >= thresh]

        if thresh_gap is not None:
            if group is not None:
                df = self._calc_grouped_summary(group=group)
                if isinstance(thresh_gap, int):
                    df_mod = df['count'].max(level=0) - df['count'].min(level=0)
                else:
                    df_mod = df['na_fraction'].max(level=0) - df['na_fraction'].min(level=0)
                columns_to_drop = df_mod[df_mod >= thresh_gap].index.to_list()
                additional_info = df_mod.to_frame()
                additional_info = additional_info[additional_info.iloc[:, 0] >= thresh_gap]
                additional_info.columns = [f"{additional_info.columns.to_list()[0]}_gap"]

        if coltype is not None:
            keep_columns = self.df_actual.select_dtypes(include=coltype[1]).columns.to_list()
            if coltype[0] == 'include':
                columns_to_drop = [i for i in self.df_actual.columns if i not in keep_columns]
            else:
                columns_to_drop = [i for i in self.df_actual.columns if i in keep_columns]

        if method == 'show':
            return {'columns to drop (only shown!)': columns_to_drop, 'columns not found': columns_not_found,
                    'additional info': additional_info}
        else:
            if columns_to_drop:
                self.df_actual.drop(columns_to_drop, axis=1, inplace=True)  # dropping specified columns

            return {'columns to drop': columns_to_drop, 'columns not found': columns_not_found,
                    'additional info': additional_info}

    @call_function
    def replace_values(self, pattern, value=np.nan, columns=None, column_type=None, **kwargs):
        """
        replaces given string-pattern with value and logs occurrences per column/row
        Args:
            log_modes:
            log: boolean, should method be logged?
            pattern: list of string pattern to be replaced with value
            value: value to be used for replacement (default: np.nan)
            columns: list of column names to be treated with function
            column_type: list of column_types to be treated ['numerics', 'object', 'category', 'date']
        """

        if columns is not None:
            cols = [col for col in self.df_actual.columns if col in columns]
        else:
            cols = self.df_actual.columns.to_list()  # all columns if nothing is specified

        if column_type is not None:
            cols_temp = []
            for item in column_type:
                if item in ['numerics', 'object', 'category', 'date']:
                    if item == 'numerics':
                        types = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
                    else:
                        types = item
                    selected_type_cols = self.df_actual.select_dtypes(include=types).columns.to_list()
                    intercept = [i for i in selected_type_cols if i in cols]
                    cols_temp.append(intercept)
            cols = [item for sublist in cols_temp for item in sublist]  # flatten list

        if cols:
            # applies replacement and gives back statistics of occurrences
            no_cell_level, no_global = self._replacements(cols, pattern, value)

        return {'no_cell_level': no_cell_level, 'no_global': no_global}

    @call_function
    def convert_column_type(self, columns_dict, **kwargs):
        """

        Args:
            columns_dict:
            log:
            log_modes:
            **kwargs:

        Returns:

        """
        if columns_dict:
            columns_dict_mod = {i: columns_dict[i] for i in columns_dict.keys() if
                                i in self.df_actual.columns}

        cols_found = list(columns_dict_mod.keys())
        cols_not_found = [i for i in list(columns_dict.keys()) if i not in self.df_actual.columns]

        self.columns.update({'columns found': cols_found, 'columns not found': cols_not_found})

        introduced_na = {}  # stores number of missing values per column

        for key, value in columns_dict_mod.items():

            no_na_before = self.df_actual[key].isna().sum()  # number of missing values before conversion

            if value[0] in ['numeric']:
                self.df_actual[key] = pd.to_numeric(self.df_actual[key], errors='coerce')

            if value[0] in ['date']:
                if 'date_format' not in kwargs:  # default value if nothing is supported
                    date_format = '%Y-%m-%d'
                else:  # value if 'date_format' is supported as parameter
                    date_format = kwargs['date_format']
                if value[1] != '':  # value if a value for a specific column is supported in tuple
                    date_format = value[1]
                self.df_actual[key] = pd.to_datetime(self.df_actual[key], format=date_format, errors='coerce')

            if value[0] in ['category', 'category_ordered']:
                if value[1] != '':
                    categories = value[1]
                    if value[0] == 'category':
                        cat_type = CategoricalDtype(categories=categories, ordered=False)
                    else:
                        cat_type = CategoricalDtype(categories=categories, ordered=True)
                else:
                    cat_type = CategoricalDtype(ordered=False)
                self.df_actual[key] = self.df_actual[key].astype(cat_type, errors='ignore')

            no_na_after = self.df_actual[key].isna().sum()  # number of missing values after conversion
            if no_na_before != no_na_after:
                introduced_na[key] = no_na_after - no_na_before

        type_before = self.df_step[cols_found].dtypes.to_dict()
        type_after = self.df_actual[cols_found].dtypes.to_dict()

        # build a single dict with values before/after
        ds = [type_before, type_after]
        before_after = {}
        for k in type_before.keys():
            before_after[k] = tuple(d[k] for d in ds)

        return {'introduced nas': introduced_na, 'object type before/after transformation': before_after}

    @call_function
    def combine_features(self, combine_dict, mode='binary', drop=True, **kwargs):
        """
        combines two or more features to one new feature. At the moment only binary features can be handled.
        combine_dict: dict with name of new category as key and column-names of features to apply
        exp. {'allergies': ['allergy_pokarmowa', 'allergy_pollen_gras_hair_mites', 'other_allergy'],
              'CVD': ['heart_failure', 'coronary_artery_disease', 'atrial_fibrillation']},
        drop: boolean (default: True), should original features be dropped?
        mode: one out of ['binary']   # TODO: sum, max (num not num) etc.
        """

        cols_found = [item for sublist in combine_dict.values() for item in sublist if
                      item in self.df_actual.columns]
        cols_not_found = [item for sublist in combine_dict.values() for item in sublist if
                          item not in self.df_actual.columns]

        modified_combine_dict = combine_dict.copy()

        if cols_not_found:  # drop columns that are not in self.df.columns etc. (update dict)
            for col in cols_not_found:
                for key, value in modified_combine_dict.items():
                    if col in value:
                        modified_combine_dict.update({key: [i for i in value if i not in cols_not_found]})

        empty = []
        for key, value in modified_combine_dict.items():
            if len(value) == 0:
                empty.append(key)

        for item in empty:
            del modified_combine_dict[item]

        if mode == 'binary':
            for col in cols_found:
                if not np.issubdtype(self.df_actual[col].dtype, np.number):
                    raise Exception(f"Column '{col}' seems not to be numeric! (mode='binary')")
                invalid_values = [i for i in self.df_actual[col] if i not in [0, 1] and str(i) != 'nan']
                if invalid_values:
                    raise Exception(f"Column '{col}' seems to contain values differ from 0,1 or np.nan!")

        for key, value in modified_combine_dict.items():
            self.df_actual[key] = self.df_actual.loc[:, value].apply(self._combine_features, args=(mode,), axis=1)

        if drop:
            self.df_actual.drop(cols_found, axis=1, inplace=True)

        return {'combine_dict': combine_dict, 'combine_dict_modified': modified_combine_dict}

    # TODO: mistake! -> pattern!
    def _replacements(self, cols, pattern, value):

        no_occurrences = self.df_actual[cols].stack().value_counts().to_dict()
        nas = self.df_actual.isnull().sum().sum()
        no_global = {}

        # global occurrences
        for idx, pat in enumerate(pattern):
            for p in pat:
                if p is np.nan:
                    no_global[p] = nas
                else:
                    no_global[p] = no_occurrences.get(p)

        # occurrences on cell level
        no_cell_level = []
        for idx, pat in enumerate(pattern):
            for col in self.df_actual[cols]:
                # temp_replacements = []
                no_occurrences = self.df_actual[col].value_counts()
                nas = self.df_actual[col].isnull().sum()
                occurrences = no_occurrences.index.to_list()
                intersect = [val for val in occurrences if val in pat]

                if nas > 0 and np.nan in pat:
                    no_cell_level.append(f"replaced {nas} 'np.nan' in column '{col}' with '{value[idx]}'")
                    self.df_actual[col] = self.df_actual[col].fillna(value[idx])

                if len(intersect) > 0:
                    for item in intersect:
                        no_cell_level.append(
                            f"replaced {no_occurrences[item]} '{item}' in column '{col}' with '{value[idx]}'")
                        self.df_actual[col] = self.df_actual[col].replace(item, value[idx])

        return no_cell_level, no_global

        # OKAY

    def get_summary(self, type='category', sort=None):
        """ returns a summary of the actual data frame with all columns and its types
        Args:
            type: one out of ['category'] as string
            sort: a tuple with (column-name, boolean) with a valid column-name out of ['names', 'types', 'categories']

        Returns: a pandas DataFrame with a summary of the actual data
        """

        # functionname = inspect.stack()[0][3]
        # sort_mod = self.validator.input(functionname, sort=sort)
        sort_mod = None

        if type == 'category':

            df = pd.DataFrame({'names': self.df_actual.columns.to_list(),
                               'types': [str(i) for i in list(self.df_actual.dtypes)]})

            # add categories for categorical columns, min and max for numerical columns and number of missing values
            cats, min, max, mean, median, std, na, non_na = [], [], [], [], [], [], [], []

            for idx, item in df.iterrows():
                if df.loc[idx, 'types'] == 'category':
                    cats.append(str(list(self.df_actual[item['names']].dtypes.categories)))
                else:
                    cats.append("")
                if df.loc[idx, 'types'] in ['int64', 'float64']:
                    min.append(self.df_actual[item['names']].min(skipna=True))
                    max.append(self.df_actual[item['names']].max(skipna=True))
                    mean.append(self.df_actual[item['names']].mean(skipna=True))
                    median.append(self.df_actual[item['names']].median(skipna=True))
                    std.append(self.df_actual[item['names']].std(skipna=True))
                else:
                    min.append(np.nan)
                    max.append(np.nan)
                    mean.append(np.nan)
                    median.append(np.nan)
                    std.append(np.nan)
                na.append(self.df_actual[item['names']].isna().sum())
                non_na.append(self.df_actual[item['names']].count())

            df['categories'] = cats
            df['max'] = max
            df['min'] = min
            df['mean'] = mean
            df['median'] = median
            df['std'] = std
            df['na'] = na
            df['non_na'] = non_na

            if sort_mod is not None:
                df.sort_values(sort_mod[0], ascending=sort_mod[1], inplace=True)

        return df

    @call_function
    def log_summary(self, **kwargs):
        df = self.get_summary(**kwargs)
        return {'summary': df}

    def get_plot(self, type="ColumnPlotter", *args, **kwargs):
        plot = getattr(sys.modules[__name__], type)
        fig = plot(self.df_actual, *args, **kwargs).get_plot()
        return fig

    # OKAY
    def get_data(self, type='actual'):
        if type == 'actual':
            return self.df_actual
        if type == 'original':
            return self.df_original


class Validator:
    """
    validates input values and gives back the validated/updated version of the input as an dictionary
    or rises an Exception. Validator methods gets the same parameters as their original method and are returning a
    dictionary with the same updated/validated input parameters. Validator methods have same name as their opposite
    original methods but a leading '_'
    """

    def __init__(self, obj):
        self.obj = obj

    def input(self, functionname, **kwargs):
        # get all methods (without dunder-methods) of class Validator
        object_methods = [method_name for method_name in dir(self)
                          if callable(getattr(self, method_name)) and not method_name.endswith('__')]

        if f"_{functionname}" in object_methods:
            return getattr(self, f"_{functionname}")(**kwargs)
        else:
            return {**kwargs}

    @staticmethod
    def _combine_features(**kwargs):
        if not isinstance(kwargs['combine_dict'], dict):
            raise Exception("combine_dict has to be of type dict!")
        for key, value in kwargs['combine_dict'].items():
            if not isinstance(key, str):
                raise Exception("keys in 'combine_dict' have to be of type str")
            if not isinstance(value, list):
                raise Exception("values in 'combine_dict' have to be of type list")
        return {'combine_dict': kwargs['combine_dict'], 'mode': kwargs['mode']}

    @staticmethod
    def _rename_columns(rename_dict, **kwargs):
        if not isinstance(rename_dict, dict):
            raise Exception("rename_dict has to be of type dict!")
        return {'rename_dict': rename_dict, **kwargs}

    @staticmethod
    def _arrange_columns(mode='alpha', **kwargs):
        if not isinstance(mode, str):
            if not isinstance(mode, list):
                raise Exception(f"mode has to be of type 'str' or of type 'list'")
        else:
            if mode not in ['alpha', 'alpha_rev', 'type', 'original']:
                raise Exception(f"mode has to be one out of 'alpha', 'alpha_rev', 'type', 'original'")
        return {'mode': mode, **kwargs}

    @staticmethod
    def _combine_features(combine_dict, mode='binary', drop=True, **kwargs):
        if not isinstance(combine_dict, dict):
            raise Exception("combine_dict has to be of type dict!")
        for key, value in combine_dict.items():
            if not isinstance(key, str):
                raise Exception("keys in 'combine_dict' have to be of type str")
            if not isinstance(value, list):
                raise Exception("values in 'combine_dict' have to be of type list")
        if mode != 'binary':
            raise Exception(f"only mode='binary' is supported at the moment...")
        if not isinstance(drop, bool):
            raise Exception(f"drop parameter has to be of type 'bool'")
        return {'combine_dict': combine_dict, 'mode': mode, 'drop': drop, **kwargs}

    @staticmethod
    def _replace_values(pattern, value=np.nan, columns=None, column_type=None, **kwargs):

        if not isinstance(pattern, list) and isinstance(value, list):
            raise Exception(f"'pattern' and 'value' have to be of type list")

        if len(pattern) != len(value):
            raise Exception(f"length of 'pattern' and 'value' does not correspond!")

        pattern_list_of_list = [all(isinstance(i, list) for i in pattern)][0]
        if not pattern_list_of_list:
            raise Exception(f"input does not fit desired format!")
        else:
            return {'pattern': pattern, 'value': value, 'columns': columns, 'column_type': column_type, **kwargs}

    @staticmethod
    def _convert_column_type(columns_dict, **kwargs):
        if not isinstance(columns_dict, dict):
            raise Exception("columns_dict has to be of type dict!")

        update = [(i,) if isinstance(i, str) else i for i in
                  columns_dict.keys()]  # update key to tuple if it's a single string
        columns_dict = dict(zip(update, list(columns_dict.values())))

        for item in columns_dict.values():
            if not isinstance(item, tuple) or len(item) != 2:
                raise Exception("values of 'column_dict' have to be tuples of length 2 "
                                "(exp: ('category', ['1', '2', '3'])")

        # build a new column_dict with 'unsplit' keys
        columns_dict_new = {}
        for key, value in columns_dict.items():
            zipped = zip(key, (value,) * len(key))
            for item in zipped:
                columns_dict_new[item[0]] = item[1]

        return {'columns_dict': columns_dict_new, **kwargs}

    @staticmethod
    def _get_summary(type='category', sort=None, **kwargs):
        if sort is not None:
            if not isinstance(sort, tuple):
                raise Exception("'sort=' has to by of type 'tuple' ('column-name', True/False) with"
                                " a valid column-name out of ['names', 'types', 'categories', 'min', 'max', 'na']")
            if not (1 <= len(sort) <= 2):
                raise Exception("'sort=' has to be a tuple of length 1 or 2")
            if sort[0] not in ['names', 'types', 'categories', 'min', 'max', 'na']:
                raise Exception("first value in 'sort=' tuple has to be one of ['names', 'types', 'categories', "
                                "'min', 'max', 'na']")
            if len(sort) == 2 and not isinstance(sort[1], bool):
                raise Exception("second value in tuple 'sort=' has to be a boolean for ascending sorting")
        return {'type': type, 'sort': sort, **kwargs}

    # @staticmethod
    def _drop_columns(self, cols=None, startswith=None, endswith=None, contains=None, empty=None, thresh=None,
                      group=None, thresh_gap=None, coltype=None, method='drop', **kwargs):

        valid_params = ['cols', 'startswith', 'endswith', 'contains', 'empty', 'thresh', 'thresh_gap', 'coltype']
        saved_args = locals()
        to_drop = {}

        for item in valid_params:
            if saved_args[item] is not None:
                to_drop.update({item: saved_args[item]})
        if len(to_drop) > 1:
            raise Exception(
                f"you can only choice one out of ['startswith', 'endswith', 'contains', 'empty', 'cols', "
                f"'thresh', 'thresh_gap', 'coltype']")

        if 'drop' in to_drop:
            if not isinstance(to_drop['empty'], bool):
                raise Exception(f"argument in parameter 'empty' has to be of type 'bool'")

        if 'thresh' in to_drop or 'thresh_gap' in to_drop:

            if 'thresh' in to_drop:
                item = 'thresh'
            else:
                item = 'thresh_gap'

            if not (isinstance(to_drop[item], int) or isinstance(to_drop[item], float)):
                raise Exception(f"'{item}' has to be of type 'float' or 'int' (given: {type(to_drop[item])})")
            if isinstance(to_drop[item], float):
                if not (0 < to_drop[item] < 1):
                    raise Exception(f"'{item}' has to be a float between 0 and 1 (given: {to_drop[item]})")
            if isinstance(to_drop[item], int):
                if to_drop[item] < 0:
                    raise Exception(f"'{item}' can't be smaller than 0 (given: {to_drop[item]})")
            if item == 'thresh_gap':
                if group is None:
                    raise Exception(f"group can't be None in combination with 'thresh_gap'!")

        if 'coltype' in to_drop:
            if not isinstance(coltype, tuple):
                raise Exception(f"parameter 'coltype' has to be of type 'tuple' exp. type = ('include', 'number')")
            if len(coltype) != 2:
                raise Exception(f"argument in parameter 'coltype' has to be a tuple of length 2")
            if coltype[0] not in ['include', 'exclude']:
                raise Exception(f"first argument in tuple 'type' has to be one out of ['include', 'exclude']")
            if isinstance(coltype[1], list):  # or coltype[1] not in ['number', 'object', 'datetime', 'category']:
                vals = all([True for i in coltype[1] if i in ['number', 'object', 'datetime', 'category']])
                if vals is False:
                    raise Exception(f"second argument in tuple 'type' has to be one out of "
                                    f"['number', 'object', 'datetime', 'category'] or a list of these items")
            if isinstance(coltype[1], str):
                if coltype[1] not in ['number', 'object', 'datetime', 'category', 'float64', 'int64']:
                    raise Exception(f"second argument in tuple 'type' has to be one out of "
                                    f"['number', 'object', 'datetime', 'category', 'float64', 'int64'] or a list of these items")

        if method != 'drop':
            if method not in ['drop', 'show']:
                raise Exception(f"parameter 'method' has to be one out of 'drop' or 'show'")

        if group:
            if group not in self.obj.df_actual.columns:
                raise Exception(f"parameter 'group' has to be a valid column of df")

        return {'cols': cols, 'startswith': startswith, 'endswith': endswith, 'contains': contains, 'empty': empty,
                'thresh': thresh, 'group': group, 'thresh_gap': thresh_gap, 'coltype': coltype, 'method': method}

    def _get_summary(self, type='category', sort=None, **kwargs):
        return {'type': type, 'sort': sort, **kwargs}


class Logger:

    def __init__(self, obj, log, path, log_modes, show_no_entries, id_count):

        self.valid_modes = ['io', 'files', 'details', 'summary']
        self.obj = obj  # preprocessing-Object
        self.path = path
        self.file = None
        self.file_counter = 0
        self.id_count = id_count
        self.logger_name = f"preprocessor_{id_count}"
        self.indent = 16
        self.width = 200
        self.max_rows = 50  # for displaying pandas DataFrame
        self.max_columns = 20  # for displaying pandas DataFrame
        self.max_width = 120  # for displaying pandas DataFrame
        self.max_colwidth = 50  # for displaying pandas DataFrame

        self.log = self.initialize_log(log, id_count)
        self.log_modes = self.set_log_modes(log_modes)
        self.show_no_entries = self.set_no_entries(
            show_no_entries)  # how many items should be shown in 'details' if list/dict is long?

    @staticmethod
    def _get_actual_time():
        time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return time

    @staticmethod
    def set_no_entries(show_no_entries):
        if not isinstance(show_no_entries, int):
            if show_no_entries != 'all':
                raise Exception(f"'show_no_entries' have to be a positive integer or 'all' (for all entries)")
        return show_no_entries

    def set_logging_options(self, **kwargs):
        self.indent = kwargs.get('indent', 16)
        self.width = kwargs.get('width', 200)

        # pandas DataFrame
        self.max_rows = kwargs.get('max_rows', 50)
        self.max_columns = kwargs.get('max_columns', 20)
        self.max_width = kwargs.get('max_width', 120)
        self.max_colwidth = kwargs.get('max_colwidth', 50)

    def get_no_entries(self, **kwargs):
        if 'show_no_entries' not in kwargs:
            show_no_entries = self.show_no_entries
        else:
            show_no_entries = self.set_no_entries(kwargs['show_no_entries'])
        return show_no_entries

    def initialize_log(self, log, id_count):
        if not isinstance(log, bool):
            raise Exception("log has to be type 'bool'")
        if log:
            if not self.path:
                self.path = Path(os.getcwd()).joinpath('logs')
            if not os.path.exists(self.path):
                try:
                    os.mkdir(self.path)
                    self.file = f"{self.path}/preprocessor_{id_count}.log"
                except FileNotFoundError:
                    raise Exception(f"path {self.path} does not exist!")
            else:
                self.file = f"{self.path}/preprocessor_{id_count}.log"
        return log

    def get_function_log_and_log_modes(self, **kwargs):
        if 'log' not in kwargs:
            log = self.log
        else:
            log = self.initialize_log(kwargs['log'])
        if 'log_modes' not in kwargs:
            log_modes = self.log_modes
        else:
            log_modes = self.set_log_modes(kwargs['log_modes'])
        return log, log_modes

    def set_log_modes(self, log_modes):
        if not isinstance(log_modes, tuple):
            if isinstance(log_modes, str):
                log_modes = (log_modes,)
            else:
                raise Exception("log_modes have to by of type 'tuple'")

        log_modes = tuple([i for i in log_modes if i in self.valid_modes])
        return log_modes

    def _write_files(self, filename):
        filename_mod = f"{self.path}/{self.logger_name}_{filename}"
        self.obj.df_step.to_csv(f"{filename_mod}_{self.file_counter}.csv", index=False)
        self.file_counter += 1
        self.obj.df_actual.to_csv(f"{filename_mod}_{self.file_counter}.csv", index=False)
        self.file_counter += 1
        with open(self.file, 'a+') as f:
            f.write(f"\n\tlog_mode: 'files': \n"
                    f"\t\twrote files: "
                    f"'{filename_mod}_{self.file_counter - 2}.csv' and "
                    f"'{filename_mod}_{self.file_counter - 1}.csv'\n")

    def logging(self, functionname, log_modes, show_no_entries):

        with open(self.file, 'a+') as f:
            f.write(f"\n{self._get_actual_time()}: {functionname.upper()}\n")

        if 'io' in log_modes:
            with open(self.file, 'a+') as f:
                if show_no_entries != 'all':
                    f.write(f"\n\tlog_mode: 'io' (only {show_no_entries} items showed): \n")
                else:
                    f.write(f"\n\tlog_mode: 'io': \n")

                if self.obj.input:  # from preprocessing object
                    for key, value in self.obj.input.items():
                        value = self._shorten_container(value, show_no_entries)
                        f.write(f"\n\t\t{key}:\n")
                        f.write(f"\t\t{pformat(value, indent=self.indent, width=self.width)}\n")

        if 'details' in log_modes:
            with open(self.file, 'a+') as f:
                if show_no_entries != 'all':
                    f.write(f"\n\tlog_mode: 'details' (only {show_no_entries} items showed): \n")
                else:
                    f.write(f"\n\tlog_mode: 'details': \n")

                # columns found/not found
                if self.obj.columns:  # from validator object
                    for key, value in self.obj.columns.items():
                        f.write(f"\n\t\t{key} ({len(value)}):\n")
                        if key == 'columns not found':
                            f.write(f"\t\t{pformat(value, indent=self.indent)}\n")

                if self.obj.output:  # from preprocessing object
                    for key, value in self.obj.output.items():
                        value = self._shorten_container(value, show_no_entries)
                        f.write(f"\n\t\t{key}:\n")
                        if isinstance(value, pd.DataFrame):
                            pd.set_option('display.max_rows', self.max_rows,
                                          'display.max_columns', self.max_columns,
                                          'display.width', self.max_width,
                                          'display.max_colwidth', self.max_colwidth)
                            f.write(f"{pformat(value)}")
                        else:
                            f.write(f"\t\t{pformat(value, indent=self.indent, width=self.width)}\n")

        if 'summary' in log_modes:
            with open(self.file, 'a+') as f:
                f.write(f"\n\tlog_mode: 'summary': \n\n"
                        f"\t\tshape before applying '{functionname}': {self.obj.df_step.shape}\n"
                        f"\t\tshape after applying '{functionname}': {self.obj.df_actual.shape}\n")

        if 'files' in log_modes:
            self._write_files(functionname)

    @staticmethod
    def _convert_to_string(value):
        if isinstance(value, list):
            str_value = ", ".join(value)
        if isinstance(value, dict):
            str_value = json.dumps(value)
        return str_value

    @staticmethod
    def _shorten_container(container, length):
        if length != 'all':
            if isinstance(container, list):
                container_updated = [item for idx, item in enumerate(container) if idx <= math.floor(length / 2) or
                                     idx > len(container) - math.floor(length / 2)]
                container_updated.insert(math.floor(length / 2), '[...]')
            if isinstance(container, dict):
                container_updated = [(key, value) for idx, (key, value) in enumerate(container.items()) if
                                     idx <= math.floor(length / 2) or idx > len(container) - math.floor(length / 2)]
                container_updated = {key: value for key, value in container_updated}
            return container_updated
        else:
            return container

    def get_path(self):
        return self.path

if __name__ == '__main__':

    content = {'d': [0, 1, 1, 0, 0, 0, np.nan, np.nan, 0, 1],
               'a': [i for i in range(10)],
               'c': ['a', 'a', 'b', 'c', 'b', 'a', 'b', 'c', 'a', 'c'],
               'b': [0, 1, 0, 1, 0, 0, 0, 1, 0, np.nan]
               }
    df = pd.DataFrame(data=content)
    pp = Preprocessor(df=df, log=False)
    pp.rename_columns(rename_dict={'a': 'a_new', 'b': 'b_new'})
    print(pp.get_summary())