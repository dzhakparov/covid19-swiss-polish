from .preprocessing.preprocessor import Preprocessor
from .predicting.predictor import Model
from .evaluating.evaluator import ClassifierEvaluator, RegressionEvaluator
# from .evaluation_tool.app import app
# from .evaluation_tool.evaluation_tool.model_evaluation import views