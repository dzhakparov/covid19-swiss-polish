from sklearn import metrics


class Scorer:
    """
    calculates scoring metrics
    """

    def __init__(self, true_values, predictions, labels=None, name='train',
                 scoring_methods=['accuracy_score'], security_level=None, args=None):
        """
        :param true_values: np.array or pd.Series
        :param predictions: dict with name of algorithm as key and predictions as values (output of Model.predict())
        :param labels: labels as list of strings in case if classification problems else None
        :param scoring_methods: list of valid sklearn-scoring-methods.
            exp: 'accuracy_score', 'mean_absolute_error', ...
        :params security_level: float between 0 and 1 or None (default) in classification tasks. Predictions below
            securyty_level will be set to 'unknown'
        :param args: if a metric needs additional arguments it can be promoted by args parameters as dictionary.
            exp: 'args': {'precision_score': {'average': 'macro', 'pos_label': 'died'},
                          'recall_score': {'pos_label': 'died'}}
        """
        self.true_values = true_values
        self.predictions = predictions  # dict with name of algorithm as key and list of values as predictions
        self.scoring_methods = scoring_methods
        self.security_level = security_level
        self.args = args
        self.scores = {}
        self.scoring_algorithms = []
        self.name = name
        self.labels = labels

    def run(self):

        for item in self.predictions.keys():
            self.scoring_algorithms.append(item)
            y_pred = self.predictions[item]
            y_true = self.true_values.to_numpy()

            # drop 'unknown' from predictions and true values for calculating scores
            if self.security_level is not None:
                mask = [idx for idx, i in enumerate(self.predictions[item]) if i != 'unknown']
                y_pred = [i for idx, i in enumerate(y_pred) if idx in mask]
                y_true = [i for idx, i in enumerate(y_true) if idx in mask]

            result = {}
            add = {}
            for method in self.scoring_methods:
                if self.args is not None:
                    if method in self.args:
                        add = self.args[method]
                scoring_method = getattr(metrics, method)
                score = scoring_method(y_true, y_pred, **add)
                result.update({method: score})
            self.scores.update({item: result})

    def get_scores(self):
        """
        :return: dict of dict with algorithm name as outer key and metric name as inner key and scoring metrics as inner values
            exp: {'KNeighborsClassifier': {'mean_absolute_error': 0.395},
                  'RandomForestClassifier': {'mean_absolute_error': 0.37},
                  'VotingClassifier': {'mean_absolute_error': 0.4}}
        """
        return self.scores