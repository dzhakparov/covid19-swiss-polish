import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from sklearn.metrics import confusion_matrix
from PredictorPipeline.evaluating.helpers import Scorer
import numpy as np


def _check_scorer_list(scorer):
    if isinstance(scorer, Scorer):
        scorer = [scorer]
    else:
        if isinstance(scorer, list):
            validation = [isinstance(item, Scorer) for item in scorer]
            if not all(validation):
                raise ValueError('Parameter should be a Scorer or a list of Scorer')
        else:
            raise ValueError('Parameter should be a Scorer or a list of Scorer')
    return scorer


def _build_positions(no_plots, **kwargs):
    geometries = [{1: (1, 1)}, {2: (2, 1)}, {3: (2, 2)}, {4: (2, 2)}, {5: (3, 2)}, {6: (3, 2)}, {7: (3, 3)},
                  {8: (3, 3)}, {9: (3, 3)}, {10: (4, 3)}, {11: (4, 3)}, {12: (4, 3)}]

    if 'geometry' not in kwargs:
        geometry = geometries[no_plots - 1].get(no_plots)
    else:
        geometry = kwargs['geometry']
        if geometry[0] + geometry[1] < no_plots:
            geometry = geometries[no_plots - 1].get(no_plots)

    positions = []
    for i in range(geometry[0]):
        for j in range(geometry[1]):
            positions.append((i + 1, j + 1))
    return [positions, geometry]


def figure_metrics(scorer, sort='algorithm', **kwargs):
    """
    plots one or multiple Scorer-objects
    :param scorer: Object of class Scorer or list of Objects of class Scorer
    :param sort: one of 'algorithm' or 'metric'
    :param kwargs: y_range as list [0,1], geometry as tuple (2,2)
    :return:
    """
    COLORS = {'train': 'rgba(61, 153, 112, 1)', 'cv': '#FF4136', 'test': 'rgba(0, 102, 204, 1)',
              'importance': 'rgb(112,112,112)'}
    scorer = _check_scorer_list(scorer)

    # set colors
    colors = []
    for item in scorer:
        if item.name.lower() in COLORS.keys():
            colors.append(COLORS[item.name])  # TODO: define colors in case of false

    # define y-range of plot
    if 'y_range' not in kwargs:
        y_range = [0, 1]  # default
    else:
        if (isinstance(kwargs['y_range'], list) and len(
                kwargs['y_range']) == 2 and 0 <= kwargs['y_range'][0] < kwargs['y_range'][1] <= 1):
            y_range = kwargs['y_range']
        else:
            y_range = [0, 1]

    axis = [scorer[0].scoring_algorithms, scorer[0].scoring_methods]

    if sort == 'metric':
        axis[0], axis[1] = axis[1], axis[0]  # swap

    no_plots = len(axis[0])
    positions, geometry = _build_positions(no_plots, **kwargs)

    fig = make_subplots(rows=geometry[0],
                        cols=geometry[1],
                        start_cell="top-left",
                        subplot_titles=axis[0])

    for index, value in enumerate(axis[0]):
        for idx, item in enumerate(scorer):
            x = axis[1]
            if sort == 'algorithm':
                y = list(item.scores[value].values())
            else:
                y = [item.scores[i][axis[0][index]] for i in item.scores]

            fig.add_trace(go.Bar(name=f"{item.name} {value}", x=x, y=y,
                                 marker_color=colors[idx]),
                          row=positions[index][0], col=positions[index][1])

        fig['layout'][f'yaxis{index + 1}'].update(range=y_range, autorange=False)
    return fig


class ConfusionMatrix:

    def __init__(self, scorer):
        self.scorer = scorer
        self.matrix = {}

    def run(self, algorithms='all'):
        """
        :param algorithms: string or list of strings with valid algorithm names of which confusion matrix should be calculated
        :return: dict with confusion matrix as pandas DataFrame
        """
        for item in self.scorer.predictions.keys():
            if item in algorithms or algorithms == 'all':
                labels = self.scorer.labels
                conf_matrix = confusion_matrix(self.scorer.true_values.to_numpy(),
                                               self.scorer.predictions[item],
                                               labels=labels)
                conf_matrix = pd.DataFrame(conf_matrix, columns=list(labels), index=list(labels))
                self.matrix.update({item: conf_matrix})

    def __str__(self):
        string = ""
        for item in self.matrix:
            string = string + f"\n{item}:\n{self.matrix[item]}\n"
        return string

    def get_matrix(self):
        return self.matrix

    def _build_subtitles(self):
        subtitles = []
        for item in self.matrix:
            scores = self.scorer.scores[item]
            score_strings = []
            for key, score in scores.items():
                score_string = f"{key.replace('_score', '')} =  {round(score, 4)}"
                score_strings.append(score_string)
            score = ', '.join(score_strings)
            subtitle = f"<b>{item}</b> <br> {score}"

            if self.scorer.security_level is not None:
                no = len([i for i in self.scorer.predictions[item] if i != 'unknown'])
                fraction_unknowns = round((1 - (no / self.scorer.true_values.shape[0])) * 100, 2)
                subtitle = subtitle + f"  (security_level={self.scorer.security_level}; " \
                                      f"'unknown': {fraction_unknowns}%)"

            subtitles.append({'text': subtitle})
        return subtitles

    def plot(self, split="default", **kwargs):

        no_plots = len(self.matrix)
        positions, geometry = _build_positions(no_plots, **kwargs)

        fig = make_subplots(rows=geometry[0],
                            cols=geometry[1],
                            start_cell="top-left",
                            subplot_titles=list(self.matrix.keys())
                            )

        for idx, (key, data) in enumerate(self.matrix.items()):
            z = data.values
            labels = data.columns.to_list()

            fig.add_trace(go.Heatmap(
                z=z,
                x=labels,
                y=labels,
                colorscale='ylgn',
                showscale=False,
            ),
                row=positions[idx][0], col=positions[idx][1])

        fig.update_yaxes(dict(title='true value', autorange='reversed'))
        fig.update_xaxes(dict(title='predicted value'))

        fig.update_layout(title_text=f'<i><b>Confusion matrix: {split.upper()}</b></i>')
        subtitles = self._build_subtitles()
        fig.update_layout({'annotations': subtitles})
        return fig


def figure_model_evaluation(obj):
    x = obj.model_names
    y = [i.mean() for i in obj.nested_cv_scores]
    errors = [np.std(i) for i in obj.nested_cv_scores]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        # name='Control',
        x=x,
        y=y,
        error_y=dict(type='data', array=errors)
    ))
    fig.update_layout(barmode='group')
    return fig
