from datetime import datetime
import os
from PredictorPipeline.predicting.predictor import Model
from joblib import dump, load
from sklearn import set_config
from sklearn.utils import estimator_html_repr
import pandas as pd
from functools import reduce
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from PredictorPipeline.evaluating.plots import figure_metrics, figure_model_evaluation, ConfusionMatrix, \
    _build_positions
from PredictorPipeline.evaluating.helpers import Scorer
from sklearn_custom.transformers.SAXTransformer import SAX_Transformer
from abc import ABC, abstractmethod
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from pprint import pformat, pprint
from sklearn.model_selection import KFold
import copy


# TODO: add _build_positions and _check_scorer_list (from plots.py) to correct places in classes

class Evaluator(ABC):
    COLORS = {'train': 'rgba(61, 153, 112, 1)', 'cv': '#FF4136', 'test': 'rgba(0, 102, 204, 1)',
              'importance': 'rgb(112,112,112)',
              'algorithms': ['red', 'blue', 'green'],
              'scorers': ['grey', 'yellow', 'orange', 'sienna']}

    def __init__(self, obj, X_test=None, y_test=None, store_path=None, security_level=None):
        """
        :param obj: instance of Model or string to stored .joblib file of class Model ('path/filename.joblib')
        """
        self.obj = self._get_object(obj)
        self.store_path = self.set_store_path(store_path)
        self.security_level = security_level  # TODO: validate security_level
        self.overall_ranking_feature_selection = None  # pandas DataFrame
        self.no_splits = None

        self.X_train = self.obj.X
        self.y_train = self.obj.y
        self.X_test = X_test
        self.y_test = y_test
        self.scorers = self._build_scorers()

    class PipeCrawler:
        """
        crawls pipeline and returns different things like all used columns ...
        """

        def __init__(self, best_models):
            self.best_models = best_models
            self.colTrans = []
            self.pipelines = {}
            self.transformers = []

        def _search_used_transformers_and_features(self):
            # TODO: adjust for other Pipeline-designs
            transformers = []
            names = []
            for i in self.best_models[list(self.best_models.keys())[0]].steps:
                if isinstance(i[1], ColumnTransformer):
                    for j in i[1].transformers_:
                        if isinstance(j[1], Pipeline):
                            self.pipelines.update({j[0]: j[2]})
                            for k in j[1].steps:
                                try:
                                    # print({i[0]: {j[0]: {k[0]: k[1].__dict__}}})
                                    transformers.append(k[1].__dict__)
                                    names.append(f"{i[0]}_{j[0]}_{k[0]}")
                                except:
                                    # print({i[0]: {j[0]: {k[0]: k[1]}}})
                                    transformers.append(k[1])
                                    names.append(f"{i[0]}_{j[0]}_{k[0]}")

            self.transformers = list(zip(names, transformers))

        def get_used_features(self):
            if not self.pipelines:
                self._search_used_transformers_and_features()
            combined_features = [self.pipelines[key] for key in self.pipelines]
            flat_list = [item for sublist in combined_features for item in sublist]
            return flat_list

        def get_used_transformers(self):
            if not self.transformers:
                self._search_used_transformers_and_features()
            return self.transformers

    @staticmethod
    def set_store_path(store_path):
        if store_path is None:
            now = datetime.now()
            now = now.strftime("%Y-%m-%d_%H-%M-%S")
            store_path = os.path.join(os.getcwd(), 'evaluation_' + now)
            try:
                os.mkdir(store_path)
            except OSError:
                raise Exception("Creation of the directory %s failed" % store_path)
        else:
            if not os.path.isdir(store_path):
                raise Exception(f"can't find this path... {store_path}")
        return store_path

    def get_total_evaluation(self):
        self.get_graphical_pipelines()
        self.plot_metrics(sort='metric')
        self.plot_metrics(sort='algorithm')
        self.plot_model_evaluation()
        self.get_scores_overview()
        self.get_transformed_features(store=True)

        if self.obj.feature_selector is not None:
            self.get_excel_feature_selection()
            self.get_excel_overall_feature_selection()
            self.plot_overall_feature_selection()
            self.get_excel_overall_feature_selection(cv=False)
            self.plot_overall_feature_selection(cv=False)

    def get_graphical_pipelines(self, estimators=None):
        """
        stores an html-instance of processed pipelines
        :param estimators: list of strings with name of desired estimators. exp: ['RandomForestClassifier']
        :return: html-files of pipeline for according algorithm
        """
        set_config(display='diagram')
        store_path = self._build_path('graphical_pipeline')

        if estimators is None:
            estimator_list = [item for item in self.obj.search_obj_store]
        else:
            estimator_list = [item for item in self.obj.search_obj_store if
                              type(item.best_params_['estimator']).__name__ in estimators]

        if estimator_list:
            for item in estimator_list:
                name = type(item.best_params_['estimator']).__name__
                file_path = f"{store_path}/{name}.html"
                with open(file_path, 'w') as f:
                    f.write(estimator_html_repr(item.best_estimator_))

    def get_excel_feature_selection(self, algorithms=None):
        """
        :param algorithms: None (default) for all algorithm available or list of names of desired algorithms
        :return:
        """
        if self.obj.feature_selector.results:

            store_path = self._build_path('excel_feature_selection')
            algs = self._get_algorithms(algorithms)

            for algorithm in algs:
                path = os.path.join(store_path, f"{algorithm}.xlsx")
                fs = self.obj.feature_selector.results[algorithm]

                with pd.ExcelWriter(path=path) as writer:
                    for algorithm in fs:
                        res = pd.DataFrame.from_dict(fs[algorithm].get_metric_dict()).T
                        res.to_excel(writer, sheet_name=algorithm)

    def get_excel_overall_feature_selection(self, algorithms=None, cv=True):
        store_path = self._build_path('feature_overall_feature_selection')
        if cv:
            name = 'feature_overall_ranking_cv.csv'
        else:
            name = 'feature_overall_ranking.csv'
        path = os.path.join(store_path, name)
        self._build_excel_overall_feature_selection(algorithms=algorithms, cv=cv)
        self.overall_ranking_feature_selection.to_csv(path)

    def get_scores_overview(self):

        store_path = self._build_path('')

        results = []
        algorithms = list(self.scorers[0].scores.keys())
        columns = [['name'], ['split'], self.scorers[0].scoring_methods]
        columns = [item for sublist in columns for item in sublist]

        for item in self.scorers:
            values = []
            for algorithm in algorithms:
                values.append(list(item.scores[algorithm].values()))

            df = pd.DataFrame.from_records(values, columns=self.scorers[0].scoring_methods)
            df['name'] = algorithms
            df['split'] = item.name
            results.append(df)

        df = pd.concat(results)
        df = df[columns]

        name = 'scores_overview.csv'
        path = os.path.join(store_path, name)
        df.to_csv(path)

    def get_transformed_features(self, data=None, store=False):
        """
        builds transformed features per algorithm based on train data (without estimator)
        :param data: if None (default) X-train will be transformed, if data is not None this data will be transformed
        :param store: boolean. If store is True nothing is returned but each pandas DataFrame is stored as .csv-file in
            a new builded folder
        :return: dict of pandas DataFrames (if store is False) or None (if store is True)
        """
        transformed_data = {}
        for algorithm in self.obj.best_models.keys():
            steps = self.obj.best_models[algorithm].steps[:-1]  # all steps without estimator as last step
            pipe = Pipeline(steps=steps)
            mod = pipe.fit(self.X_train)
            if data is None:
                transf_data = mod.transform(self.X_train)
            else:
                transf_data = mod.transform(data)
            transformed_data.update({algorithm: transf_data})

        if store is False:
            return transformed_data
        else:
            store_path = self._build_path('transformed_data')
            for algorithm, data in transformed_data.items():
                data.to_csv(f"{store_path}/transformed_data_{algorithm}.csv", index=True)

    def plot_overall_feature_selection(self, algorithms=None, cv=True):

        if self.obj.feature_selector.results:

            store_path = self._build_path('feature_overall_feature_selection')
            algs = self._get_algorithms(algorithms)

            self._build_excel_overall_feature_selection(algorithms=algs, cv=cv)

            if cv:
                name = f'overall_ranking_feature_selection_cv.html'
                fig = go.Figure([go.Bar(x=self.overall_ranking_feature_selection.index,
                                        y=self.overall_ranking_feature_selection[('score', 'mean')],
                                        error_y=dict(type='data', array=self.overall_ranking_feature_selection[
                                                                            ('score', 'std')] / np.sqrt(self.no_splits),
                                                     visible=True))])
                title = f"overall feature importance with standard error <br> algorithms = {algs}"

            else:
                name = f'overall_ranking_feature_selection.html'
                table = self.overall_ranking_feature_selection
                fig = go.Figure([go.Bar(x=table.index, y=table['score'])])
                title = f"<b>overall feature importance: algorithms = {algs}</b>"

            fig = self._update_layout(fig, title, yaxis_title='average score', xaxis_title='features')
            fig.write_html(f"{store_path}/{name}")
            return fig

    def plot_metrics(self, sort='metric', **kwargs):
        """
        plots metric of algorithms in scorers
        :param sort: 'metric' or 'algorithm' to define for what type the plots should be sorted
        """
        store_path = self._build_path('metrics_plots')
        fig = figure_metrics(self.scorers, sort=sort, y_range=[0, 1], **kwargs)
        title = f"<b>Predictions with different Classifiers ({sort})</b>"
        fig = self._update_layout(fig, title, yaxis_title='', xaxis_title='')
        fig.write_html(f"{store_path}/metric_plot_{sort}")

    def plot_model_evaluation(self, **kwargs):
        """
        shows cross-validation scores of all or single models
        """
        store_path = self._build_path('')
        fig = figure_model_evaluation(self.obj, **kwargs)
        title = f"<b>Model evaluation (mean, sd)</b> <br>cv={self.obj.cv.cv}"
        fig = self._update_layout(fig, title, yaxis_title=self.obj.scoring.scoring, xaxis_title='')
        fig.write_html(f"{store_path}/model_evaluation.html")

    def _update_labels(self):
        if self.security_level is not None and self.obj.fitting_type == 'Classification':
            labels = self.obj.labels.copy()
            labels.append('unknown')
        else:
            labels = self.obj.labels
        return labels

    def _build_scorers(self, X=None, y=None):

        scorers = []
        labels = self._update_labels()  # in case of classification and security_level != None -> 'unknown' as new category

        if X is not None and y is not None:  # scorer for part of data/predictions
            self.obj.predict(X)
            preds = self.obj.get_predictions(security_level=self.security_level)
            scorer_level = Scorer(true_values=y, labels=labels, name='level',
                                  predictions=preds, security_level=self.security_level,
                                  **self.config_evaluation)
            scorer_level.run()
            scorers.append(scorer_level)
        else:
            if self.X_test is not None and self.y_test is not None:
                self.obj.predict(self.X_test)
                predictions_test = self.obj.get_predictions(security_level=self.security_level)
                scorer_test = Scorer(true_values=self.y_test, labels=labels, name='test',
                                     predictions=predictions_test, security_level=self.security_level,
                                     **self.config_evaluation)
                scorer_test.run()
                scorers.append(scorer_test)

            self.obj.predict(self.X_train)
            preds = self.obj.get_predictions(security_level=self.security_level)
            scorer_train = Scorer(true_values=self.y_train, name='train', predictions=preds, labels=labels,
                                  security_level=self.security_level, **self.config_evaluation)
            scorer_train.run()
            scorers.append(scorer_train)

        return scorers

    def _build_path(self, name):
        store_path = os.path.join(self.store_path, name)
        if not os.path.isdir(store_path):
            try:
                os.mkdir(store_path)
            except OSError:
                raise Exception("can't build this directory" % store_path)
        return store_path

    def _get_algorithms(self, algorithms):
        if algorithms is None:
            algs = [i for i in self.obj.model_names if not 'Voting' in i and not 'Dummy' in i]
        else:
            algs = [i for i in self.obj.model_names if not 'Voting' in i and not 'Dummy' in i and i in algorithms]
        return algs

    @staticmethod
    def _set_config_evaluation(self, config_evaluation):
        return config_evaluation

    @staticmethod
    def _get_object(obj):
        if isinstance(obj, Model):
            return obj
        elif isinstance(obj, str):
            try:
                obj = load(obj)
                return obj
            except FileNotFoundError:
                raise Exception(f"can't load file from given path {obj}")
        else:
            raise Exception(f"'obj' is not class Model nor str!")

    @staticmethod
    def _update_layout(fig, title, **kwargs):
        fig.update_layout(
            title={
                'text': title,
                'font': {'size': 25}
            },
            **kwargs,
            template='plotly_white'
        )
        return fig

    @staticmethod
    def _build_feature_order(data):
        feature_order = []
        for idx in range(2, len(data.subsets_) + 1):
            f1 = list(data.subsets_[idx - 1]['feature_names'])
            f2 = list(data.subsets_[idx]['feature_names'])
            f_new = [x for x in f2 if x not in f1]
            feature_order.append(f_new[0])
        feature_order.insert(0, data.subsets_[1]['feature_names'][0])
        return feature_order

    @staticmethod
    def _build_df_from_ranking(ranking):
        df = reduce(lambda left, right: left.join(right, how='outer'), ranking)  # join DataFrames of all algorithms
        overall_sum = df.sum(axis=1).sum(axis=0)
        df['sum'] = df.sum(axis=1)
        df['score'] = df.loc[:, "sum"] / overall_sum
        df.sort_values('score', ascending=False, inplace=True)
        return df

    def _build_excel_overall_feature_selection(self, algorithms=None, cv=False):
        """
        calculates overall importance of each feature
        :param fs: SFS object
        :param algorithms: list of desired algorithm names (None (default) = all available algorithms)
        :return: ranking DataFrame
        """
        if self.obj.feature_selector.results:

            algs = self._get_algorithms(algorithms)
            splits = list(self.obj.feature_selector.results[algs[0]].keys())
            self.no_splits = len(splits) - 1

            if cv is False:
                ranking = []

                for algorithm in algs:
                    # splits = list(self.obj.feature_selector.results[algorithm].keys())
                    # splits.remove('X')
                    data = self.obj.feature_selector.results[algorithm]['X']
                    feature_order = self._build_feature_order(data)
                    ranking.append(
                        pd.DataFrame(index=feature_order, data=list(range(len(feature_order), 0, -1)),
                                     columns=[algorithm]))
                self.overall_ranking_feature_selection = self._build_df_from_ranking(ranking)

            else:
                splits.remove('X')
                ranking_cv = []
                for idx, split in enumerate(splits):
                    temp_split = []
                    for algorithm in algs:
                        data = self.obj.feature_selector.results[algorithm][split]
                        feature_order = self._build_feature_order(data)
                        temp_split.append(
                            pd.DataFrame(index=feature_order, data=list(range(len(feature_order), 0, -1)),
                                         columns=[algorithm]))
                    df = self._build_df_from_ranking(temp_split)
                    df['idx'] = idx
                    ranking_cv.append(df)
                df = pd.concat(ranking_cv)
                df = df.reset_index().drop(['sum', 'idx'], axis=1)
                df = df.groupby(by='index').agg(['mean', 'std'])
                df.sort_values(('score', 'mean'), ascending=False, inplace=True)
                self.overall_ranking_feature_selection = df


class RegressionEvaluator(Evaluator):

    def __init__(self, obj, X_test=None, y_test=None, store_path=None, config_evaluation=None):
        self.config_evaluation = self._validate_config_evaluation(config_evaluation)
        super().__init__(obj, X_test, y_test, store_path)

    def get_total_evaluation(self):
        super().get_total_evaluation()

    @staticmethod
    def _validate_config_evaluation(config_evaluation):
        if config_evaluation is None:
            config_evaluation = {'scoring_methods': ['mean_squared_error']}
        return config_evaluation


class ClassifierEvaluator(Evaluator):

    def __init__(self, obj, X_test=None, y_test=None, store_path=None, config_evaluation=None, security_level=None):
        self.config_evaluation = self._validate_config_evaluation(config_evaluation)
        super().__init__(obj, X_test, y_test, store_path, security_level)
        self.summary_data = self._build_summary_data()
        self.pipe = self.PipeCrawler(self.obj.best_models)
        self.used_features = self.pipe.get_used_features()
        self.used_transformers = self.pipe.get_used_transformers()

    def get_total_evaluation(self):
        super().get_total_evaluation()
        self.plot_confusion_matrix()
        self.plot_summary_data(modes=['mean', 'na_percentage'])
        self.get_summary_data_as_csv()
        self.plot_box(boxmean="sd", boxpoints='all', jitter=0.3)

    def get_summary_data_as_csv(self):
        store_path = self._build_path('data_summary')
        self.summary_data.to_csv(f"{store_path}/data_summary.csv", index=True)

    # OKAY
    def plot_confusion_matrix(self, algorithms='all'):
        """
        plots an confusion matrix of all or special algorithms
        :param algorithms: 'all' default or a list of valid algorithm names to build confusion matrix
        """
        store_path = self._build_path('confusion_matrix')
        for sc in self.scorers:
            cm = ConfusionMatrix(sc)
            cm.run(algorithms=algorithms)
            fig = cm.plot(split=sc.name)
            fig.write_html(f"{store_path}/confusion_Matrix_{sc.name}")

    def plot_summary_data(self, modes=['na_percentage', 'mean'], **kwargs):
        """
        plots missing values of each feature divided per target group.
        :param kwargs:
        """
        store_path = self._build_path('data_summary')

        titles = {'na_percentage': {'title': f"missing values per group", 'y': '% missing values'},
                  'mean': {'title': f"mean values per group", 'y': "value"}}

        for item in modes:

            fig = go.Figure()
            for name, df in self.summary_data.groupby(self.y_train.name):
                fig.add_trace(go.Bar(
                    x=df.index.levels[0],
                    y=df[item],
                    name=name,
                ))

            fig = self._update_layout(fig, titles[item]['title'], yaxis_title=titles[item]['y'], xaxis_title='features')
            fig.update_layout(barmode='group')
            fig.write_html(f"{store_path}/{item}_per_group")

    def plot_box(self, features='all', **kwargs):

        store_path = self._build_path('data_summary')
        data = self._build_box_data(features)
        data = data.groupby(self.y_train.name)

        fig = go.Figure()
        for name, df in data:
            fig.add_trace(go.Box(
                y=df['value'],
                x=df['variable'],
                name=name,
                **kwargs
            ))
        fig.update_layout(
            boxmode='group'  # group together boxes of the different traces for each value of x
        )
        fig = self._update_layout(fig, title="feature boxplot", yaxis_title="value")
        fig.write_html(f"{store_path}/boxplot_features")

    def plot_metric_observation_level(self, n_splits=5, sort='algorithm', **kwargs):
        """
        # TODO: plots are NOT correct!
        :param n_splits: int, number of splits for KFold-crossvalidation
        :param sort: one out of 'algorithm' or 'scorer'
        :param kwargs: for 'go.Scatter' -> line_width=3,
        """

        store_path = self._build_path('metric_observation_level')
        res = self._build_metrics_for_observation_level(n_splits=n_splits)  # TODO: uncomment
        # res = load("data.joblib")
        df_scorer, df_obs = self._build_data_for_observation_level(res)

        if sort == 'algorithm':
            df = df_scorer.groupby('algorithm')
            no = len(df_scorer['algorithm'].unique())
            names = df_scorer['algorithm'].unique()
        else:
            df = df_scorer.groupby('scorer')
            no = len(df_scorer['scorer'].unique())
            names = df_scorer['scorer'].unique()

        positions, geometry = _build_positions(no)

        fig = make_subplots(rows=geometry[0],
                            cols=geometry[1],
                            start_cell="top-left",
                            subplot_titles=names)

        # make COLOR-mapping:
        color_mapping = {}
        if sort == 'scorer':
            algorithms = list(df_obs['algorithm'].unique())
            for idx, item in enumerate(algorithms):
                color_mapping.update({item: self.COLORS['algorithms'][idx]})
        else:
            scorers = list(df_scorer['scorer'].unique())
            for idx, item in enumerate(scorers):
                color_mapping.update({item: self.COLORS['scorers'][idx]})

        for idx, (name, data) in enumerate(df):

            if sort == 'scorer':
                i = data.groupby('algorithm')
            else:
                i = data.groupby('scorer')

            if idx != 0:  # no legend for all subplots except the first one (no repeating legends)

                for sub_name, sub_data in i:
                    fig.add_trace(
                        go.Scatter(
                            x=sub_data.loc[sub_data['variable'] == 'mean', 'threshold'].to_list(),
                            y=sub_data.loc[sub_data['variable'] == 'mean', 'value'].to_list(),
                            name=sub_name,
                            error_y=dict(
                                type='data',  # value of error bar given in data coordinates
                                array=sub_data.loc[sub_data['variable'] == 'std', 'value'].to_list(),
                                visible=True),
                            line_color=color_mapping.get(sub_name, 'darkgreen'),
                            legendgroup=name,
                            showlegend=False,
                            **kwargs
                        ),
                        row=positions[idx][0], col=positions[idx][1]
                    )

                # observations
                fig.add_trace(
                    go.Scatter(
                        x=df_obs.loc[df_obs['algorithm'] == sub_name, 'threshold'].to_list(),  # TODO:
                        y=df_obs.loc[df_obs['algorithm'] == sub_name, 'mean'].to_list(),
                        name='number observations',
                        error_y=dict(
                            type='data',  # value of error bar given in data coordinates
                            array=df_obs.loc[df_obs['algorithm'] == sub_name, 'std'].to_list(),
                            visible=True),

                        legendgroup=name,
                        showlegend=False,
                        line_color='black',
                        line_dash='dot',
                    ),
                    row=positions[idx][0], col=positions[idx][1]
                )
            else:  # legend for first subplot

                for sub_name, sub_data in i:
                    fig.add_trace(
                        go.Scatter(
                            x=sub_data.loc[sub_data['variable'] == 'mean', 'threshold'].to_list(),
                            y=sub_data.loc[sub_data['variable'] == 'mean', 'value'].to_list(),
                            name=sub_name,
                            error_y=dict(
                                type='data',  # value of error bar given in data coordinates
                                array=sub_data.loc[sub_data['variable'] == 'std', 'value'].to_list(),
                                visible=True),
                            line_color=color_mapping.get(sub_name, 'darkgreen'),
                            legendgroup=name,
                            showlegend=True,
                            **kwargs
                        ),
                        row=positions[idx][0], col=positions[idx][1]
                    )

                # observations
                fig.add_trace(
                    go.Scatter(
                        x=df_obs.loc[df_obs['algorithm'] == list(res.keys())[0], 'threshold'].to_list(),
                        y=df_obs.loc[df_obs['algorithm'] == list(res.keys())[0], 'mean'].to_list(),
                        name='number observations',
                        error_y=dict(
                            type='data',  # value of error bar given in data coordinates
                            array=df_obs.loc[df_obs['algorithm'] == sub_name, 'std'].to_list(),
                            visible=True),

                        legendgroup=name,
                        showlegend=True,
                        line_color='black',
                        line_dash='dot',
                    ),
                    row=positions[idx][0], col=positions[idx][1]
                )

            fig.update_yaxes(rangemode="tozero")
            fig.update_xaxes(title="security level [%]")

        fig = self._update_layout(fig, title="Scores dependend on predicting security level")
        fig.write_html(f"{store_path}/metric_observation_level_{sort}")

    @staticmethod
    def _get_max_probabilities(probas, model_name):
        """ returns dict with name of algorithm as key and an array of probabilities"""
        values = {}
        max = probas.max(axis=1)
        values.update({model_name: max})
        probas_max = pd.DataFrame.from_dict(values)
        return probas_max

    def _build_metrics_for_observation_level(self, n_splits):

        X = copy.deepcopy(self.X_train)
        y = copy.deepcopy(self.y_train)

        results_total = {}
        for model in self.obj.best_models.keys():
            if model not in ['VotingClassifier', 'DummyClassifier']:
                kf = KFold(n_splits=n_splits)
                results = []
                best_mod = self.obj.best_models[model]

                for train_index, test_index in kf.split(X):
                    X_train = X.iloc[train_index, :]
                    X_test = X.iloc[test_index, :]
                    y_train = y.iloc[train_index]
                    y_test = y.iloc[test_index]

                    new_mod = best_mod.fit(X_train, y_train)
                    try:
                        pred_probas = new_mod.predict_proba(X_test)
                    except:
                        pred_probas = None

                    if pred_probas is not None:
                        max_probs_y = self._get_max_probabilities(pred_probas, model)

                        scorers = {}
                        for threshold in np.arange(1 / len(self.obj.labels), 1, 0.05):
                            mask = max_probs_y[model] > threshold
                            XXX = X_test.reset_index()
                            X_masked = XXX[mask]
                            XXX = X_masked.set_index(self.X_test.index.name)
                            y_masked = y_test[list(mask)]

                            if len(XXX) != 0:
                                sco = self._build_scorers(X=XXX, y=y_masked)
                                scorers.update(
                                    {f"{round(threshold, 2)}": {'scores': sco[0].scores.get(model),
                                                                'frac_obs': len(X_masked) / len(X_test)}})
                        results.append(scorers)
                results_total.update({model: results})
        return results_total

    def _build_data_for_observation_level(self, res):
        data = res
        results = []
        for classifier in res.keys():
            cl = res.get(classifier)
            for threshold in np.arange(1 / len(self.obj.labels), 1, 0.05):
                b = []
                d = []
                for item in range(0, len(cl)):
                    a = cl[item].get(str(round(threshold, 2)))
                    if a is not None:
                        b.append(a['scores'])
                        d.append(a['frac_obs'])
                e = pd.DataFrame.from_dict(b)
                e['frac_obs'] = d
                f = e.agg(['mean', 'std'])
                f = f.unstack().to_frame().T
                f['threshold'] = round(threshold, 2)
                f['algorithm'] = classifier
                results.append(f)

        df = pd.concat(results)
        df = df.set_index(['algorithm', 'threshold'])

        res_scorer = []
        for item in a['scores'].keys():
            dff = df.loc[:, item]
            dff = dff.reset_index(level=[0, 1])
            dff['scorer'] = item
            res_scorer.append(dff)

        df_scorer = pd.concat(res_scorer)
        df_scorer = df_scorer.melt(id_vars=['algorithm', 'threshold', 'scorer'])

        df_obs = df.loc[:, 'frac_obs']
        df_obs = df_obs.reset_index(level=[0, 1])

        return [df_scorer, df_obs]

    @staticmethod
    def _validate_config_evaluation(config_evaluation):
        if config_evaluation is None:
            config_evaluation = {'scoring_methods': ['accuracy_score']}
        return config_evaluation

    def _build_summary_data(self):
        # TODO: better solution...?
        raw_data = pd.concat([self.y_train, self.X_train], axis=1)
        df = raw_data.groupby(self.y_train.name).agg(['mean', 'median', 'min', 'max', 'std', 'size', 'count'])
        df1 = df.swaplevel(0, 1, axis=1)
        df2 = df1.unstack(level=1)
        df3 = df2.swaplevel(0, 2)
        df4 = df3.unstack(level=2)
        df5 = df4.swaplevel(0, 1)
        df5.sort_index(axis=0, level=0, inplace=True)
        df5['na_percentage'] = 1 - (df5['count'] / df5['size'])
        return df5

    def _build_box_data(self, features):

        raw_data = pd.concat([self.y_train, self.X_train], axis=1)
        x = raw_data[self.y_train.name]
        raw_data = raw_data[self.used_features]
        data = raw_data.select_dtypes(include=np.number)

        if features != 'all':
            features = [i for i in data.columns if i in features]
            if features is not None:
                data = data[features]
            else:
                raise Exception(f"no fetaures found in data")

        data = pd.concat([x, data], axis=1)
        data = data.melt(id_vars=self.y_train.name)
        return data
