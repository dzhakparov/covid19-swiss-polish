import pandas as pd
import numpy as np
from misc.valid_file_path import get_valid_path
import random

# TODO: change headers in output DataFrame

def get_missing_value_summary(data, group=None, path=None):
    """ calculates absolute and fraction of missing values per defined group/subgroup

    Args:
        data: pandas DataFrame
        group: one or multiple categorical columns of data in a list of strings
        path: path to store output file as .csv or None (default). In case of None file will not be stored but only
            returned.

    Returns:
        pandas DataFrame with summary of missing values per group and/or subgroup
    """

    if group is not None:

        if not isinstance(group, list):
            group = [group]

        df = data.groupby(group).agg(['count']).T
        df = df.droplevel(1)

        if len(group) == 1:
            df.columns = df.columns.categories.to_list()

        dff = df.copy()

        li = []
        for row in data.iterrows():
            gr = tuple([row[1][i] for i in row[1].index if i in group])
            for idx, cell in enumerate(row[1]):
                if pd.isnull(cell):
                    li.append({row[1].index[idx]: gr})

        dff.iloc[:, :] = 0
        for item in li:
            key = list(item.keys())
            value = list(item.values())
            if len(value[0]) == 1:
                value = value[0][0]
            dff.loc[key, value] = dff.loc[key, value] + 1

        dff_percents = round((dff / (df + dff)) * 100, 2)

        df['total'] = df.apply(lambda x: sum(x), axis=1)
        df['na_total'] = df['total'].apply(lambda x: data.shape[0] - x)
        df['na_total%'] = df['na_total'].apply(lambda x: round(x / (data.shape[0] / 100), 2))

        df_summary = pd.concat([df, dff, dff_percents], axis=1)

        if path is not None:
            valid_path = get_valid_path(path=path, valid_file_extensions=['.csv'])
            df_summary.to_csv(valid_path)

        return df_summary


if __name__ == '__main__':
    pass

    # def data_missing_value():
    #     content = {'a1': random.sample(range(10, 30), 8),
    #                'c1': [i for i in range(8)],
    #                'e1': [True for i in range(8)],
    #                'f1': ['A', 'B', 'B', np.nan, 'A', 'A', 'B', 'A'],
    #                'g1': ['m', 'f', 'f', 'f', 'f', np.nan, 'm', 'f']
    #                }
    #     df = pd.DataFrame(data=content)
    #     df["f1"] = df["f1"].astype('category')
    #     df["g1"] = df["g1"].astype('category')
    #     df.loc[2,'a1'] = np.nan
    #     return df
    #
    # data_raw = data_missing_value()
    # data = get_missing_value_summary(data_raw, group=['f1', 'g1'])
    # data.index = data.index.set_levels(data.index.levels[0].str.replace('A', 'a'), level=0)
    # print(data)