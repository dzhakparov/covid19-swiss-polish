
def find_first_local_extrema(x, type='index', peak='max', shift=0, threshold=0.20):
    """
    Looking for the first local maximum/minimum of a numeric (smoothed) pandas series
    Args:
        x: pandas series (time-series)
        type: what should be returned: position ('index') or value ('value')?
        peak: either 'max' (default) or 'min' for maximum/minimum of the
        shift: shift for rolling average in number of steps. if shift = 0 (default) there eis no rolling average calculated
        threshold: how many percent may values be under max to detect this als local max

    Returns: position (since start of series) of first peak max/min or it's value
    """

    if x.dtypes not in ['int', 'int64', 'float', 'float64']:
        raise Exception("column is not of type numeric!")

    if shift != 0:
        x = x.rolling(shift, win_type=None).mean()
    x.fillna(method='ffill', inplace=True)
    x.fillna(0, inplace=True)
    x = x.to_frame()
    x.reset_index(inplace=True, drop=True)
    x = x.iloc[:,0]

    if peak == 'max':
        local_extrema_value = x.min()
    else:
        local_extrema_value = x.max()
    # local_extrema_value = 0
    local_extrema_pos = 0

    for row in x.items():
        if peak == 'max':
            if row[1] > local_extrema_value:
                local_extrema_pos, local_extrema_value = row[0], row[1]
            if row[1] < (1 - threshold) * local_extrema_value:
                break
        else:
            # TODO: ERROR
            if row[1] < local_extrema_value:
                local_extrema_pos, local_extrema_value = row[0], row[1]
            if row[1] > (1 - threshold) * local_extrema_value:
                break

    if type == 'index':
        return local_extrema_pos
    else:
        return local_extrema_value


if __name__ == '__main__':
    pass