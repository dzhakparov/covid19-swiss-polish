from functools import wraps
import logging
from pathlib import Path
import os.path
import pandas as pd
from datetime import datetime


def log(mode=None):
    """
    Args:
        mode: dictionary with settings exp.: mode = {'time': True}

    Returns:
    """

    params = {'time': False, 'doc': False}

    if mode is not None:
        params.update(mode)

    def log_int(fn):  # decorator

        p = Path(fn.__name__)
        filepath = f"{str(Path(__file__).parent)}/logs"
        # file = f"{str(Path(__file__).parent)}/logs/{p.stem}.log"
        file = f"{str(Path(__file__).parent)}/logs/{fn.__module__}.log"

        @wraps(fn)
        def logging_fun(*args, **kwargs):

            with open(file, 'a+') as f:
                args_values_types = [(a, type(a)) for a in args]
                kwargs_values_types = [(k, v, type(v)) for k, v in kwargs.items()]

                if params['time']:
                    now = datetime.now()
                    f.write(f"\n{now}: Function '{fn.__name__}' was called\n")
                else:
                    f.write(f"\nFunction '{fn.__name__}' was called\n")

                if params['doc']:
                    f.write(f"{fn.__doc__}")

                f.write(f"\nargs '{fn.__name__}': {args_values_types}")
                f.write(f"\nkwargs '{fn.__name__}': {kwargs_values_types}")
                fn_results = fn(*args, **kwargs)
                if isinstance(fn_results, pd.DataFrame):
                    f.write(f"\n\n\t{fn_results.head(2).to_string()}")
                    # f.write(f"Function '{fn.__name__}' returns pd.DataFrame: \n{fn_results.head(2)}\n")
                    f.write(f"\n\t shape: {fn_results.shape}\n")
                else:
                    f.write(f"Function '{fn.__name__}' returns \n{fn_results}\n")
                f.write(f"params = {params}\n\n")
                return fn_results

        return logging_fun

    return log_int


if __name__ == '__main__':
    pass

