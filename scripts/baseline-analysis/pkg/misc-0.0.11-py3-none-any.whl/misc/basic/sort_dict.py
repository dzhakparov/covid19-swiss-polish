

if __name__ == '__main__':

    termine = {"Termin 2020-11-19 18:20:20.838892": {"Name": "Test", "Beschreibung": "xxx", "Kategorie": "Freizeit",
                                                     "Datum": "2020-11-04", "Zeit": "22:20", "Ort": "Marbach",
                                                     "Verbleibend": "-16"},
               "Termin 2020-11-22 16:39:33.607295": {"Name": "knwar", "Beschreibung": "hwtr", "Kategorie": "Arbeit",
                                                     "Datum": "2020-11-20", "Zeit": "20:39", "Ort": "hw",
                                                     "Verbleibend": "-3"},
               "Termin 2020-11-24 14:11:24.559071": {"Name": "garg", "Beschreibung": "fa", "Kategorie": "Schule",
                                                     "Datum": "2020-11-11", "Zeit": "17:11", "Ort": "fae",
                                                     "Verbleibend": "-14"},
               "Termin 2020-11-24 15:43:15.541988": {"Name": "test", "Beschreibung": "bootstrap", "Kategorie": "Schule",
                                                     "Datum": "2020-11-20", "Zeit": "20:48", "Ort": "hier",
                                                     "Verbleibend": "-5"}}

    print(termine)

    # termine_neu = termine.copy()

    a = sorted(termine.items(), key=lambda x: int(x[1]['Verbleibend']), reverse=False)
    print(a)