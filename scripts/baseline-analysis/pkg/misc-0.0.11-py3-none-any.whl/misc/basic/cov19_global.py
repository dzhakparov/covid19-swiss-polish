import numpy as np
import pandas as pd
from misc.df_plotter.matrix_plotter import MatrixPlotter
from misc.df_plotter.scatter_plotter import ScatterPlotter
from misc.basic.locale_extrema import find_first_local_extrema
from misc.basic.cov19_config import attributes, log_transformation, local_maximum, drop_features, mp, path

# TODO
# DEADLINE: 20.November 2020
# IDEEN:
# ev. SAX einbauen
# neues Feature: gestorben/neue Fälle
# this file will be removed from this package. It's only here because of the development of MatrixPlotter (in this
# package...)


def convert_to_ts(data, cols):
    df_ts = data.pivot(index='location', columns='date')[cols]
    header = df_ts.columns.values.tolist()
    new_header = [i[0].replace('_', '-') + '_' + i[1] for i in header]
    df_ts.columns = new_header
    return df_ts


def get_local_max_of_new_cases(data, type='max', duration=14, drop=0.4):
    new_cases_cols = [col for col in data.columns if
                      'new-cases' in col and 'smoothed' not in col and 'million' not in col]
    df_pd = data.copy()
    df_pd['days-peak'] = df_pd[new_cases_cols].apply(find_first_local_extrema, args=('index', type, duration, drop), axis=1)
    df_pd = df_pd['days-peak'].to_frame()
    return df_pd


def apply_log_transformation(data, type='log10'):
    # change values (logarithm, sqrt, ...)
    data[data < 0] = 0  # replace negative values by 0
    data = data.fillna(0)  # replace all nan with 0
    numeric_cols = [col for col in data if data[col].dtype.kind != 'O']
    data[numeric_cols] += 1  # add 1 to each cell (no problem with logarithm)
    if type == 'log1p':
        data = np.log1p(data.mask(data <= 0)).fillna(0)  # log1p = log(1 + value)
    elif type == 'ln':
        data = np.log(data.mask(data <= 0)).fillna(0)  # log = ln
    else:
        data = np.log10(data.mask(data <= 0)).fillna(0)
    return data


def get_static_num_data(data, cols):
    df_static_num = data.pivot(index='location', columns='date')[cols]
    df_static_num = df_static_num.groupby(level=0, axis=1).mean()
    header = df_static_num.columns.values.tolist()
    new_header = [i.replace('_', '-') for i in header]
    df_static_num.columns = new_header
    return df_static_num


def get_static_text_data(data, cols):
    df_static_text = data.loc[:, cols]
    df_static_text.drop_duplicates(inplace=True)
    df_static_text.set_index(['location'], inplace=True)
    return df_static_text


def join_data(df_ts, df_static_num, df_static_text, df_pd):
    df = df_static_num.join(df_ts)
    df = df_static_text.join(df)
    df = df_pd.join(df)
    return df


def add_new_feature(df, df_static_num, df_static_text):
    cols = [i for i in df.columns if i.startswith("total-deaths-per-million")]
    df_tcpm = df[cols]
    df_tcpm.replace(0, np.nan,
                    inplace=True)  # replace 0 by nan -> if mean is taken with all 0 this would lead to false results
    df_tcpm['mean-total-deaths-per-million'] = df_tcpm.mean(axis=1, skipna=True)
    df_tcpm['max-total-deaths-per-million'] = df_tcpm.max(axis=1, skipna=True)
    df = df.merge(df_tcpm[['mean-total-deaths-per-million', 'max-total-deaths-per-million']], left_index=True,
                  right_index=True)
    cols_to_order = df_static_num.columns.to_list() + df_static_text.columns.to_list() + [
        'mean-total-deaths-per-million', 'max-total-deaths-per-million']
    new_columns = cols_to_order + df.drop(cols_to_order, axis=1).columns.to_list()
    df = df[new_columns]
    return df


def drop_columns(data, col):
    """

    Args:
        data:
        col:

    Returns:

    """
    cols_to_drop = [i for i in col if i in data.columns]
    if cols_to_drop:
        data.drop(cols_to_drop, axis=0, inplace=True)
    return data


def run():

    data = pd.read_csv(path)

    df_ts = convert_to_ts(data, attributes['ts'])

    df_ts = apply_log_transformation(df_ts, type=log_transformation['type'])  # no numerical cols

    df_pd = get_local_max_of_new_cases(df_ts, type=local_maximum['type'], duration=local_maximum['duration'],
                                       drop=local_maximum['drop'])

    df_static_num = get_static_num_data(data, attributes['num'])

    df_static_text = get_static_text_data(data, attributes['text'])

    df = join_data(df_ts, df_static_num, df_static_text, df_pd)

    df = add_new_feature(df, df_static_num, df_static_text)

    df = drop_columns(df, drop_features)

    fig = MatrixPlotter(df, scale_by=mp['scale_by'], sort_by=mp['sort_by']).get_plot()
    fig.show()

    # df_upd = df.reset_index()
    # fig = ScatterPlotter(df, features=['total-cases-per-million', 'new-cases-per-million', 'total-tests', 'hosp-patients'],
    #                      # colored_by='continent',
    #                      filter = {'location': ['Switzerland', 'Greece', 'Kenya']},
    #                      # filter = {'continent': ['Africa']}
    #                      ).get_plot()
    # fig.show()
    # fig.write_html(f"figs/scatter_plot.html")

    # fig.write_html(f"{mp['name']}.html")
    #
    # df.to_csv(f"{mp['name']}.csv")
    #
    # print("\nsuccessfully build plot and datafile!\n")


if __name__ == '__main__':
    run()



