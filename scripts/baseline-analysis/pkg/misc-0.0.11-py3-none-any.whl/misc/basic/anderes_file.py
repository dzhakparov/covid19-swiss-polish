from misc.basic.logger import log
import pandas as pd


@log()
def run(a, b="test"):
    """ This is the run function
    Returns: None
    """
    d = {'col1': [1, 2], 'col2': [3, 4]}
    df = pd.DataFrame(data=d)
    return df
    print(f"running... {a}")
    return df


if __name__ == '__main__':
    a = run(a=42, b='hallo')
