from misc.basic.logger import log
from misc.basic.anderes_file import run
import pandas as pd

mode = {'time': True, 'doc': True}


@log()
def first_function(no=10):
    print([i for i in range(no)])
    hallo()


@log(mode)
def hallo():
    print("hallo")


@log(mode)
def test():
    d = {'col1': [1, 2], 'col2': [3, 4]}
    df = pd.DataFrame(data=d)
    return df


if __name__ == '__main__':
    first_function(no=8)
    a = test()
    run(a=18)
