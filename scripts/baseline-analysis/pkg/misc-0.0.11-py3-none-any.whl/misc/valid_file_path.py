from pathlib import Path


def get_valid_path(path=None, valid_file_extensions=None):
    """ validates and/or extends file path

    Args:
        path: a filename with or without suffix or a filepath as string or Path
        valid_file_extensions: a list of strings of valid file extensions, exp. ['.csv']

    Returns:
        a valid path object to store a certain file

    Examples:

        >>> print(get_valid_path('test.csv'))
        /home/schmidmarco/Documents/CODE/PACKAGES/misc/misc/test.csv

        >>> print(get_valid_path('test', valid_file_extensions=['.csv']))
        /home/schmidmarco/Documents/CODE/PACKAGES/misc/misc/test.csv

        >>> print(get_valid_path('/home/schmidmarco/Documents/CODE/PACKAGES/misc/misc/test.csv'))
        /home/schmidmarco/Documents/CODE/PACKAGES/misc/misc/test.csv
    """

    if path is None:
        return
    else:
        try:
            path = Path(path)
        except ValueError:
            raise Exception(f"couldn't convert {path} into a Path object")

    # check suffix
    if path.suffix == "":
        if valid_file_extensions is None:
            raise Exception(f"no valid suffix found! Use .csv or similar for file ending")
        else:
            path = Path(f"{path}{valid_file_extensions[0]}")  # add first valid_file_extension
    else:
        if valid_file_extensions is not None and path.suffix not in valid_file_extensions:
            raise Exception(f"file suffix '{path.suffix}' is not valid in this case")

    # check folder/path
    if path.parent.name == "":
        path = Path.cwd().joinpath(path)  # single file -> add current working directory
    else:
        folder = path.parent  # check if directory exists
        if not folder.exists():
            raise Exception(f"folder '{folder}' does not exists")
    return path
