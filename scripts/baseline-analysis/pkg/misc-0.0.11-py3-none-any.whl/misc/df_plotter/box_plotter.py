import pandas as pd
import plotly.express as px
import math
import pprint
import re
from datetime import datetime
import os

from misc.df_plotter.plotter import Plotter
from plotly.subplots import make_subplots
import plotly.graph_objects as go


class BoxPlotter(Plotter):

    def __init__(self, df, split=None, features=None):
        """ builds a boxplot of all promoted (numerical) features, optionally split by a categorical feature

        Args:
            df: pandas DataFrame with raw data to plot
            split: feature to split data (categorical)
            features: list of desired features or None (default) that will take all numerical features in df
        """

        super().__init__(df)
        self.split = split
        self.features = features
        self.split_unique_cats = None
        self.figure_data = []  # list (features) of list (group)
        self.style_figure = {}  # for boxplot
        self.style_grid = {}  # for subplot
        self.n_rows = None  # how many plots on y-side
        self.n_cols = None  # how many plots on x-side
        self.subplots_position = None  # grid -> list of list with tuples
        self.figs = []  # stores a list of figures (plotly.graph_objects)
        self.COLOR = None

    def get_features(self):
        return self.features

    def get_plot(self):
        """ returns al list of plotly figures"""
        self._build_figures()
        return self.figs

    def show(self):
        """ shows plots in browser """
        for fig in self.figs:
            fig.show()

    def store(self, path=None, name=None):
        """ stores figures from self.figs """
        if path is None:
            path = os.getcwd()

        if name is None:
            name = f"boxplot_{datetime.now()}"

        try:
            no_figs = len(self.figs)
            for idx, fig in enumerate(self.figs):
                if no_figs == 1:
                    fig.write_html(f"{path}/{name}.html")
                else:
                    fig.write_html(f"{path}/{name}_{idx}.html")
        except():
            pass

    def update_layout(self, style_figure=None, style_grid=None, n_cols=None, n_rows=None, colors=None):
        """
        styles layout and appearing of plots
        Args:
            style_figure: dict with arguments of go.Box like boxpoints, jitter, pointpos, ...
            style_grid: dict with arguments of plotly.make_subplots like shared_xaxes, shared_yaxes, start_cell,
                print_grid, horizontal_spacing, vertical_spacing, subplot_titles, column_widths, row_heights, ...
            n_cols: number of plots (int) in a column
            n_rows: number of plots (int) in a column
            colors: dict of colors {group-name: desired color, ...} or {'data': desired color} for non grouped data
        """

        self.style_grid = {'horizontal_spacing': 0.05, 'vertical_spacing': 0.05}
        if style_grid is not None:
            self.style_grid.update(style_grid)

        self.style_figure = {'boxpoints': 'all', 'boxmean': 'sd'}
        if style_figure is not None:
            self.style_figure.update(style_figure)

        if n_rows is None:
            self.n_rows = None
        else:
            if isinstance(n_rows, int) and n_rows > 0:
                self.n_rows = n_rows
            else:
                raise ValueError(f"rows have to be an integer value bigger 0")

        if n_cols is None:
            self.n_cols = None
        else:
            if isinstance(n_cols, int) and n_cols > 0:
                self.n_cols = n_cols
            else:
                raise ValueError(f"cols have to be an integer value bigger 0")

        if colors is None:
            # if no group separation: {'data': 'blue'}
            # default colors for group separation
            colors = ['slateblue', 'indianred', 'forestgreen', 'indigo', 'orange', 'darkkhaki', 'darksalmon']
            if self.split is not None:
                split_unique_cats = list(self.df[self.split].unique())
                self.COLOR = {key:value for (key,value) in zip(split_unique_cats, colors)}
            else:
                self.COLOR = {'data': 'blue'}  # default color for unsplitted boxplots
        else:
            if isinstance(colors, dict):
                self.COLOR = colors
            else:
                raise ValueError(f"colors have to be of type dictionary with group name as key and color as value")

    def _build_figures(self):
        prep_data = self._prepare_data()
        self._split_data(prep_data)  # builds self.figure_data as list of list
        self._initial_grid()  # self.subplot_position  (OKAY)
        self._update_figure_data_grid_annotation()  # self.figure_data
        self._create_figure()  # returns list of figures according to dimensions

    def _prepare_data(self):
        """ builds a pandas DataFrame with columns 'index', 'y', 'value' and optionally 'group' """

        numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
        num_data = self.df.select_dtypes(include=numerics)
        self.df['index'] = self.df.index

        if self.features is not None:
            cols = [i for i in num_data.columns if i in self.features]
        else:
            cols = num_data.columns.to_list()

        self.features = cols.copy()
        cols.append('index')
        if self.split is not None:
            cols.append(self.split)
            prep_data = pd.melt(self.df[cols], id_vars=[self.split, 'index'], var_name='y', value_name='value')
        else:
            prep_data = pd.melt(self.df[cols], id_vars=['index'], var_name='y', value_name='value')

        self.df.drop('index', axis=1, inplace=True)
        return prep_data

    def _split_data(self, data):

        """ Splits data per group and feature and stores it in a list of list (self.figure_data). In list[0]
        first feature DataFrame are stored per each group one DataFrame aso. If no split is supported data will
        be stored by feature in the same way (list of list) """

        if self.split is not None:
            self.split_unique_cats = list(data[self.split].unique())

        for feature in self.features:
            feature_data = data[data['y'] == feature]
            if data.shape[1] == 4:  # with split
                split_group = []
                for split in self.split_unique_cats:
                    split_feature_data = feature_data[feature_data[self.split] == split]
                    split_group.append(split_feature_data)
                self.figure_data.append(split_group)
            else:  # without split
                self.figure_data.append([feature_data])

    def _initial_grid(self):
        """ returns list of grid position (self.subplot_position)
        exp. [[(1,1),(1,2)]] -> will end in 1 figure with 2 subplots
        exp. [[(1,1), (1,2)], [(1,1), (1,2)]]  -> will end up in 2 plots with each 2 subplots
        """
        n_figures = len(self.figure_data)

        def _calc_combination(n_cols, n_rows, repetitions=1):
            res = []
            for rep in range(repetitions):
                subs = []
                for i in range(1, n_rows + 1):
                    for j in range(1, n_cols + 1):
                        subs.append((i, j))
                res.append(subs)
            return res

        # one figure
        if self.n_rows is None and self.n_cols is None:
            # default with all subplots in one figure
            n_cols = math.ceil(math.sqrt(n_figures))
            n_rows = math.floor(math.sqrt(n_figures))
            if n_cols * n_rows < n_figures:
                n_rows = n_rows + 1
            self.subplots_position = _calc_combination(n_cols=n_cols, n_rows=n_rows, repetitions=1)

        # one figure with defined number of cols or rows
        if (self.n_cols is not None and self.n_rows is None) or (self.n_cols is None and self.n_rows is not None):
            if self.n_cols is not None:
                n_cols = self.n_cols
                n_rows = math.ceil(n_figures / n_cols)
            if self.n_rows is not None:
                n_rows = self.n_rows
                n_cols = math.ceil(n_figures / n_rows)
            self.subplots_position = _calc_combination(n_cols=n_cols, n_rows=n_rows, repetitions=1)

        # possibly multiple figures/sheets
        if (self.n_cols is not None) and (self.n_rows is not None):
            if self.n_cols * self.n_rows < n_figures:
                repetitions = math.ceil(n_figures / (self.n_cols * self.n_rows))
            else:
                repetitions = 1
            self.subplots_position = _calc_combination(n_cols=self.n_cols, n_rows=self.n_rows, repetitions=repetitions)

    def _update_figure_data_grid_annotation(self):

        data = []
        grid = []
        annotations = []
        counter = 0  # counter
        for i in self.subplots_position:
            sub_data = []
            sub_grid = []
            sub_annotations = []
            for y in i:
                if counter < len(self.figure_data):
                    sub_data.append(self.figure_data[counter])
                    sub_grid.append(y)
                    sub_annotations.append(self.features[counter])
                    counter += 1
            data.append(sub_data)
            grid.append(sub_grid)
            annotations.append(sub_annotations)
        self.figure_data = data  # list of list with DataFrames according to subplots
        self.subplots_position = grid
        self.annotations = annotations  # feature names

    def _create_figure(self):

        for figure, data, annotation in zip(self.subplots_position, self.figure_data, self.annotations):

            n_row = max([i[0] for i in figure])
            n_col = max([i[1] for i in figure])

            fig = make_subplots(rows=n_row, cols=n_col, subplot_titles=annotation, **self.style_grid)

            for idx, subplot in enumerate(figure):
                for trace in data[idx]:

                    if self.split is None:
                        label = 'data'
                    else:
                        label = trace.iloc[0, 0]

                    if idx == 0:  #
                        fig.add_trace(
                            go.Box(y=trace['value'],
                                   name=label,
                                   legendgroup=label,
                                   marker_color=self.COLOR.get(label, 'blue'),
                                   text=trace['index'],
                                   showlegend=True,
                                   **self.style_figure
                                   ),
                            row=subplot[0], col=subplot[1]
                        )
                    else:
                        fig.add_trace(
                            go.Box(y=trace['value'],
                                   name=label,
                                   legendgroup=label,
                                   marker_color=self.COLOR.get(label, 'blue'),
                                   text=trace['index'],
                                   showlegend=False,
                                   **self.style_figure
                                   ),
                            row=subplot[0], col=subplot[1]
                        )

            fig.update_layout(
                title={
                    'text': f"<b>Boxplot</b>",
                    'font': {'size': 24}
                },
                template='plotly_white',
            )

            self.figs.append(fig)