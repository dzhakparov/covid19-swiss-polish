import plotly.graph_objects as go
import pandas as pd
import numpy as np
from misc.df_plotter.plotter import Plotter


class TypePlotter(Plotter):

    def __init__(self, df, sort='original'):
        """plots column-types and missing-values (fraction) of pandas DataFrame

        Args:
            df: pandas DataFrame with data to plot
            sort: one out of 'original' (default), 'alphabetic', 'type', 'missing' or 'not_missing'
        """

        super().__init__(df)
        self.sort = sort
        self.dff = None  # stores transformed df
        self.fig = None

    def get_plot(self):
        self._build_data()
        self._set_color()
        self._sort_df()
        self._add_text()
        self._build_figure()
        return self.fig

    def _build_data(self):
        content = {'colname': self.df.columns.to_list(),
                   'type_obj': self.df.dtypes.to_list(),
                   'type': [str(i) for i in self.df.dtypes.to_list()],
                   'num': [str(i) for i in self.df.dtypes.to_list()],
                   'missing': self.df.isna().sum().to_list(),
                   'non_missing_fraction': [1 - (i / self.df.shape[0]) for i in self.df.isna().sum().to_list()],
                   'missing_fraction': [i / self.df.shape[0] for i in self.df.isna().sum().to_list()],
                   'color_dark': [str(i) for i in self.df.dtypes.to_list()],
                   'color_bright': [str(i) for i in self.df.dtypes.to_list()],
                   'text': ["" for i in self.df.columns],
                   }
        self.dff = pd.DataFrame(data=content)

        self.dff['num'] = self.dff['num'].replace({'object': 1, 'int64': 2, 'float64': 3, 'bool': 4, 'category': 5})

    def _set_color(self):
        # change color according to type
        self.dff['color_dark'] = self.dff['color_dark'].replace({
            'object': 'rgb(232,21,21)',
            'int64': 'rgb(85,146,15)',
            'float64': 'rgb(25,228,59)',
            'bool': 'rgb(199,131,13)',
            'category': 'rgb(9,168,208)'})

        self.dff['color_bright'] = self.dff['color_bright'].replace({
            'object': 'rgb(225,170,170)',
            'int64': 'rgb(192,212,168)',
            'float64': 'rgb(178,219,185)',
            'bool': 'rgb(203,182,145)',
            'category': 'rgb(158,194,203)'})

        # set default colors for (all) other types  [grey, lightgrey]
        self.dff.loc[~self.dff['color_dark'].str.startswith("rgb("), 'color_dark'] = "rgb(76,76,76)"
        self.dff.loc[~self.dff['color_bright'].str.startswith("rgb("), 'color_bright'] = "rgb(204,204,204)"

    def _sort_df(self):
        if self.sort == 'type':
            self.dff.sort_values(by=['type', 'colname'], inplace=True)
        elif self.sort == 'alphabetic':
            self.dff.sort_values(by=['colname', 'type'], inplace=True)
        elif self.sort == 'missing':
            self.dff.sort_values(by=['missing', 'colname', 'type'], ascending=False, inplace=True)
        elif self.sort == 'not_missing':
            self.dff.sort_values(by=['missing', 'colname', 'type'], ascending=True, inplace=True)

    def _add_text(self):
        # add text for hover in tests_df_plotter
        for item in self.dff.iterrows():
            if item[1]['num'] == 1 or item[1]['num'] == 4:
                self.dff.loc[item[0], "text"] = f"<b>type:</b> {self.dff.loc[item[0], 'type']} <br>" \
                                           f"<b>counts: </b> {str(self.df[item[1]['colname']].value_counts().to_dict())}"
            if item[1]['num'] == 2 or item[1]['num'] == 3:
                self.dff.loc[item[0], "text"] = f"<b>type:</b> {self.dff.loc[item[0], 'type']} <br>" \
                                           f"<b>min:</b> {self.df[item[1]['colname']].min()}, <br>" \
                                           f"<b>max:</b> {self.df[item[1]['colname']].max()}"
            if item[1]['num'] == 5:
                self.dff.loc[item[0], "text"] = f"<b>type:</b> {self.dff.loc[item[0], 'type']} <br>" \
                                           f"levels: {str(self.dff.loc[item[0], 'type_obj'].categories.values)}, <br>" \
                                           f"ordered: {self.df.loc[:, item[1]['colname']].dtypes.ordered}"

    def _build_figure(self):

        self.fig = go.Figure()

        self.fig.add_trace(go.Bar(
            x=self.dff['colname'],
            y=self.dff['non_missing_fraction'],
            marker_color=self.dff['color_dark'],

            hovertemplate=
            '<b>x</b>: %{x} <br>' +
            '<b>non_missing</b>: %{y} <br>' +
            '%{text}',
            text=self.dff['text'],
            name='non missing'

        ))

        self.fig.add_trace(go.Bar(
            x=self.dff['colname'],
            y=self.dff['missing_fraction'],
            marker_color=self.dff['color_bright'],

            hovertemplate=
            '<b>x</b>: %{x} <br>' +
            '<b>non_missing</b>: %{y} <br>' +
            '%{text}',
            text=self.dff['text'],
            name='missing'
        ))

        no_occurrences = str(self.dff['type'].value_counts().to_dict())
        title = f"<b>{self._get_title()}</b><br> " \
                f"<b>type-count</b> ({len(self.df.columns)}): {no_occurrences};   " \
                f"<b>missing:</b> {self.dff['missing'].sum()} ({round(self.dff['missing'].sum() / (self.df.shape[0] * self.df.shape[1]) * 100, 2)}%);   " \
                f"<b>sort:</b> {self.sort}"

        self._update_layout(title)

        self.fig.update_layout(
            xaxis_title="features",
            yaxis_title=f"fraction missing / not_missing",
            showlegend=False,
            barmode="relative"
        )


if __name__ == '__main__':
    content = {'a': ['a', np.nan, 'c', 'd', 'e', 'f', 'g', 'h'],
               'b': ['-' for i in range(8)],
               'c': [i for i in range(8)],
               'd': [np.nan for i in range(8)],
               'e': [True for i in range(8)],
               'g': ['a', 'b', 'b', 'b', 'a', 'a', 'b', 'a']
               }

    df = pd.DataFrame(data=content)
    df["g"] = df["g"].astype('category')
    fig = TypePlotter(df, sort="alphabetic").get_plot()
    fig.show()