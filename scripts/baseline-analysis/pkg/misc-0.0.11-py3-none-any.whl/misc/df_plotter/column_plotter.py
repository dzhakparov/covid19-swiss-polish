from misc.df_plotter.plotter import Plotter
import pandas as pd
import random
import numpy as np
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import math
import string

COLORS = {'object': 'red', 'number': 'blue', 'int64': 'blue', 'float64': 'blue', 'bool': 'grey', 'datetime': 'orange',
          'category': 'green'}


class ColumnPlotter(Plotter):

    def __init__(self, df, nrows=None, ncols=None, columns=None, column_type=None):
        """ this plotter generates an overview of all columns of a pandas dataframe as a histogram.

        Args:
            df: pandas dataframe
            nrows: int, how many rows should the plot contain? If nrows is None (default) and ncols is None (default) the optimal size for all plots will be generated automatically.
            ncols: int, how many columns should the plot contain? If nrows is None (default) and ncols is None (default) the optimal size for all plots will be generated automatically.
            columns: list of valid column-names to be plotted
            column_type: string, one out of ['object', 'number', 'int64', 'float64', 'bool', 'datetime', 'category']. Only columns with this datatype will be plotted.
        """

        self.nrows = nrows
        self.ncols = ncols
        self.columns = columns
        self.column_type = column_type
        self.fig = None
        self.cols_to_plot = None
        self.no_cols_to_plot = 0
        self.position_matrix = None
        super().__init__(df)

    def get_plot(self, *args, **kwargs):
        """ returns generated histogram of dataframe's content

        Args:
            *args:
            **kwargs: addition plot specific parameters like 'opacity' or 'histnorm' ( "" | "percent" | "probability" | "density" | "probability density" )

        Returns: fig
        """
        self._build_plot(*args, **kwargs)
        return self.fig

    def _calculate_grid_layout(self):
        """
        calculates nrows and ncols based on input (nrows, ncols, columns, column_type)
        Returns: self.nrows, self.ncols
        """
        if self.columns is None:
            if self.column_type is None:
                self.cols_to_plot = self.df.columns.to_list()
            else:
                self.cols_to_plot = self._get_column_type(type=self.column_type).columns.to_list()
        else:
            self.cols_to_plot = [i for i in self.columns if i in self.df.columns]
        self.no_cols_to_plot = len(self.cols_to_plot)

        if self.no_cols_to_plot == 0:
            raise Exception(f"nothing to plot! Check your setup!")

        if self.nrows is None and self.ncols is None:
            if self.no_cols_to_plot <= 49:  # default maximal size (per sheet)
                self.ncols = math.ceil(math.sqrt(self.no_cols_to_plot))
                self.nrows = math.floor(math.sqrt(self.no_cols_to_plot))
                if self.ncols * self.nrows < self.no_cols_to_plot:
                    self.nrows += 1

        if self.nrows is None and self.ncols is not None:
            self.nrows = math.ceil(self.no_cols_to_plot / self.ncols)

        if self.nrows is not None and self.ncols is None:
            self.ncols = math.ceil(self.no_cols_to_plot / self.rows)

        if self.nrows is not None and self.ncols is not None:
            if self.nrows * self.ncols < self.no_cols_to_plot:
                self.nrows = math.ceil(self.no_cols_to_plot / self.ncols)

    def _build_grid_layout(self):
        self.fig = make_subplots(rows=self.nrows, cols=self.ncols, subplot_titles=self.cols_to_plot)

    def _get_column_type(self, type='number'):
        if type not in ['object', 'number', 'int64', 'float64', 'bool', 'datetime', 'category']:
            raise Exception(f"'type' has to be one out of ['object', 'number', 'int64', 'float64', 'bool', "
                            f"'datetime', 'category']")
        return self.df.select_dtypes(include=type)

    def _build_position_matrix(self):
        numbers = np.arange(self.no_cols_to_plot)
        fill = np.full(self.ncols * self.nrows - self.no_cols_to_plot, fill_value=-99)
        numbers = np.append(numbers, fill)  # fill missing positions with -99
        self.position_matrix = numbers.reshape((self.nrows, self.ncols))

    def _get_position(self, idx):
        pos = np.where(self.position_matrix == idx)
        row = int(pos[0]) + 1
        col = int(pos[1]) + 1
        return row, col

    def _add_traces(self, opacity=0.5, **kwargs):
        for idx, item in enumerate(self.cols_to_plot):
            row, col = self._get_position(idx)
            type = str(self.df[item].dtype)
            self.fig.add_trace(go.Histogram(x=self.df[item].values,
                                            name=item,
                                            marker={'color': COLORS[type]},
                                            opacity=opacity,
                                            **kwargs),
                               row=row, col=col)

    def _build_plot(self, *args, **kwargs):
        self._calculate_grid_layout()
        self._build_grid_layout()
        self._build_position_matrix()
        self._add_traces(*args, **kwargs)
        self._update_layout(f"Histograms for selected columns  ('object'=red, 'numeric'=blue,"
                            f" 'category'=green, 'bool'=grey, 'datetime'=orange)")


if __name__ == '__main__':
    letters = string.ascii_lowercase
    rand_letters = random.choices(letters, k=300)
    bool_list = [True, False]

    content = {'v_2': [random.random() for i in range(300)],
               'h_2': [random.randint(10, 20) for i in range(300)],
               'h_3': [random.randint(0, 5) for i in range(300)],
               'x': [random.randint(0, 10) for i in range(300)],
               'y': rand_letters,
               'z': random.choices(bool_list, k=300)
               }
    df = pd.DataFrame(data=content)
    df.iloc[100, 2] = 28

    # p = ColumnPlotter(df=df, column_type='number')
    p = ColumnPlotter(df=df, columns=['h_3', 'v_2', 'y', 'z', 'h_2'])
    fig = p.get_plot(
        opacity=0.3)  # histnorm, =  ( "" | "percent" | "probability" | "density" | "probability density" ), nbinsx=5
    fig.show()
