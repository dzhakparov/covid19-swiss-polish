from misc.df_plotter.plotter import Plotter
from sklearn.preprocessing import MinMaxScaler
import plotly.graph_objects as go
import pandas as pd
import random
import numpy as np


def _min_max_scaler(x, min, max):
    return (x - min) / (max - min)


class MatrixPlotter(Plotter):

    def __init__(self, df, sort_by=None, scale_by=None, color_scale=[[0, 'rgb(255,255,255)'], [1, 'rgb(255,0,0)']]):
        """

        Args:
            df: pandas DataFrame
            sort_by: tuple or list of tuples with column-name and 'asc' or 'desc', exp. [('age', 'asc'), ('sex', 'desc')]
            scale_by: one of None (default) or tuple with ('group', no_stdv). With None each column will be transformed
                with a MinMaxScaler for itself, where as 'group' takes a couple of columns which belongs together to
                scale (crp_1, crp_2 -> group 'crp'). Second argument 'no_stdev' give number of standard deviations to
                fix min and max value of a group. 0 will lead to a normal MinMaxScaler (per group), 2 for example gives
                a max-value of min(max or mean + 2 stddev) and a min-value of max(min, mean - 2 stddev)
            color_scale: tuple of (value, color) -> exp: [[0, 'rgb(255,255,255)'], [1, 'rgb(255,0,0)']] -> white/red
        """

        super().__init__(df)
        self.sort_by = sort_by
        self.scale_by = scale_by
        self.color_scale = color_scale
        self.fig = None

    def get_plot(self):
        self._build_plot()
        return self.fig

    def _scale_data(self):
        if self.scale_by is None:
            x, y, values = self._individual_scale()
        elif self.scale_by[0] == 'group':
            x, y, values = self._group_scale()
        # elif self.scale_by[0] == 'log':
        #     x, y, values = self._log_scale()
        else:
            x, y, values = None
        return x, y, values

    def _build_plot(self):
        self._sort_df()
        cols = self.df.columns.to_list()
        self.df[cols] = self.df[cols].apply(pd.to_numeric,
                                            errors='coerce')  # convert all to numeric values introducing nan in case of failure
        x, y, values = self._scale_data()
        if x is not None:
            self._build_fig(x, y, values)

    def _build_fig(self, x, y, values):
        title = f"MatrixPlotter - values sorted by {self.sort_by}"
        trace = go.Heatmap(
            x=x,
            y=y,
            z=values,
            colorscale=self.color_scale
        )
        data = [trace]
        self.fig = go.Figure(data=data)
        self._update_layout(title)

    def _individual_scale(self):
        scaler = MinMaxScaler()
        scaler.fit(self.df)
        x = self.df.columns.to_list()
        y = self._build_index()
        values = scaler.transform(self.df)
        return x, y, values

    def _build_index(self):
        if self.df.index.dtype in['int64', 'float64', 'int32', 'float32']:
            y = ['i' + str(i) for i in self.df.index]
        else:
            y = [i for i in self.df.index]
        return y

    def _group_scale(self):
        # get different groups: a group starts with the same pattern followed by an '_' and then a number (exp:
        # crp_1, crp_2 -> group: crp)

        group_prefix = [i.split('_')[0] for i in self.df.columns.to_list()]
        unique_groups = list(set(group_prefix))
        for item in unique_groups:
            cols = [i for i in self.df if i.split('_')[0] == item]
            min_value = self.df[cols].min().min()
            max_value = self.df[cols].max().max()
            if self.scale_by[1] != 0:
                mean = self.df[cols].stack().mean()
                sd = self.df[cols].stack().std()
                min_value = max(mean-self.scale_by[1]*sd, min_value)
                max_value = min(mean+self.scale_by[1]*sd, max_value)
            self.df[cols] = self.df[cols].apply(_min_max_scaler, args=(min_value, max_value))
        self.df[self.df < 0] = 0
        self.df[self.df > 1] = 1
        x = self.df.columns.to_list()
        y = self._build_index()
        values = self.df.values
        return x, y, values

    def _log_scale(self):
        df = self.df

        numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
        for c in [c for c in df.columns if df[c].dtype in numerics]:
            df[c] = df[c] * 1000
            df[c] = np.log10(df[c])

        x = df.columns.to_list()
        y = ['i' + str(i) for i in df.index]
        values = df.values
        return x, y, values

    def _sort_df(self):
        if self.sort_by is not None:
            if isinstance(self.sort_by, tuple) or isinstance(self.sort_by, list):
                cl = None
                if isinstance(self.sort_by, list):
                    cl = [i[0] for i in self.sort_by if i[0] in self.df.columns]
                    order = [i[1] for i in self.sort_by if i[0] in self.df.columns]
                    order = [True if x == 'asc' else False for x in order]
                else:
                    if self.sort_by[0] in self.df.columns:
                        cl = [self.sort_by[0]]
                        if self.sort_by[1] == 'asc':
                            order = True
                        else:
                            order = False

                if cl is not None:
                    if len(cl) != 0:
                        self.df = self.df.sort_values(by=cl, ascending=order)
                    else:
                        raise Exception("column to sort by was not found in data...")
            else:
                raise Exception("sort_by has to be a a tuple with column-name as string and "
                                "one of 'asc' or 'desc' for sort-order or a list tuples like these")


if __name__ == '__main__':

    content = {'v_1': [i for i in range(300)],
               'v_2': [random.random() for i in range(300)],
               'h_1': [random.randint(0, 10) for i in range(300)],
               'h_2': [random.randint(10, 20) for i in range(300)],
               'h_3': [random.randint(0, 5) for i in range(300)],
               'x': [random.randint(0, 10) for i in range(300)]
               }
    df = pd.DataFrame(data=content)
    df.loc[1,'h_3'] = 100
    fig = MatrixPlotter(df, sort_by=[('h_1', 'asc'), ('v_1', 'desc')]).get_plot()
    fig.show()

    # fig1 = MatrixPlotter(df).get_plot()
    # fig1.show()

    # fig2 = MatrixPlotter(df, sort_by=[('h_1', 'asc'), ('v_1', 'desc')], scale_by=('group', 0)).get_plot()
    # fig2.show()

    # df_adj = pd.read_csv("../../data/working_file.csv")
    # fig = MatrixPlotter(df=df_adj, sort_by=[('final_result', 'desc'), ('age', 'asc'), ('sex', 'desc')]).get_plot()
    # fig.show()
