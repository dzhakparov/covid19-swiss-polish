from abc import ABC, abstractmethod


# TODO: add methods from subclasses to parent class: sort df, split in subplots (grid, multiple pages)
# initialise stuff belongs to dataframe in init, and details stuff like opacity etc. in get_plot-method -> **kwargs

class Plotter:
    def __init__(self, df):
        """Parent class for other plotter types based on pandas DataFrame
        Args:
            df: pandas DataFrame
        """
        self.df = df

    @abstractmethod
    def get_plot(self):
        """abstract method that all subclasses have to implement
        """
        pass

    def _get_title(self):
        return f"{self.__class__.__name__}"

    def _update_layout(self, title):

        self.fig.update_layout(
            title={
                'text': title,
                'font': {'size': 24}
            },
            template='plotly_white',
        )