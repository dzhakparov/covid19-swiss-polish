from misc.df_plotter.plotter import Plotter
from plotly.subplots import make_subplots
import pandas as pd
import plotly.graph_objects as go
import numpy as np
import itertools
from random import randrange


class ScatterPlotter(Plotter):
    def __init__(self, df, features=None, colored_by=None, filter=None):
        """

        Args:
            df: pandas DataFrame with single observation per row, static attributes (columns to sort or color by) and
            dynamic attributes as columns with same name split by '_' (exp. total-death_2020-01-01,
            total-death_2020-01-02, ...). attention: No additional '_' may be in column-name!
            features: which columns should be plotted? For dynamical attributes only the part before '_' is given
            (exp. ['total_death']
            colored_by: an static attribute (or time) from df as string
        """
        self.features = features
        self.colored_by = colored_by
        self.static_cols = None  # columns appearing only once
        self.dynamic_cols = None  # columns with more than 1 dimension (= same stem before "_" in column-name)
        self.unique_cols_stem = None
        self.picked_cols = None  # chosen columns which are in data
        self.unique_cols_to_plot = None
        self.nrows = None
        self.ncols = None
        self.fig = None
        self.filter = filter
        self.original_df = df
        super().__init__(df)

        self._get_data()
        self._calculate_grid_layout()
        self._build_grid_layout()
        self._reshape_data()
        self._build_position_matrix()
        self._add_traces()
        self._update_layout(title="ScatterPlot")

    def get_plot(self):
        return self.fig

    def _get_data(self):

        self.static_cols = [i.split("_")[0] for i in self.df.columns.to_list() if len(i.split("_")) == 1]
        self.dynamic_cols = list(set([i.split("_")[0] for i in self.df.columns.to_list() if len(i.split("_")) > 1]))

        if self.features is not None:
            self.picked_cols = [i for i in self.df.columns.to_list() if i.split("_")[0] in self.features]
        else:
            self.picked_cols = self.df.columns.to_list()

        self.unique_cols_stem = [i for i in self.static_cols + self.dynamic_cols if i in self.features]

        self.df = self.df[self.picked_cols]

    def _reshape_data(self):
        self.df.reset_index(inplace=True)
        self.df = self.df.melt(id_vars='location', var_name='feature', value_name='value')
        self.df[['feature', 'date']] = self.df.feature.str.split("_", expand=True, )

        # self.df = self.df.pivot(index=('location', 'date', 'continent'), columns='feature')['value']
        self.df = self.df.pivot(index=('location', 'date'), columns='feature', values='value')
        self.df.reset_index(inplace=True)

        # if colored_by take as single attribute
        # TODO: test for single column / problem with (build) column 'location'
        if self.colored_by is not None:
            if self.colored_by not in self.static_cols and self.colored_by != 'time':
                raise Exception("f'colored_by' have to be a static attribute not a time-series or 'time'")
            df = self.original_df[self.colored_by].to_frame()
            df.reset_index(inplace=True)
            self.df = pd.merge(self.df, df, on="location")

    def _calculate_grid_layout(self):

        self.unique_cols_to_plot = [i for i in self.unique_cols_stem if i in self.dynamic_cols]

        no_dynamic_cols = len( self.unique_cols_to_plot)

        if 0 <= no_dynamic_cols <= 8:
            self.ncols = self.nrows = no_dynamic_cols
        else:
            if no_dynamic_cols >= 8:
                raise Exception("more than 8 columns are chosen. Please select less...")
            else:
                raise Exception("no time-series-column to plot is selected...")

    def _build_grid_layout(self):
        self.fig = make_subplots(rows=self.nrows, cols=self.ncols)  #  ,
                                 # subplot_titles=[f"plot {i}" for i in range(self.nrows*self.nrows)])

    def _build_position_matrix(self):
        numbers = np.arange(self.nrows*self.ncols)
        self.position_matrix = numbers.reshape((self.nrows, self.ncols))

    def _get_position(self, idx):
        pos = np.where(self.position_matrix == idx)
        row = int(pos[0]) + 1
        col = int(pos[1]) + 1
        return row, col

    def _add_traces(self, opacity=0.5, **kwargs):

        # TODO: validation filter and refactoring
        if self.filter is not None:
            for key, value in self.filter.items():
                self.df = self.df[self.df[key].isin(value)]

        if self.colored_by is not None:
            # build dict
            unique_vals = list(set(self.df[self.colored_by]))
            color_dict= {}
            for idx, i in enumerate(unique_vals):
                # col = [j for j in [randrange(255) for i in range(3)]]
                # color_dict.update({i: f"rgb{col[0], col[1], col[2]}"})
                color_dict.update({'Europe': 'red', 'Africa': 'blue'})

        tuple_items = list(itertools.product(self.unique_cols_to_plot, repeat=2))

        for idx, item in enumerate(tuple_items):
            row, col = self._get_position(idx)
            x = item[0]
            y = item[1]

            # data_grp = self.df.groupby(self.colored_by)
            # data_red = data_grp.get_group(name=countries[item])

            if x != y:
                self.fig.add_trace(go.Scatter(x=self.df[x],
                                              y=self.df[y],
                                              marker_color = color_dict,
                                              # marker_color="grey",
                                              mode='markers',
                                              name=str(item),
                                              # opacity=0.5
                                              ),
                                   row=row, col=col)
                self.fig.update_yaxes(title_text=y, row=row, col=col)

            else:
                self.fig.add_trace(go.Histogram(x=self.df[x],
                                   marker_color="grey",
                                   name=str(item),
                                   histnorm='probability'
                                   ),
                                   row=row, col=col
                                   )

            self.fig.update_xaxes(title_text=x, row=row, col=col)
            self.fig.update_layout(showlegend=False)


    def _build_plot(self):

        # TODO: generalize
        color= ['blue', 'red', 'green', 'grey']
        countries =['Switzerland' , 'Greece', 'Kenya', 'Austria']
        features = self.unique_cols_to_plot

        self.df = self.df[self.df['location'].isin(countries)]
        self.df = self.df[self.df['feature'].isin(features)]
        self.df = self.df.pivot(index=('location', 'date', 'continent'), columns='feature')['value']
        self.df.reset_index(inplace=True)

        data_grp = self.df.groupby("location")

        for j in range(1,4,1):
            for item in range(len(countries)):
                data_red = data_grp.get_group(name=countries[item])
                data_red['date_num'] = range(0, data_red.shape[0], 1)

                if j == 1:
                    self.fig.add_trace(go.Scatter(x=data_red[features[0]],
                                             y=data_red[features[1]],
                                             # marker_color = self.df['continent'],
                                             marker_color=color[item],
                                             mode='markers',
                                             name=countries[item],
                                             # opacity=0.5
                                                  ),
                                             row=1, col=j)
                if j == 2:
                    self.fig.add_trace(go.Scatter(x=data_red[features[0]],
                                             y=data_red[features[1]],
                                             # marker_color=data_grp['date']
                                             marker=dict(
                                                 size=8,
                                                 cmax=data_red.shape[0],
                                                 cmin=0,
                                                 color=data_red['date_num'],
                                                 colorbar=dict(
                                                     title="Colorbar"
                                                 ),
                                                 colorscale="Viridis"
                                             ),
                                             mode="markers",
                                             name=countries[item],
                                             # marker=dict(color=[4, 5, 6],
                                             #            coloraxis="coloraxis")
                                             ),
                                  1, j)
                    self.fig.update_layout(showlegend=False),

                self.fig.update_xaxes(title_text=features[0], row=1, col=j)
                self.fig.update_yaxes(title_text=features[1], row=1, col=j)


if __name__ == '__main__':
    pass
