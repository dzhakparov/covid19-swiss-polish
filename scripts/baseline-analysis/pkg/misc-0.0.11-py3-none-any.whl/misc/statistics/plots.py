import math
import plotly.graph_objects as go
from statsmodels.graphics.gofplots import qqplot
import matplotlib.pyplot as plt
from plotly.subplots import make_subplots
from itertools import product
from misc.statistics.statisticalTestSuite.helpers import post_hoc_to_tuple


class Plot:

    COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
              '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
    PLOT_TYPES = ['histogram', 'qqplot', 'boxplot']

    def __init__(self, statisticalTest, location, filename, interactive=False, plot_choice=None, show_group_diff=True):

        self.obj = statisticalTest
        self.data = self.obj.get_data()
        self.location = location
        self.filename = filename
        self.interactive = interactive
        self.plot_choice = plot_choice
        self.show_group_diff = show_group_diff
        self.fig = None

        self._extract_grouped_data()
        self._plot()

    def layout(self):
        self.fig.update_layout(
            title=f"Feature: {self.data.name}",
            legend_title_text=self.data.index.name,
            font=dict(
                size=18,
                color="#7f7f7f"
            ),
            template="plotly_white")

    def store(self, prefix):
        if self.interactive:
            self.fig.write_html(f"{self.location}/{prefix}{self.filename}.html")
        else:
            self.fig['layout'].update({
                'width': 800,
                'height': 800,
            })
            self.fig.write_image(f"{self.location}/{prefix}{self.filename}.jpeg")
        plt.close('all')

    def _extract_grouped_data(self):
        grouped = self.data.groupby(level=0)  # .indices
        self.grouped_list = [grouped.get_group(x) for x in grouped.groups]

    def _plot(self):
        if self.plot_choice is not None:
            if 'box' in self.plot_choice:
                self.boxplot()
            if 'qq' in self.plot_choice:
                self.qqplot()
            if 'hist' in self.plot_choice:
                self.histogram()
        else:
            self.boxplot()
            self.qqplot()
            self.histogram()

    def boxplot(self):

        self.fig = go.Figure()

        for idx, item in enumerate(self.grouped_list):

            self.fig.add_trace(go.Box(y=item.values,
                                 name=item.index[0],
                                 boxmean='sd',
                                 boxpoints='all',
                                 jitter=0.5,
                                 marker_color=Plot.COLORS[idx],
                                 ))

        if self.obj.post_hoc is not None and self.show_group_diff:
            res = post_hoc_to_tuple(self.obj.post_hoc)

            y = self._get_y_values_for_group_difference_lines(res)

            for idx, item in enumerate(res):
                if item[2] < 0.01:
                    line = dict(
                        color="#7f7f7f",
                        width=2)
                else:
                    line = dict(
                        color="#7f7f7f",
                        width=2,
                        dash='dash')

                self.fig.add_trace(go.Scatter(
                    x=[item[0], item[0], item[1], item[1]],
                    y=[y[idx]*0.98, y[idx], y[idx], y[idx]*0.98],
                    mode='lines',
                    line=line
                ))

        self.layout()
        self.fig.update_layout(showlegend=False)

        self.store("boxplot_")

    def qqplot(self):

        rows, cols, positions = self._get_number_rows_cols()

        self.fig = make_subplots(rows=rows, cols=cols)

        for idx, item in enumerate(self.grouped_list):
            qqplot_data = qqplot(item.values, line='s').gca().lines

            f1 = go.Scatter(x=qqplot_data[0].get_xdata(),
                           y=qqplot_data[0].get_ydata(),
                           mode='markers',
                           marker_color=Plot.COLORS[idx],
                           marker_size=10,
                           name=item.index[0]
                           )
            f2 = go.Scatter(x=qqplot_data[1].get_xdata(),
                            y=qqplot_data[1].get_ydata(),
                            mode='lines',
                            line_color=Plot.COLORS[idx],
                            name=item.index[0]
            )

            self.fig.append_trace(f1, positions[idx][0], positions[idx][1])
            self.fig.append_trace(f2, positions[idx][0], positions[idx][1])

        self.fig['layout'].update({
            'title': f"Quantile-Quantile Plot: {item.name}",
            'xaxis': {
                'title': 'Theoritical Quantities',
                'zeroline': False
            },
            'yaxis': {
                'title': 'Sample Quantities'
            },
            'showlegend': True,

            'font': dict(
                size=18,
                color="#7f7f7f"
            ),
        })

        self.store("qqplot_")

    def histogram(self):

        rows, cols, positions = self._get_number_rows_cols()

        self.fig = make_subplots(rows=rows, cols=cols)

        for idx, item in enumerate(self.grouped_list):
            f=go.Histogram(x=item.values,
                           name=item.index[0],
                           histnorm='probability',
                           marker_color=Plot.COLORS[idx],
                           nbinsx=40)

            self.fig.append_trace(f, positions[idx][0], positions[idx][1])

        self.fig.update_traces(opacity=0.75)

        self.layout()
        self.store("histogram_")

    def _get_number_rows_cols(self):

        no_plots = len(self.grouped_list)
        rows = math.floor(math.sqrt(no_plots))
        cols = math.ceil(math.sqrt(no_plots))
        if rows * cols < no_plots:
            rows = rows + 1

        positions = [item for item in product(range(1, cols+1), repeat=2)]

        return rows, cols, positions

    def _get_y_values_for_group_difference_lines(self, res):
        max = self.data.max()
        results = []
        for idx, item in enumerate(res):
            y_value = max * 1.05 + (max/100*5)*idx
            results.append(y_value)
        return results