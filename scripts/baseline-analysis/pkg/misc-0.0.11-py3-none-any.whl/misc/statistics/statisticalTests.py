# This class gets a pandas DataFrame with at least one categorical Feature (target) and multiple numerical and/or
# categorical features

import pandas as pd
from misc.statistics.statisticalTestSuite.statTest import StatTest
from misc.statistics.statisticalTestSuite.statPlot import StatPlot
from misc.statistics.statisticalTestSuite.helpers import means_to_string, post_hoc_to_string
import os


class StatisticalTests:

    def __init__(self, data, target=None, path=None, cols_to_analyze=None, cols_normal_distributed=None,
                 p_value_correction=None, test_significance_level=0.05, significance_level_post_hoc=0.05):
        """

        :param data:
        :param target:
        :param path:
        :param cols_to_analyze:
        :param cols_normal_distributed:
        :param p_value_correction: string, choose from 'bonferroni' or 'holm' (default: None=no correction)
        """

        self.data = data  # pandas DataFrame
        self.target = target  # name of categorical column of data
        self.cols_to_analyze = cols_to_analyze
        self.cols_normal_distributed = cols_normal_distributed
        self.p_value_correction = p_value_correction
        self.test_significance_level = test_significance_level
        self.significance_level_post_hoc = significance_level_post_hoc
        self.results_table = None
        self.statisticalTest = None
        self.cols = None
        self.no_cols = 0
        self.path = path

        self._build_output_directory()
        self._build_cols_to_analyze()
        self._initialize_result_table()

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, df):
        if not isinstance(df, pd.DataFrame): raise Exception("data must be of type pd.DataFrame")
        self._data = df

    @property
    def target(self):
        return self._target

    @target.setter
    def target(self, target):
        if target is None:
            if self._data.iloc[:, 0].dtype.name != 'category':
                raise Exception("if target is None, first column of DataFrame must be of type 'category'")
            else:
                self._target = self._data.columns[0]
        else:
            if self._data.loc[:, target].dtype.name != 'category':
                raise Exception("target must be of type 'category'")
            else:
                self._target = target

    def get_result_table(self):
        return self.results_table

    def run_stats(self, store_csv=False, plot=False, plot_choice=None, interactive=False, show_group_diff=True):
        """
        starts method to calculate statistics
        :param store_csv: boolean, if figure should be stored as .csv
        :param plot: boolean, if figure should be plotted
        :param plot_choice: None or list of ['qq', 'hist', 'box']
        :param interactive: boolean, if tests_df_plotter should be interactive in browser or static as jpg.
        if interactive is True maximal 5 features will be plotted
        :param show_group_diff: boolean, should between group differences be indicated be a dashed(<0.05) or solid (<0.01) line?
        :return:
        """
        counter = 0  # counts number of (numeric) feature plotted (interactive mode will tests_df_plotter maximal 5 features!)

        for idx, item in enumerate(self.cols):

            if self.cols_normal_distributed is not None:
                if item in self.cols_normal_distributed:
                    normality_manual = True
                else:
                    normality_manual = False
            else:
                normality_manual = False

            self.statisticalTest = StatTest(col_feature=self._data[item], col_by=self._data[self._target],
                                            normality_manual=normality_manual,
                                            test_significance_level=self.test_significance_level)

            if plot and self._data[item].dtype in ['float64', 'int64'] and 'ERROR' not in self.statisticalTest.feature:
                counter = counter + 1
                location = self.path + "/data/output/tests_df_plotter"
                # if (interactive is False) or (
                #         interactive and counter <= 5):  # plots only maximal 5 interactive features
                StatPlot(statisticalTest=self.statisticalTest, location=location, filename=idx,
                         interactive=interactive, plot_choice=plot_choice, show_group_diff=show_group_diff)

            # self.results = statisticalTest.get_testresults()
            self._fill_results_table(idx)

        self.results_table.sort_values(by=['p_value'], inplace=True)

        if self.p_value_correction is not None:
            self._update_p_values_corrected()

        if store_csv:
            self.results_table.to_csv(self.path + '/data/output/output.csv')

    def _build_cols_to_analyze(self):

        if self.cols_to_analyze is None:
            self.cols = [col for col in self._data.columns if col != self._target]  # analyze all
        else:
            self.cols = [col for col in self.cols_to_analyze if
                         col != self._target and col in self._data.columns]  # analyze selected cols

        self.no_cols = len(self.cols)

        if self.no_cols == 0:
            raise Exception("no valid columns found!")

    def _initialize_result_table(self):

        # Create an empty DataFrame with columns or indices
        self.results_table = pd.DataFrame(columns=['grouped_by', 'grouped_levels', 'feature', 'feature_type',
                                                   'number_obs', 'normality', 'normality_manual', 'var_homogeneity',
                                                   'testname','p_value', 'p_value_adj', 'means', 'post_hoc_test',
                                                   'post_hoc'],
                                          index=list(range(0, self.no_cols)))
        self.results_table.index.names = ['idx']

    def _fill_results_table(self, idx):
        self.results_table.loc[idx, 'testname'] = self.statisticalTest.test
        self.results_table.loc[idx, 'grouped_by'] = self.statisticalTest.col_by.name
        self.results_table.loc[idx, 'grouped_levels'] = self.statisticalTest.group_names
        self.results_table.loc[idx, 'feature'] = self.statisticalTest.feature
        self.results_table.loc[idx, 'feature_type'] = self.statisticalTest.type_feature
        self.results_table.loc[idx, 'number_obs'] = self.statisticalTest.group_sizes
        self.results_table.loc[idx, 'normality'] = self.statisticalTest.normality_status
        self.results_table.loc[idx, 'normality_manual'] = self.statisticalTest.normality_manual
        self.results_table.loc[idx, 'var_homogeneity'] = self.statisticalTest.var_homogeneity_status
        self.results_table.loc[idx, 'means'] = means_to_string(self.statisticalTest.group_means)
        self.results_table.loc[idx, 'p_value'] = self.statisticalTest.pvalue
        self.results_table.loc[idx, 'post_hoc_test'] = self.statisticalTest.post_hoc_test
        self.results_table.loc[idx, 'post_hoc'] = post_hoc_to_string(self.statisticalTest.post_hoc,
                                                                     level=self.significance_level_post_hoc)

    def _update_p_values_corrected(self):

        number_of_valid_tests = self.results_table['p_value'].count()

        # bonferroni
        if self.p_value_correction == 'bonferroni':
            self.results_table['p_value_adj'] = self.results_table['p_value'] * number_of_valid_tests
            self.results_table['p_value_adj'] = self.results_table['p_value_adj'].apply(lambda x: 1 if x > 1 else x)

        # holm
        if self.p_value_correction == 'holm':
            pass  # TODO

        def remove_post_hoc(x):
            if x['post_hoc'] is not None:
                if x['p_value_adj'] > self.test_significance_level:
                   x['post_hoc'] = ""
                   x['post_hoc_test'] = ""
            return x

        # update results_table (remove post_hoc for p_value_adj > sig_level)
        self.results_table = self.results_table.apply(remove_post_hoc, axis=1)

    def _build_output_directory(self):

        # TODO: check for path as string etc.
        if self.path is None:
            self.path = os.getcwd()

        locations = [self.path + '/data/output',   # TODO
                     self.path + '/data/output/tests_df_plotter']

        for location in locations:
            if not os.path.isdir(location):
                try:
                    os.mkdir(location)
                except OSError:
                    print("Creation of the directory %s failed" % location)
                else:
                    print("Successfully created the directory %s " % location)

    @staticmethod
    def combine_features(data, key_cols, new_name=None, drop_nan=True, drop_key_cols=True):
        """
        this staticmethod creates/combines new feature from existing ones.
        :param data: pandas DataFrame
        :param cols: list of columns in df which should be combined to new column
        :param drop_nan: boolean, should nan in each key_cols be removed?
        :param drop_key_cols: boolean, should columns combined to new column be deleted from df?
        :return: pandas DataFrame with new-build column
        """
        if new_name is None:
            new_name = 'key'

        names = [name for name in data.features if name in key_cols]
        names_intersection = names.copy()

        if len(names) > 1:
            new_df = data[names]
            new_df[new_name] = new_df[names[0]].str.cat(new_df[names[1]], sep="_")  # TODO: better solution?
            del names[:2]
            while len(names) != 0:
                new_df[new_name] = new_df[new_name].str.cat(new_df[names[0]], sep="_")
                del names[:1]

            data = pd.concat([data, new_df[new_name]], axis=1)

            if drop_nan:
                data.dropna(subset=[new_name], inplace=True)
            else:
                data[new_name] = data[new_name].fillna('category_with_na_in_key')

            if drop_key_cols:
                data.drop(names_intersection, axis=1, inplace=True)

            data = data.astype({new_name: 'category'})

        return data


if __name__ == '__main__':

    df = pd.read_pickle('../../data/final_data.pkl')

    df = StatisticalTests.combine_features(data=df, key_cols=['diagnosis', 'location'],
                                           new_name='location_diagnosis', drop_nan=True, drop_key_cols=True)

    df.drop(columns=['PID'], inplace=True)

    # df = df[df['RNASeq'] == 'yes']

    obj = StatisticalTests(data=df,
                           target='location_diagnosis',
                           # path='/home/marco/Desktop',
                           # cols_to_analyze=['farmanimal_contact_mother', 'fuel_cooking_Open fires outside the house',
                           #                  'sunlight_exp_winter', 'parental_income'],
                           cols_to_analyze=['log_blood_count_monocytes','sunlight_exp_winter'],
                           # cols_normal_distributed=['log_blood_count_monocytes'],
                           # cols_to_analyze=['log_blood_count_monocytes'],
                           # p_value_correction='bonferroni',
                           test_significance_level=0.05,
                           significance_level_post_hoc=0.05
                           )

    obj.run_stats(store_csv=True,
                  plot=True,
                  # plot_choice=['box', 'qq', 'hist'],
                  interactive=True,
                  show_group_diff=True
                  )

    print(obj.get_result_table())