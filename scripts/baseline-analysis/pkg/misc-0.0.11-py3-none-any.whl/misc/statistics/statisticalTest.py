import pandas as pd
from scipy.stats import shapiro
from misc.statistics.statisticalTestSuite.helpers import levene


class Error(Exception):
    pass


class NumberObservationTooSmallError(Error):
    pass


class StatisticalTest:
    """
    gets 2 pandas Series (target and feature) and builds the statistics for
    """

    def __init__(self, col_by, col_feature, normality_manual=False, test_significance_level=0.05):

        self.col_by = col_by  # pandas Series
        self.col_feature = col_feature  # pandas Series
        self.normality_manual=normality_manual
        self.test_significance_level = test_significance_level
        self.feature = self.col_feature.name
        self.data = None

        self.type_target = self.col_by.dtype.name
        self.type_feature = self.col_feature.dtype.name

        self.test = None  # which test should be calculated (depending of distribution, homogeneity of variance etc.)?

        self.group_names = None   # names of subgroups as list: ['A', 'B', 'C']
        self.group_sizes = None   # sizes of subgroups in order of group_names: [12, 18, 6]
        self.group_means = None   # means of all subgroups (only if numerical)

        self.normality_test = 'shapiro-wilk'  # set test for normality assumptions
        self.normality_sig_level = 0.05
        self.normality_values = None  # list of p-values of feature per group (if feature is numeric)
        self.normality_status = False  # will be set to True if assumptions are met or if is set to True manually

        self.var_homogeneity_test = 'levene'
        self.var_homogeneity_sig_level = 0.05
        self.var_homogeneity_value = None  # p_value of test for homogeneity of variance
        self.var_homogeneity_status = False  # will be set to True if assumptions are met or if is set to True manually

        # results
        self.pvalue = None
        self.pvalue_corrected = None
        self.expected_freq = None
        self.stats = None
        self.post_hoc = None
        self.post_hoc_test = None

        self._execute_method()

    def get_testresults(self):
        return self.results

    def get_data(self):
        return self.data

    def _execute_method(self):

        self._build_series()  # builds self.data as pandas Series with group as index and feature as values

        try:
            self._build_groups()
        except NumberObservationTooSmallError:
            # if number of observations is below 3 (per subgroup)
            self.feature = f"{self.col_feature.name} ERROR"
            return

        self._build_test_type()
        self._run_stat_test()

    def _build_series(self):
        """
        build pandas series with target as index and feature as values with all missing values removed
        """
        data = pd.concat([self.col_by, self.col_feature], axis=1)
        data.dropna(inplace=True)
        data = data.set_index(data.columns[0])
        self.data = data[data.columns[0]]  # convert to pandas series

    def _build_groups(self):
        """
        calculates the number of observations in each subgroup
        :param data: pandas series with groups as index
        :return: number of observation per subgroup as a list
        """

        grp = self.data.index.value_counts()
        self.group_sizes = grp.to_list()
        self.group_names = grp.index.to_list()

        group_sizes = [i for i in self.group_sizes if i <= 3]
        if len(group_sizes) >= 1:
            raise NumberObservationTooSmallError

        if self.type_feature in ['float64', 'int64']:
            self.group_means = self.data.groupby(level=0).mean()

    def _build_test_type(self):
        """
        determines which kind of statistical test should be applied on data depending on assumptions (normality,
        equality of variance, number of groups)
        """
        if self.type_feature in ['float64', 'int64']:  # for numerical feature

            self._test_normality()
            self._set_normality_status()
            self._test_var_homogenity()  # TODO: calculate 'levene' for non-normality values and 'bartlett' for normal distributed values
            self._set_var_homogeneity_status()

            if len(self.group_names) == 2:
                if self.normality_status is False and self.normality_manual is False:
                    self.test = 'mann_whitney'  # wilcox  (non parameteric alternative to t-test)
                else:
                    self.test = 't_test'
            else:
                if self.normality_status is False and self.normality_manual is False:
                    self.test = 'kruskal'  # non parametric alternative to one-way anova
                else:
                    self.test = 'anova'

        else:
            self.test = 'chi_square'

    def _test_normality(self):
        """
        test for normality of each subgroup
        :return: list of p-values for each subgroup
        """
        if self.normality_test == 'shapiro-wilk':
            def shapiro_wilk(data):
                stat, p = shapiro(data.values)
                return p

            p_values = self.data.groupby(level=0).apply(shapiro_wilk)
            self.normality_values = p_values.values.tolist()

    def _set_normality_status(self):
        """
        sets status to False if at least one value of the list is below promoted sig_level
        """
        if self.normality_values is not None:
            sig_values = [i for i in self.normality_values if i <= self.normality_sig_level]
            if len(sig_values) >= 1:
                self.normality_status = False
            else:
                self.normality_status = True

    def _test_var_homogenity(self):

        if self.var_homogeneity_test == 'levene':
            self.var_homogeneity_value = levene(self.data)

    def _set_var_homogeneity_status(self):

        if self.var_homogeneity_value < self.var_homogeneity_sig_level:
            self.var_homogeneity_status = False
        else:
            self.var_homogeneity_status = True

    def _run_stat_test(self):
        """
        calculates the statistical test
        :return: dictionary (self.res) with named results {'name': 't-test', 'p-value': 0.04352, ...}
        """

        kwargs = {"normality": self.normality_status, "normality_manual": self.normality_manual,
                  "homogeneity": self.var_homogeneity_status, 'sig_level': self.test_significance_level}

        func = eval(self.test)
        func(self, **kwargs)