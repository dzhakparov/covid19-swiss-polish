import numpy as np
import pandas as pd
import logging
import plotly.express as px
import plotly.graph_objects as go


def column_conversion(file, columns, logger=None, log_level='column'):
    # numeric
    #   float64
    #   int64
    # object
    # datetime64[ns]
    # category

    # coerce='force', 'error'

    columns = {"A": ('category', ["1", "2", "3"]), "B": ('numeric', 'int')}
    columns = {}


# def convert_categorical(file, logging):
#     categorical = prep['convert_categorical']
#     logging.info(f"try to convert to categorical: \n{format(categorical)}\n")
#     file[categorical] = file[categorical].apply(lambda x: x.astype('category'))
#     logging.info(f"'convert_categorical' successfully finished!\n")
#     return file
#
#
# def convert_date(file, logging):
#     date = prep['convert_date']
#     logging.info(f"try to convert to date: \n{format(date)}\n")
#     file[date] = file[date].apply(lambda x: pd.to_datetime(x, format='%Y-%m-%d'))
#     logging.info(f"'convert_date' successfully finished!\n")
#     return file
#
# def convert_numerical(file, logging):
#     categorical = prep['convert_categorical']
#     date = prep['convert_date']
#     object = [col for col in file.columns if 'mews_' in col]
#     numerical = [item for item in file.columns.to_list() if
#                  item not in categorical and item not in date and item not in object]  # numerical columns (all the rest)
#     logging.info(f"try to convert to numerical: \n{format(numerical)}\n")
#     file[numerical] = file[numerical].apply(pd.to_numeric,
#                                             errors='ignore')  # If 'ignore', then invalid parsing will return the input
#     logging.info(f"'convert_numerical' successfully finished!\n")
#     return file
#
#
# def convert_object(file, logging):
#     object = [col for col in file.columns if 'mews_' in col]
#     logging.info(f"try to convert to type object: \n{format(object)}\n")
#     file[object] = file[object].apply(lambda x: x.astype('object'))
#     logging.info(f"'convert_object' successfully finished!\n")
#     return file


def _build_data(df):

    content = {'colname': df.features.to_list(),
               'type_obj': df.dtypes.to_list(),
               'type': [str(i) for i in df.dtypes.to_list()],
               'num': [str(i) for i in df.dtypes.to_list()],
               'missing': df.isna().sum().to_list(),
               'non_missing_fraction': [1 - (i / df.shape[0]) for i in df.isna().sum().to_list()],
               'missing_fraction': [i / df.shape[0] for i in df.isna().sum().to_list()],
               'color_dark': [str(i) for i in df.dtypes.to_list()],
               'color_bright': [str(i) for i in df.dtypes.to_list()],
               'text': ["" for i in df.features],
               }
    dff = pd.DataFrame(data=content)

    dff['num'] = dff['num'].replace({'object': 1, 'int64': 2, 'float64': 3, 'bool': 4, 'category': 5})
    return dff


def _set_color(df):

    # change color according to type
    df['color_dark'] = df['color_dark'].replace({
        'object': 'rgb(232,21,21)',
        'int64': 'rgb(85,146,15)',
        'float64': 'rgb(25,228,59)',
        'bool': 'rgb(199,131,13)',
        'category': 'rgb(9,168,208)'})

    df['color_bright'] = df['color_bright'].replace({
        'object': 'rgb(225,170,170)',
        'int64': 'rgb(192,212,168)',
        'float64': 'rgb(178,219,185)',
        'bool': 'rgb(203,182,145)',
        'category': 'rgb(158,194,203)'})

    # set default colors for (all) other types  [grey, lightgrey]
    df.loc[~df['color_dark'].str.startswith("rgb("), 'color_dark'] = "rgb(76,76,76)"
    df.loc[~df['color_bright'].str.startswith("rgb("), 'color_bright'] = "rgb(204,204,204)"

    return df


def _sort_df(df, sort):
    if sort == 'type':
        df.sort_values(by=['type', 'colname'], inplace=True)
    elif sort == 'alphabetic':
        df.sort_values(by=['colname', 'type'], inplace=True)
    elif sort == 'missing':
        df.sort_values(by=['missing', 'colname', 'type'], ascending=False, inplace=True)
    elif sort == 'not_missing':
        df.sort_values(by=['missing', 'colname', 'type'], ascending=True, inplace=True)
    return df


def _add_text(dff, df):
    # add text for hover in tests_df_plotter
    for item in dff.iterrows():
        if item[1]['num'] == 1 or item[1]['num'] == 4:
            dff.loc[item[0], "text"] = f"<b>type:</b> {dff.loc[item[0], 'type']} <br>" \
                                       f"<b>counts: </b> {str(df[item[1]['colname']].value_counts().to_dict())}"
        if item[1]['num'] == 2 or item[1]['num'] == 3:
            dff.loc[item[0], "text"] = f"<b>type:</b> {dff.loc[item[0], 'type']} <br>" \
                                       f"<b>min:</b> {df[item[1]['colname']].min()}, <br>" \
                                       f"<b>max:</b> {df[item[1]['colname']].max()}"
        if item[1]['num'] == 5:
            dff.loc[item[0], "text"] = f"<b>type:</b> {dff.loc[item[0], 'type']} <br>" \
                                       f"levels: {str(dff.loc[item[0], 'type_obj'].categories.values)}, <br>" \
                                       f"ordered: {df.loc[:, item[1]['colname']].dtypes.ordered}"

    return dff


def _build_figure(dff, df, sort):

    fig = go.Figure()

    fig.add_trace(go.Bar(
        x=dff['colname'],
        y=dff['non_missing_fraction'],
        marker_color=dff['color_dark'],

        hovertemplate=
        '<b>x</b>: %{x} <br>' +
        '<b>non_missing</b>: %{y} <br>' +
        '%{text}',
        text=dff['text'],
        name='non missing'

    ))

    fig.add_trace(go.Bar(
        x=dff['colname'],
        y=dff['missing_fraction'],
        marker_color=dff['color_bright'],

        hovertemplate=
        '<b>x</b>: %{x} <br>' +
        '<b>non_missing</b>: %{y} <br>' +
        '%{text}',
        text=dff['text'],
        name='missing'
    ))

    no_occurrences = str(dff['type'].value_counts().to_dict())
    title = f"<b>Overview DataFrame</b><br> <b>type-count</b> ({len(df.features)}): {no_occurrences};   " \
            f"<b>missing:</b> {dff['missing'].sum()} ({round(dff['missing'].sum() / (df.shape[0] * df.shape[1]) * 100, 2)}%);   " \
            f"<b>sort:</b> {sort}"

    fig.update_layout(
        title={
            'text': title,
            'font': {'size': 22}
        },
        xaxis_title="features",
        yaxis_title=f"fraction missing / not_missing",
        template='plotly_white',
        showlegend=False,
        barmode="relative"
    )

    return fig


def type_plotter(df, sort='original'):
    """
    Plots a barchart of an underlying pandas DataFrame with type of all columns and missing values.
    Args:
        df: pandas DataFrame
        sort: one out of 'original' (default), 'type', 'alphabetic', 'missing'

    Returns: plotly fig-object
    """

    dff = _build_data(df)
    dff = _set_color(dff)
    dff = _sort_df(dff, sort)
    dff = _add_text(dff, df)
    fig = _build_figure(dff, df, sort)
    return fig


if __name__ == '__main__':
    logger = logging.getLogger('app')
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler('replace.log')
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    content = {'a': ['a', np.nan, 'c', 'd', 'e', 'f', 'g', 'h'],
               'b': ['-' for i in range(8)],
               'c': [i for i in range(8)],
               'd': [np.nan for i in range(8)],
               'e': [True for i in range(8)],
               'g': ['a', 'b', 'b', 'b', 'a', 'a', 'b', 'a']
               }

    df = pd.DataFrame(data=content)
    df["g"] = df["g"].astype('category')

    # fig = type_plotter(df, sort="alphabetic")
    # fig.show()

    f = pd.read_csv("../../data/working_data.csv")
    f.iloc[:,2] = f.iloc[:,2].astype('category')
    f['new'] = [i for i in range(f.shape[0])]
    f['bool'] = [True for i in range(f.shape[0])]
    f.loc[[12,13,16,18,25],'bool'] = np.nan
    f['bool_1'] = [True for i in range(f.shape[0])]
    fig = type_plotter(f, sort="type")
    fig.show()