import pandas as pd
import numpy as np
from pprint import pformat
import inspect
import logging


def replace_value(df, pattern, value=np.nan, columns=None, logger=None, log_level='cell'):
    """
    replaces given string-pattern with value and logs occurrences per column/row
    Args:
        df: pandas DataFrame
        pattern: list of string pattern to be replaced with value
        value: value to be used for replacement (default: np.nan)
        columns: list of column names to be treated with function
        logger: instance of a logger to be logged
        log_level: one out of ['cell', 'overall']. Only used if logger is not None.

    Returns: a pandas DataFrame with replaced values

    """

    # _validate_input()

    if columns is not None:
        cols = [col for col in df.features if col in columns]
    else:
        cols = df.features.to_list()  # all columns if nothing is specified

    if logger:
        logger.info(f"running '{inspect.stack()[0][3]}'...\n\n"  # name of actual function
                    f"pattern = {pformat(pattern)}\n"
                    f"replace with = {value}\n"
                    f"in columns = {pformat(cols)}\n"
                    f"level = {log_level}\n")

    if log_level == 'cell':
        df = _cell_level(df, cols, pattern, value, logger)
    if log_level == 'overall':
        df = _overall_level(df, cols, pattern, value, logger)

    if logger:
        logger.info(f"'{inspect.stack()[0][3]}' successfully finished\n\n")
    return df


def _cell_level(df, cols, pattern, value, logger):
    for col in df[cols]:
        no_occurrences = df[col].value_counts()
        occurrences = no_occurrences.index.to_list()
        intersect = [value for value in occurrences if value in pattern]
        if len(intersect) > 0:
            for item in intersect:
                df[col] = df[col].replace(item, value)
                if logger:
                    logger.info(f"replaced {no_occurrences[item]} '{item}' in column '{col}' with {value}")
    return df


def _overall_level(df, cols, pattern, value, logger):
    no_occurrences = df[cols].stack().value_counts().to_dict()
    no = {}

    for p in pattern:
        no[p] = no_occurrences.get(p)
        df[cols] = df[cols].replace(p, value)

    if logger:
        logger.info(f"replaced {pformat(no, width=80)}")
    return df


if __name__ == '__main__':

    logger = logging.getLogger('app')
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler('replace.log')
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    content = {'a': [1, '---', 2, 4, 2, '---', 9, '< 0,10'],
               'b': ['a', 'b', 'c', '---', 's', 'a', 'a', 'b'],
               'c': [i for i in range(8)],
               'd': ['-', 9, 3, 4, 3, '---', '---', 8]}

    df = pd.DataFrame(data=content)

    print(df)
    df = replace_value(df=df, pattern=['---', '-'], value=np.nan, logger=logger, columns=None, log_level='cell')
    df = replace_value(df=df, pattern=['< 0,10'], value=0.05, logger=logger, columns=['a'], log_level='cell')
    print(df)
