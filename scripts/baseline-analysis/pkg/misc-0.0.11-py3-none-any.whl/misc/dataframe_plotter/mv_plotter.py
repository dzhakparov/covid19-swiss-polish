import numpy as np
import pandas as pd
import plotly.graph_objects as go
from misc.df_plotter.plotter import Plotter


class MissingValuePlotter(Plotter):
    """
        plots missing values of a pandas DataFrame per feature
        Args:
            df: pandas DataFrame
            sort: one out of 'original' (default), 'alphabetic', 'missing', 'not_missing'
            na: list of strings with patterns to replace with np.nan (default: ["n/a", "na", "???", ".", "NR", "", " ", '-', '---'])
    """

    def __init__(self, df, sort='original', na=["n/a", "na", "???", ".", "NR", "", " ", '-', '---'],
                 color_scale=[[0, 'rgb(255,255,255)'], [1, 'rgb(255,0,0)']]):
        self.df = df
        self.sort = sort
        self.na = na
        self.color_scale = color_scale
        self.dff = None
        self.fig = None
        self.no_missing_values = None
        self.total_values = None

    def get_plot(self):

        self._build_data()
        self._sort_df()
        self._build_fig()
        return self.fig

    def _build_data(self):

        for item in self.na:
            _df = self.df.replace(item, np.nan)  # replaces all defined na with np.nan

        data = pd.isna(_df)  # all values are 0 except missing values are 1

        self.no_missing_values = sum((data == 1).sum(axis=1))  # sums up missing values per feature
        self.total_values = data.shape[0] * data.shape[1]

        store = []
        for idx, col in enumerate(data):
            temp = data.iloc[:, idx]
            temp = temp.to_frame(name='value')
            temp = temp.reset_index()
            temp['id'] = temp['index']
            temp['index'] = temp.index
            temp['colname'] = col
            store.append(temp)

        self.dff = pd.concat(store)

        # convert type of column 'value' from bool to int (for heatmap)
        self.dff['value'] = self.dff['value'].astype('int64')

        self.total_missing_values = self.dff.loc[:, ['colname', 'value']].groupby('colname').sum().reset_index()
        self.total_missing_values = self.total_missing_values.rename({'value': 'total_missing'}, axis=1)

        self.dff = self.dff.merge(self.total_missing_values, left_on='colname', right_on='colname')

    def _sort_df(self):

        if self.sort == 'alphabetic':
            self.dff.sort_values(by=['colname', 'total_missing'], inplace=True)
        elif self.sort == 'missing':
            self.dff.sort_values(by=['total_missing', 'colname'], ascending=False, inplace=True)
        elif self.sort == 'not_missing':
            self.dff.sort_values(by=['total_missing', 'colname'], ascending=True, inplace=True)

    def _build_fig(self):

        title = f"{self._get_title()} <br> missing values: {self.no_missing_values} ( = red) from  {self.total_values} " \
                f"({round(self.no_missing_values / self.total_values * 100, 3)}%)"

        data = [go.Heatmap(x=self.dff['colname'],
                           y=self.dff['index'],
                           z=self.dff['value'],
                           text=self.dff['id'],
                           hovertemplate='id: %{text}<br>x: %{x}<br>missing: %{z}<br><extra></extra>',
                           colorscale=self.color_scale,
                           zmin=0,
                           zmax=1)]
        layout = go.Layout(
            title=title)
        self.fig = go.Figure(data=data, layout=layout)
        self._update_layout(title)


if __name__ == '__main__':

    content = {'x': ['a', np.nan, 'c', 'd', 'e', 'f', 'g', 'h'],
               'b': ['-' for i in range(8)],
               'v': [i for i in range(8)],
               'd': [np.nan for i in range(8)],
               'e': [True for i in range(8)],
               'g': ['a', 'b', 'b', 'b', 'a', 'a', 'b', 'a']
               }

    df = pd.DataFrame(data=content)
    df["g"] = df["g"].astype('category')

    fig = MissingValuePlotter(df, na=['-']).get_plot()
    fig.show()
