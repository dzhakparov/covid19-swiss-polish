import numpy as np
import pandas as pd
import plotly.graph_objects as go


def _discrete_colorscale(bvals, colors):
    """
    bvals - list of values bounding intervals/ranges of interest
    colors - list of rgb or hex colorcodes for values in [bvals[k], bvals[k+1]],0<=k < len(bvals)-1
    returns the plotly  discrete colorscale
    """
    if len(bvals) != len(colors) + 1:
        raise ValueError('len(boundary values) should be equal to  len(colors)+1')
    bvals = sorted(bvals)
    nvals = [(v - bvals[0]) / (bvals[-1] - bvals[0]) for v in bvals]  # normalized values

    dcolorscale = []  # discrete colorscale
    for k in range(len(colors)):
        dcolorscale.extend([[nvals[k], colors[k]], [nvals[k + 1], colors[k]]])
    return dcolorscale


class DiffPlotter():
    """
    This Plotter shows differences of 2 pandas DataFrame as heatmap
    color-code:
    header: 0=original, 1=renamed, 2=other type
    cells: 0=no difference, 3=other value, 4=other type
    """

    def __init__(self, df1, df2):
        self.df1 = df1
        self.df2 = df2

    def get_plot(self, changes=None):
        df, df_original, df_actual = self._build_df_diff()

        bvals = [0, 11, 12, 13, 14, 15]
        colors = ['white', 'red', 'blue', 'green', 'yellow']
        dcolorsc = _discrete_colorscale(bvals, colors)

        tickvals = [1, 10.5, 11.5, 12.5, 13.5]
        ticktext = ['', 'renamed col', 'other type col', 'other value', 'other type cell']

        x = df.columns.to_list()
        y = ["row" + str(i) for i in df.index.to_list()]
        y.insert(0, "column")
        del y[-1]
        z = df.values

        hovertext = list()
        for yi, yy in enumerate(y):
            hovertext.append(list())
            for xi, xx in enumerate(x):
                hovertext[-1].append('col: {}<br />original: {}<br />actual: {}'.format(xx, df_original.iloc[yi,xi], df_actual.iloc[yi,xi]))

        heatmap = go.Heatmap(z=z,
                             x=x,
                             y=y,
                             colorscale=dcolorsc,
                             colorbar=dict(thickness=25,
                                           tickvals=tickvals,
                                           ticktext=ticktext),
                             hoverinfo='text',
                             text=hovertext
                             )

        # lines = go.Scatter(x=['x', 'd'],
        #                    y=[0.5, 0.5],
        #                    mode='lines',
        #                    line_color='black', line_width=2.5)

        fig = go.Figure(data=[heatmap])
        fig.update_yaxes(autorange="reversed")

        return fig

    # TODO
    def _build_df_diff(self):
        content = {'x': [11, 13, 0, 0, 0, 0, 0, 0, 0],
                   'b': [0, 0, 13, 0, 0, 0, 0, 0, 0],
                   'c': [12, 0, 0, 0, 0, 0, 0, 0, 0],
                   'd': [0, 0, 0, 14, 0, 0, 0, 0, 0]}
        df_content = pd.DataFrame(data=content)

        original = {'x': ['a', np.nan, 'c', 'd', 'e', '-', 'g', '2020-10-11', '2'],
                   'b': [i for i in range(9)],
                   'c': [i for i in range(9)],
                   'd': ['a', 'a', 'b', 'c', 'b', 'a', 'b', 'c', 'a']}
        df_original = pd.DataFrame(data=original)

        df_actual = df_original.copy()
        df_actual.iloc[0, 0] = "XXX"
        df_actual.iloc[1, 1] = 25

        return df_content, df_original, df_actual


if __name__ == '__main__':

    content = {'a': ['a', np.nan, 'c', 'd', 'e', '-', 'g', '2020-10-11'],
               'b': [i for i in range(8)],
               'c': [i for i in range(8)],
               'd': ['a', 'a', 'b', 'c', 'b', 'a', 'b', 'c']}
    df1 = pd.DataFrame(data=content)

    df1['d'] = df1['d'].astype('category')

    content = {'a': ['a', 'sa', 'c', 'd', 'e', '-', 'g', 'k'],
               'b': [i for i in range(8)],
               'c': [i for i in range(8)],
               'd': ['a', 'a', 'b', 'c', 'b', 'a', 'b', 'c']}
    df2 = pd.DataFrame(data=content)

    plotter = DiffPlotter(df1, df2)
    fig = plotter.get_plot()
    fig.show()
