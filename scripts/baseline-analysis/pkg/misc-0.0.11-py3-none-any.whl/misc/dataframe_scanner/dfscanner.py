import pandas as pd
import logging
import os
import numpy as np
from datetime import datetime


class DfScanner:
    """
    DfScanner analyzes pandas DataFrames without any modifications. There are several tests_df_plotter options to display data
    in different forms. Each method will be logged in a external or internal logging file.
    """

    def __init__(self, df, logging=None):

        if isinstance(df,  pd.DataFrame):
            self.df = df
        else:
            raise Exception("df has to by an instance of pd.DataFrame!")

        if logging:
            self.logging = logging
        else:
            self.logging = self._initialize_logger()

        self.logging.info(f"logger '{self.logging.name}' successfully initialized")

    @staticmethod
    def _initialize_logger():
        script = str.split(os.path.basename(__file__), '.')[0]
        path = os.path.join(os.getcwd(), 'temp')
        if not os.path.isdir(path):
            os.mkdir(path)  # build temp directory for storing logger

        level = logging.INFO
        name = f"{path}/{script}"
        log_file = f"{name}.log"

        # FileHandler to log into file
        formatter = logging.Formatter('%(asctime)s.%(msecs)03d %(levelname)s: %(message)s')
        handler = logging.FileHandler(log_file)  # log into file
        handler.setFormatter(formatter)
        logger = logging.getLogger(script)
        logger.setLevel(level)
        logger.addHandler(handler)

        return logger

    def get_logger(self):
        return self.logging

    def first_method(self, log=True):
        if log:
            self.logging.info(f"log first_method")

    def aaa(self, cols=None, scan_for='numeric', log_level="cell"):
        res = {}
        print(self.df.dtypes[0])
        # for item in self.df.iloc[:,0]:
            # print(item)
            # print(type(item))
            # try:
            #     datetime_object = datetime.strptime(item, '%Y-%m-%d')
            #     print(f"item as Date: {datetime_object}")
            # except:
            #     continue
        for item in self.df.columns:
            try:
                no_nan_before = pd.isna(self.df.loc[:,item]).sum()
                obj = pd.to_numeric(self.df.loc[:,item], errors='coerce')
                no_nan_after = pd.isna(obj).sum()
                no_num = obj.count()
                print(no_nan_before)
                print(no_nan_after)
            except:
                print("ERROR")


if __name__ == '__main__':
    content = {'a': ['a', np.nan, 'c', 'd', 'e', '12', 'g', '2020-10-11'],
               'b': [i for i in range(8)],
               'c': [i for i in range(8)]}
    content['c'][6] = '-'
    df = pd.DataFrame(data=content)

    sc = DfScanner(df=df)
    sc.aaa()