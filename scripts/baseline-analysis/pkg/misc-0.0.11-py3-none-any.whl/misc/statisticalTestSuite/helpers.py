import numpy as np


def post_hoc_to_tuple(df):
    if df is not None:
        a = np.tril(df.values)  # get lower left triangle matrix
        b = np.where((a <= 0.05) & (a > 0))  # filter
        result = []
        for i in range(0, b[0].shape[0]):
            a1 = df.features[b[0][i]]
            a2 = df.features[b[1][i]]
            result.append((a1,a2,round(a[b[0][i], b[1][i]], 3)))
    return result


def means_to_string(s):
    """

    :param s:
    :return:
    """
    if s is not None:
        result = ""
        for index, value in s.items():
            result = result + str(index) + '=' + str(round(value, 3)) + ' / '
        result = result[:-2]
        return result


def post_hoc_to_string(df, level=0.05):
    """
    converts matrix with p-values to a simple string representation
    :param df: pandas DataFrame

              AD_Rural  AD_Urban  HC_Rural  HC_Urban
    AD_Rural -1.000000  0.040802  0.073529  0.532397
    AD_Urban  0.040802 -1.000000  1.000000  0.819494
    HC_Rural  0.073529  1.000000 -1.000000  1.000000
    HC_Urban  0.532397  0.819494  1.000000 -1.000000

    :return: string of significant p-values with groupnames   # AD_Urban <-> AD_Rural (0.041) / HC_Rural <-> AD_Rural (0.074)
    """
    if df is not None:
        a = np.tril(df.values)  # get lower left triangle matrix
        b = np.where((a <= level) & (a > 0))  # filter
        result = ""
        for i in range(0, b[0].shape[0]):
            a1 = df.features[b[0][i]]
            a2 = df.features[b[1][i]]
            result = result + a1 + ' <-> ' + a2 + f' ({round(a[b[0][i], b[1][i]], 3)}) / '

        result = result[:-2]
        return result