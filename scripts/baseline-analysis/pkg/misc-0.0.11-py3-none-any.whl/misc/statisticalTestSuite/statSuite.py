import os
import pandas as pd
import sys
from pathlib import Path
from misc.statisticalTestSuite.statTest import StatTest
from misc.statisticalTestSuite.statPlot import StatPlot
from misc.statisticalTestSuite.helpers import means_to_string, post_hoc_to_string


class StatSuite:

    def __init__(self, data, target=None, path=None, cols_to_analyze=None, cols_normal_distributed=None,
                 p_value_correction=None, test_significance_level=0.05, significance_level_post_hoc=0.05):
        """
        This class gets a pandas DataFrame with at least one categorical Feature (target) and multiple numerical and/or
        categorical features. It will calculate statistical Tests (anova, t-test, ...) and post-hocs for each numerical
        or categorical column selected and tests_df_plotter them if desired.

        Args:
            data: pandas DataFrame with numerical and categorical columns
            target: name of (categorical) target column as string
            path: ...
            cols_to_analyze: None (default) will take all available columns. If a list of strings with desired column headers is supported these columns will be taken.
            cols_normal_distributed: None (default) will calculate if a column splitted by target is distributed normally or not. A list of strings with desired column names to be set as normal distributed is supported.
            p_value_correction: None (default) will apply no correction. 'bonferroni' as argument applies a bonferroni-correction on all calculated p-values
            test_significance_level: 0.05 (default) as alpha-error. Numeric numbers between 0 and 1 are supported.
            significance_level_post_hoc: 0.05 (default) as alpha-error. Numeric numbers between 0 and 1 are supported.
        """

        self.data = data
        self.target = target
        self.cols_to_analyze = cols_to_analyze
        self.cols_normal_distributed = cols_normal_distributed
        self.p_value_correction = p_value_correction
        self.test_significance_level = test_significance_level
        self.significance_level_post_hoc = significance_level_post_hoc
        self.results_table = None  # stores results after applying statistical tests
        self.statisticalTest = None
        self.statisticalTests = []
        self.cols = None
        self.no_cols = 0
        self.path = path
        self.locations = None  # defines locations for output (data/output and data/output/plots)

        self._build_output_directory()
        self._build_cols_to_analyze()
        self._initialize_result_table()

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, df):
        if not isinstance(df, pd.DataFrame): raise Exception("data must be of type pd.DataFrame")
        self._data = df

    @property
    def target(self):
        return self._target

    @target.setter
    def target(self, target):
        if target is None:
            if self._data.iloc[:, 0].dtype.name != 'category':
                raise Exception("if target is None, first column of DataFrame must be of type 'category'")
            else:
                self._target = self._data.columns[0]
        else:
            if self._data.loc[:, target].dtype.name != 'category':
                raise Exception("target must be of type 'category'")
            else:
                self._target = target

    @property
    def test_significance_level(self):
        return self._test_significance_level

    @test_significance_level.setter
    def test_significance_level(self, x):
        if 0 <= x <= 1:
            self._test_significance_level = x
        else:
            raise Exception("test_significance_level must be an float number between 0 and 1!")

    @property
    def significance_level_post_hoc(self):
        return self._significance_level_post_hoc

    @significance_level_post_hoc.setter
    def significance_level_post_hoc(self, x):
        if 0 <= x <= 1:
            self._significance_level_post_hoc = x
        else:
            raise Exception("significance_level_post_hoc must be an float number between 0 and 1!")

    def get_result_table(self):
        return self.results_table

    def run(self, store_csv=True):
        """
        Starts to calculate all statistics

        Args:
            store_csv: If True (default) the table will be stored as output.csv in folder output

        """
        for idx, item in enumerate(self.cols):
            if self.cols_normal_distributed is not None:
                if item in self.cols_normal_distributed:
                    normality_manual = True
                else:
                    normality_manual = False
            else:
                normality_manual = False

            self.statisticalTest = StatTest(col_feature=self._data[item], col_by=self._data[self._target],
                                            normality_manual=normality_manual,
                                            test_significance_level=self.test_significance_level)
            self._fill_results_table(idx)
            self.statisticalTests.append(self.statisticalTest)

        self.results_table.sort_values(by=['p_value'], inplace=True)

        if self.p_value_correction is not None:
            self._update_p_values_corrected()

        if store_csv:
            self.results_table.to_csv(self.locations[0] / 'output.csv')

    def plot(self, plot_choice=None, interactive=False, show_group_diff=True):
        """
        Plots all numerical columns of calculated statistical tests

        Args:
            plot_choice: None (all available plots will be calculated) or list of ['histogram', 'qqplot', 'boxplot'] interactive: If False (default) a .jpeg fill with the tests_df_plotter will be generated if True it will be an interactive .html file.
            show_group_diff: If True (default) lines which represent significant differences in group means are displayed in tests_df_plotter
        """
        for idx, item in enumerate(self.statisticalTests):
            if item.df.dtype in ['float64', 'int64'] and 'ERROR' not in item.feature:
                StatPlot(statisticalTest=item, location=self.locations[1],
                         filename=idx, interactive=interactive, plot_choice=plot_choice,
                         show_group_diff=show_group_diff).run()

    def _build_cols_to_analyze(self):
        """
        builds list of columns to be analyzed (self.cols). If no valid column is found and Exception is thrown.
        """
        if self.cols_to_analyze is None:
            self.cols = [col for col in self._data.columns if col != self._target]  # analyze all
        else:
            self.cols = [col for col in self.cols_to_analyze if
                         col != self._target and col in self._data.columns]  # analyze selected cols

        self.no_cols = len(self.cols)

        if self.no_cols == 0:
            raise Exception("no valid columns found!")

    def _initialize_result_table(self):
        """
        Create an empty DataFrame (nan) with desired columns and number of rows according to number of columns to be analyzed.
        """
        self.results_table = pd.DataFrame(columns=['grouped_by', 'grouped_levels', 'feature', 'feature_type',
                                                   'number_obs', 'normality', 'normality_manual', 'var_homogeneity',
                                                   'testname', 'p_value', 'p_value_adj', 'means', 'post_hoc_test',
                                                   'post_hoc'],
                                          index=list(range(0, self.no_cols)))
        self.results_table.index.names = ['idx']

    def _fill_results_table(self, idx):
        """
        Fills empty DataFrame (results_table) with calculated results.
        Args:
            idx: row number as integer

        Returns: a pandas DataFrame filled with statistical results
        """
        self.results_table.loc[idx, 'testname'] = self.statisticalTest.test
        self.results_table.loc[idx, 'grouped_by'] = self.statisticalTest.col_by.name
        self.results_table.loc[idx, 'grouped_levels'] = self.statisticalTest.group_names
        self.results_table.loc[idx, 'feature'] = self.statisticalTest.feature
        self.results_table.loc[idx, 'feature_type'] = self.statisticalTest.type_feature
        self.results_table.loc[idx, 'number_obs'] = self.statisticalTest.group_sizes
        self.results_table.loc[idx, 'normality'] = self.statisticalTest.normality_status
        self.results_table.loc[idx, 'normality_manual'] = self.statisticalTest.normality_manual
        self.results_table.loc[idx, 'var_homogeneity'] = self.statisticalTest.var_homogeneity_status
        self.results_table.loc[idx, 'means'] = means_to_string(self.statisticalTest.group_means)
        self.results_table.loc[idx, 'p_value'] = self.statisticalTest.pvalue
        self.results_table.loc[idx, 'post_hoc_test'] = self.statisticalTest.post_hoc_test
        self.results_table.loc[idx, 'post_hoc'] = post_hoc_to_string(self.statisticalTest.post_hoc,
                                                                     level=self.significance_level_post_hoc)

    def _update_p_values_corrected(self):
        """
        If p_value_correction is True, a alpha-inflation correction (bonferroni) is applied to calculate
        corrected p-values. Bonferroni multiplies calculated p-values with number of tests applied. If result is bigger
        than 1 it will be set to 1.
        Returns: DataFrame with filled column 'p_value_adj'
        """
        number_of_valid_tests = self.results_table['p_value'].count()

        # bonferroni
        if self.p_value_correction == 'bonferroni':
            self.results_table['p_value_adj'] = self.results_table['p_value'] * number_of_valid_tests
            self.results_table['p_value_adj'] = self.results_table['p_value_adj'].apply(lambda x: 1 if x > 1 else x)

        # holm
        if self.p_value_correction == 'holm':
            pass  # TODO

        def remove_post_hoc(x):
            if x['post_hoc'] is not None:
                if x['p_value_adj'] > self.test_significance_level:
                    x['post_hoc'] = ""
                    x['post_hoc_test'] = ""
            return x

        # update results_table (remove post_hoc for p_value_adj > sig_level)
        self.results_table = self.results_table.apply(remove_post_hoc, axis=1)

    @staticmethod
    def _get_working_directory():
        return Path(os.getcwd())

    def _build_output_directory(self):
        """
        builds directories for output (table) and plots. If no argument is supported (path) these new build folders will
        ly in the current working directory 'output' and 'output/tests_df_plotter'
        """
        if self.path is None:
            self.path = self._get_working_directory()
        else:
            try:
                self.path = Path(self.path)
            except TypeError:
                print(f"path '{self.path}' could'n be converted to a Path-object! '{self._get_working_directory()}' "
                      f"was taken as default directory for output instead!")
                self.path = self._get_working_directory()

        self.locations = [self.path / 'output',
                          self.path / 'output/tests_df_plotter']

        for location in self.locations:
            if not os.path.isdir(location):
                try:
                    os.mkdir(location)
                except OSError:
                    print("Creation of the directory %s failed" % location)
                    sys.exit()
                else:
                    print("Successfully created the directory %s " % location)

    def combine_features(self, key_cols, new_name=None, drop_nan=True, drop_key_cols=True):
        """
        This method creates/combines new feature from existing ones. Two categorical columns can be merged to one
        new column. If one of both merged columns was the target column the new resulting feature will be new 'target'
        automatically.

        Args:
            key_cols: list of columns in df which should be combined to new column
            new_name: new names for new feature as string. If argument is None (default) the new column will be named 'key'
            drop_nan: boolean, should nan in each key_cols be removed?
            drop_key_cols: boolean, should columns combined to new column be deleted from df?
        """

        if new_name is None:
            new_name = 'key'

        names = [name for name in self.data.columns if name in key_cols]
        names_intersection = names.copy()

        if len(names) > 1:
            new_df = self.data[names]
            new_df[new_name] = new_df[names[0]].str.cat(new_df[names[1]], sep="_")  # TODO: better solution?
            del names[:2]
            while len(names) != 0:
                new_df[new_name] = new_df[new_name].str.cat(new_df[names[0]], sep="_")
                del names[:1]

            self.data = pd.concat([self.data, new_df[new_name]], axis=1)

            if drop_nan:
                self.data.dropna(subset=[new_name], inplace=True)
            else:
                self.data[new_name] = self.data[new_name].fillna('category_with_na_in_key')

            if drop_key_cols:
                self.data.drop(names_intersection, axis=1, inplace=True)

            self.data = self.data.astype({new_name: 'category'})

            if self.target in key_cols:
                self.target = new_name
                print(f"ATTENTION: changed 'target' to {new_name}")