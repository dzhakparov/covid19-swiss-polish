import os
import pandas as pd
import numpy as np
import inspect
from pprint import pformat
from pathlib import Path
from datetime import datetime
from pandas.api.types import CategoricalDtype
import sys
import math
from functools import wraps
import json

from misc.df_plotter.matrix_plotter import MatrixPlotter
from misc.df_plotter.mv_plotter import MissingValuePlotter
from misc.df_plotter.column_plotter import ColumnPlotter
from misc.df_plotter.type_plotter import TypePlotter
from misc.df_plotter.box_plotter import BoxPlotter


# TODO: compare df's
# 1.
# 2.

# log = True/False
# log_modes = (io, files, details, summary)
# each function can overwrite behavior of global log_modes

class Preprocessor:

    def __init__(self, df, log=True, log_modes=('io', 'summary', 'details', 'files'), show_no_entries='all'):
        """
        'Preprocessor' is a class which helps preprocessing and logging pandas data.frame. The behaviour of 'log' and
        'log_modes' can be overridden be each method.
        Args:
            df: pandas DataFrame
            log: boolean (default: True)
            log_modes: one or more out of 'io', 'summary', 'details', 'files' as tuple
        """

        self.validator = Validator(obj=self)  # validates input-values and correct/adjusts them if possible
        self.logger = Logger(obj=self, log=log, log_modes=log_modes, show_no_entries=show_no_entries)

        if isinstance(df, pd.DataFrame):
            self.df_actual = df.copy()  # actual df
            self.df_original = df.copy()  # original df (unchanged)
            self.df_step = df.copy()  # stores pre-last processed DataFrame
        else:
            raise Exception("df has to by an instance of pd.DataFrame!")

        self.last_called_function = None  # name of last called function (by decorator)
        self.called_functions = []  # stores names of each function applied in correct order (for comparing df's)
        self.df_development = []  # stores actual df after each transformation (for comparing df's)
        self.input = {}  # stores updated/validated inputs of called function
        self.output = {}  # stores generated output for logging reason
        self.columns = {}  # stores which columns are found and which are not found to apply given method

    # decorator
    def call_function(fn):
        @wraps(fn)
        def call_function_intern(self, *args, **kwargs):
            self.df_step = self.df_actual.copy()  # stores actual df before applying function (difference Plotter)
            self.last_called_function = fn.__name__
            # gets a validated/updated input dictionary with parameters of same length as original
            self.input = self.validator.input(self.last_called_function,
                                              **kwargs)  # returns all input parameters as dictionary
            log, log_modes = self.logger.get_function_log_and_log_modes(**kwargs)
            show_no_entries = self.logger.get_no_entries(**kwargs)

            # function-call
            self.output = fn(self, *args, **kwargs)  # output is a dictionary with all output for logging reasons

            self.called_functions.append(self.last_called_function)
            self.df_development.append(self.df_actual)

            if log:
                self.logger.logging(self.last_called_function, log_modes, show_no_entries)

            return None

        return call_function_intern

    @staticmethod
    def _combine_features(x, mode):
        """
        Args:
            x: pandas Series of various number of columns (cells)
            mode: one out of ['binary']

        Returns: value of combined feature cell
        """
        if mode == 'binary':
            if 1 in x.values:
                return 1
            elif math.isnan(sum(x.values)):
                return np.nan
            else:
                return 0

    # OKAY / TESTED
    @call_function
    def rename_columns(self, rename_dict, **kwargs):
        """
        renames column names of dataframe
        Args:
            rename_dict: a dictionary with old column-name asa key and new column-name as value
            log: boolean (default: None). 'log' can override the class behaviour for this method
            log_modes: tuple (default: None) with one or more values of 'io', 'summary', 'details', 'files'.
            local 'log_modes' overwrites class behavior for this method
        """

        if self.input['rename_dict']:
            cols_found = [i for i in list(self.input['rename_dict'].keys()) if i in self.df_actual.columns]
            cols_not_found = [i for i in list(self.input['rename_dict'].keys()) if i not in self.df_actual.columns]
            self.columns.update({'columns not found': cols_not_found, 'columns found': cols_found})
            rename_dict_mod = {your_key: self.input['rename_dict'][your_key] for your_key in cols_found}
            self.df_actual.rename(columns=rename_dict_mod, inplace=True)

        return {'columns names before': self.df_step.columns.to_list(),
                'columns names after': self.df_actual.columns.to_list()}

    # OKAY / TESTED
    @call_function
    def arrange_columns(self, mode='alpha', **kwargs):
        """
        arranges columns in DataFrame alphabetically, reversed alphabetically, by type, original or by list
        Args:
            mode: one out of 'alpha', 'alpha_rev', 'original', 'type' or a list or sublist with column-names
            log: boolean (default: None). 'log' can override the class behaviour for this method
            log_modes: tuple (default: None) with one or more values of 'io', 'summary', 'details', 'files'.
                local 'log_modes' overwrites class behavior for this method
        """

        mode_mod = self.input['mode']
        colnames = self.df_actual.columns.to_list()
        if mode_mod == 'alpha':
            sorted_colnames = sorted(colnames)

        elif mode_mod == 'alpha_rev':
            sorted_colnames = sorted(colnames, reverse=True)

        elif mode_mod == 'original':
            original_colnames = self.df_original.columns.to_list()
            existing_colnames = [i for i in self.df_actual if i in original_colnames]
            additional_colnames = [i for i in self.df_actual if i not in original_colnames]
            sorted_colnames = existing_colnames + additional_colnames

        elif mode_mod == 'type':
            cols = self.df_actual.columns.to_list()
            type = [str(i) for i in self.df_actual.dtypes.to_list()]
            df = pd.DataFrame({'cols': cols,
                               'type': type})

            df.sort_values(by=['type', 'cols'], inplace=True)
            sorted_colnames = df['cols'].values.tolist()

        else:  # in case of list
            colnames = [i for i in mode_mod if i in self.df_actual.columns]
            sorted_colnames = colnames + self.df_actual.drop(colnames, axis=1).columns.to_list()

        # arrange columns
        self.df_actual = self.df_actual[sorted_colnames]

    @call_function
    def drop_columns(self, **kwargs):
        """
        drops certain column by name or type
        Args:
            additional arguments (kwargs): 'endswith', 'startswith', 'contains', 'cols', 'empty'
        """

        columns_to_drop = None
        columns_not_found = None

        if 'startswith' in self.input['dropping parameter']:
            columns_to_drop = [i for i in self.df_actual.columns if
                               i.startswith(self.input['dropping parameter']['startswith'])]
        if 'endswith' in self.input['dropping parameter']:
            columns_to_drop = [i for i in self.df_actual.columns if
                               i.endswith(self.input['dropping parameter']['endswith'])]
        if 'contains' in self.input['dropping parameter']:
            columns_to_drop = [i for i in self.df_actual.columns if self.input['dropping parameter']['contains'] in i]
        if 'cols' in self.input['dropping parameter']:
            columns_to_drop = [i for i in self.input['dropping parameter']['cols'] if i in self.df_actual.columns]
            columns_not_found = [i for i in self.input['dropping parameter']['cols'] if i not in self.df_actual.columns]
        if 'empty' in self.input['dropping parameter']:
            columns_to_drop = [i for i in self.df_actual.columns if self.df_actual[i].isnull().all()]
        if 'tresh' in self.input[
            'dropping parameter']:  # tresh -> float: maximal fraction missing values, int (0, shape(df)): maximal number missing values
            tresh = self.input['dropping parameter']['tresh']
            if isinstance(tresh, float):
                tresh = np.floor(tresh * self.df_actual.shape[0])
            columns_to_drop = [i for i in self.df_actual.columns if self.df_actual[i].isnull().sum() >= tresh]

        # TODO: by type -> drops only numerics or drops all but numerics etc.

        if columns_to_drop:
            self.df_actual.drop(columns_to_drop, axis=1, inplace=True)

        return {'columns to drop': columns_to_drop, 'columns not found': columns_not_found}

    @call_function
    def replace_values(self, pattern, value=np.nan, columns=None, column_type=None, **kwargs):
        """
        replaces given string-pattern with value and logs occurrences per column/row
        Args:
            log_modes:
            log: boolean, should method be logged?
            pattern: list of string pattern to be replaced with value
            value: value to be used for replacement (default: np.nan)
            columns: list of column names to be treated with function
            column_type: list of column_types to be treated ['numerics', 'object', 'category', 'date']
        """

        if self.input['columns'] is not None:
            cols = [col for col in self.df_actual.columns if col in self.input['columns']]
        else:
            cols = self.df_actual.columns.to_list()  # all columns if nothing is specified

        if self.input['column_type'] is not None:
            cols_temp = []
            for item in self.input['column_type']:
                if item in ['numerics', 'object', 'category', 'date']:
                    if item == 'numerics':
                        types = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
                    else:
                        types = item
                    selected_type_cols = self.df_actual.select_dtypes(include=types).columns.to_list()
                    intercept = [i for i in selected_type_cols if i in cols]
                    cols_temp.append(intercept)
            cols = [item for sublist in cols_temp for item in sublist]  # flatten list

        if cols:
            # applies replacement and gives back statistics of occurrences
            no_cell_level, no_global = self._replacements(cols)

        return {'no_cell_level': no_cell_level, 'no_global': no_global}

    @call_function
    def convert_column_type(self, columns_dict, **kwargs):
        """

        Args:
            columns_dict:
            log:
            log_modes:
            **kwargs:

        Returns:

        """
        if self.input['columns_dict']:
            columns_dict_mod = {i: self.input['columns_dict'][i] for i in self.input['columns_dict'].keys() if
                                i in self.df_actual.columns}

        cols_found = list(columns_dict_mod.keys())
        cols_not_found = [i for i in list(self.input['columns_dict'].keys()) if i not in self.df_actual.columns]

        self.columns.update({'columns found': cols_found, 'columns not found': cols_not_found})

        introduced_na = {}  # stores number of missing values per column

        for key, value in columns_dict_mod.items():

            no_na_before = self.df_actual[key].isna().sum()  # number of missing values before conversion

            if value[0] in ['numeric']:
                self.df_actual[key] = pd.to_numeric(self.df_actual[key], errors='coerce')

            if value[0] in ['date']:
                if 'date_format' not in kwargs:  # default value if nothing is supported
                    date_format = '%Y-%m-%d'
                else:  # value if 'date_format' is supported as parameter
                    date_format = kwargs['date_format']
                if value[1] != '':  # value if a value for a specific column is supported in tuple
                    date_format = value[1]
                self.df_actual[key] = pd.to_datetime(self.df_actual[key], format=date_format, errors='coerce')

            if value[0] in ['category', 'category_ordered']:
                if value[1] != '':
                    categories = value[1]
                    if value[0] == 'category':
                        cat_type = CategoricalDtype(categories=categories, ordered=False)
                    else:
                        cat_type = CategoricalDtype(categories=categories, ordered=True)
                else:
                    cat_type = CategoricalDtype(ordered=False)
                self.df_actual[key] = self.df_actual[key].astype(cat_type, errors='ignore')

            no_na_after = self.df_actual[key].isna().sum()  # number of missing values after conversion
            if no_na_before != no_na_after:
                introduced_na[key] = no_na_after - no_na_before

        type_before = self.df_step[cols_found].dtypes.to_dict()
        type_after = self.df_actual[cols_found].dtypes.to_dict()

        return {'introduced nas': introduced_na, 'object type before transformation': type_before,
                'object type after transformation': type_after}

    @call_function
    def combine_features(self, combine_dict, mode='binary', drop=True, log=None, log_modes=None):
        """
        combines two or more features to one new feature. At the moment only binary features can be handled.
        combine_dict: dict with name of new category as key and column-names of features to apply
        exp. {'allergies': ['allergy_pokarmowa', 'allergy_pollen_gras_hair_mites', 'other_allergy'],
              'CVD': ['heart_failure', 'coronary_artery_disease', 'atrial_fibrillation']},
        drop: boolean (default: True), should original features be dropped?
        mode: one out of ['binary']   # TODO: sum, max (num not num) etc.
        """

        cols_found = [item for sublist in self.input['combine_dict'].values() for item in sublist if
                      item in self.df_actual.columns]
        cols_not_found = [item for sublist in self.input['combine_dict'].values() for item in sublist if
                          item not in self.df_actual.columns]

        modified_combine_dict = self.input['combine_dict'].copy()

        if cols_not_found:  # drop columns that are not in self.df.columns etc. (update dict)
            for col in cols_not_found:
                for key, value in modified_combine_dict.items():
                    if col in value:
                        modified_combine_dict.update({key: [i for i in value if i not in cols_not_found]})

        empty = []
        for key, value in modified_combine_dict.items():
            if len(value) == 0:
                empty.append(key)

        for item in empty:
            del modified_combine_dict[item]

        if self.input['mode'] == 'binary':
            for col in cols_found:
                if not np.issubdtype(self.df_actual[col].dtype, np.number):
                    raise Exception(f"Column '{col}' seems not to be numeric! (mode='binary')")
                invalid_values = [i for i in self.df_actual[col] if i not in [0, 1] and str(i) != 'nan']
                if invalid_values:
                    raise Exception(f"Column '{col}' seems to contain values differ from 0,1 or np.nan!")

        for key, value in modified_combine_dict.items():
            self.df_actual[key] = self.df_actual.loc[:, value].apply(self._combine_features, args=(self.input['mode'],),
                                                                     axis=1)

        if drop:
            self.df_actual.drop(cols_found, axis=1, inplace=True)

        return {'combine_dict': self.input['combine_dict'], 'combine_dict_modified': modified_combine_dict}

        # if log:
        #     self._logging(functionname, log_modes, empty=empty, combine_dict=combine_dict_mod,
        #                   modified_combine_dict=modified_combine_dict,
        #                   mode=mode_mod, drop=drop, cols_not_found=cols_not_found)

    # OKAY
    def get_data(self, type='actual'):
        if type == 'actual':
            return self.df_actual
        if type == 'original':
            return self.df_original

    # OKAY
    def get_summary(self, type='category', sort=None):
        """ returns a summary of the actual data frame with all columns and its types
        Args:
            type: one out of ['category'] as string
            sort: a tuple with (column-name, boolean) with a valid column-name out of ['names', 'types', 'categories']

        Returns: a pandas DataFrame with a summary of the actual data
        """

        # functionname = inspect.stack()[0][3]
        # sort_mod = self.validator.input(functionname, sort=sort)
        sort_mod = None

        if type == 'category':

            df = pd.DataFrame({'names': self.df_actual.columns.to_list(),
                               'types': [str(i) for i in list(self.df_actual.dtypes)]})

            # add categories for categorical columns, min and max for numerical columns and number of missing values
            cats, min, max, na = [], [], [], []

            for idx, item in df.iterrows():
                if df.loc[idx, 'types'] == 'category':
                    cats.append(str(list(self.df_actual[item['names']].dtypes.categories)))
                else:
                    cats.append("")
                if df.loc[idx, 'types'] in ['int64', 'float64']:
                    min.append(self.df_actual[item['names']].min(skipna=True))
                    max.append(self.df_actual[item['names']].max(skipna=True))
                else:
                    min.append(np.nan)
                    max.append(np.nan)
                na.append(self.df_actual[item['names']].isna().sum())

            df['categories'] = cats
            df['max'] = max
            df['min'] = min
            df['na'] = na

            if sort_mod is not None:
                df.sort_values(sort_mod[0], ascending=sort_mod[1], inplace=True)

        return df

    def get_plot(self, type="ColumnPlotter", *args, **kwargs):
        plot = getattr(sys.modules[__name__], type)
        fig = plot(self.df_actual, *args, **kwargs).get_plot()
        return fig

    # def _logging(self, functionname, log_modes, **kwargs):
    #
    #     with open(self.file, 'a+') as f:
    #         f.write(f"\n{self._get_actual_time()}: {functionname.upper()}\n")
    #
    #     if 'files' in log_modes:
    #         self._write_files(functionname)
    #
    #     if 'summary' in log_modes:
    #         with open(self.file, 'a+') as f:
    #             f.write(f"\nlog_mode: 'summary': \n"
    #                     f"\tshape before applying '{functionname}': {self.df_step.shape}\n"
    #                     f"\tshape after applying '{functionname}': {self.df_actual.shape}\n")
    #
    #     if functionname == 'rename_columns':
    #
    #         rename_dict = kwargs['rename_dict']
    #         cols_found = kwargs['cols_found']
    #         cols_not_found = kwargs['cols_not_found']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\trenaming ['old': 'new'] ({len(rename_dict)}) = {pformat(self._shorten_container(rename_dict, 20))}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 f.write(f"\tcolumn found and renamed [{len(cols_found)}]: {pformat(self.rename_dict_mod)}\n")
    #                 f.write(f"\tcolumn not found [{len(cols_not_found)}]: {pformat(cols_not_found)}\n")
    #
    #     if functionname == 'arrange_columns':
    #         mode = kwargs['mode']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tmode = {mode}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 # TODO: think about it...
    #                 f.write(f"\told arrangement: {pformat(self.df_original.columns.to_list())}\n")  # self.df_step
    #                 f.write(f"\tnew arrangement: {pformat(self.df_actual.columns.to_list())}\n")
    #
    #     if functionname == 'drop_columns':
    #         to_drop = kwargs['to_drop']
    #         not_found = kwargs['not_found']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tmode = {kwargs}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 f.write(f"\tcolumns found and deleted [{len(to_drop)}]: {pformat(to_drop)}\n")
    #                 if 'cols' in kwargs:
    #                     f.write(f"\tcolumns not found [{len(not_found)}]: {pformat(not_found)}\n")
    #
    #     if functionname == 'convert_column_type':
    #         columns_dict = kwargs['columns_dict']
    #         columns_dict_mod = kwargs['columns_dict_mod']
    #         introduced_na = kwargs['introduced_na']
    #         cols_concerned = list(columns_dict_mod.keys())
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tcolumn_dict = {pformat(columns_dict)}\n"
    #                         f"\tmodified column_dict = {pformat(columns_dict_mod)}\n"
    #                         f"\tnot found columns: {pformat('aaa')}\n")  # TODO: replace 'aaa' by correct value
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\tintroduced na: {pformat(introduced_na)}\n")
    #                 f.write(f"\nold column type = \n{pformat(self.df_step[cols_concerned].dtypes)}\n\n"
    #                         f"types after conversion = \n{pformat(self.df_actual[cols_concerned].dtypes)}\n")
    #
    #     if functionname == 'combine_features':
    #         empty = kwargs['empty']
    #         combine_dict = kwargs['combine_dict']
    #         modified_combine_dict = kwargs['modified_combine_dict']
    #         mode = kwargs['mode']
    #         drop = kwargs['drop']
    #         cols_not_found = kwargs['cols_not_found']
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 f.write(f"\tnot found columns in original data: {pformat(cols_not_found)}\n")
    #                 f.write(f"\tdropped new combined_features: {empty}\n")
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tcombine_dict = {pformat(combine_dict)}\n"
    #                         f"\tmodified combine_dict = {pformat(modified_combine_dict)}\n"
    #                         f"\tmode = {mode}\n"
    #                         f"\tdrop = {drop}\n")
    #
    #     if functionname == 'replace_values':
    #         pattern = kwargs['pattern']
    #         value = kwargs['value']
    #         columns = kwargs['columns']
    #         column_type = kwargs['column_type']
    #         cols = kwargs['cols']
    #         no_cell_level = kwargs['no_cell_level']
    #         no_global = kwargs['no_global']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tpattern = {pformat(pattern)}\n"
    #                         f"\treplace with = {value}\n"
    #                         f"\tin columns = {pformat(columns)}\n"
    #                         f"\tcolumn_type = {pformat(column_type)}\n"
    #                         f"\tconsidered columns ({len(cols)}) = {self._shorten_container(cols, 20)}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details':\n")
    #                 for item in no_cell_level.values():
    #                     f.write(item[0])
    #                 f.write(f"\n\tsummary:\n{pformat(no_global)}\n")

    def _replacements(self, cols):

        no_occurrences = self.df_actual[cols].stack().value_counts().to_dict()
        nas = self.df_actual.isnull().sum().sum()
        no_global = {}

        # global occurrences
        for idx, pattern in enumerate(self.input['pattern']):
            for p in pattern:
                if p is np.nan:
                    no_global[p] = nas
                else:
                    no_global[p] = no_occurrences.get(p)

        # occurrences on cell level
        no_cell_level = []
        for idx, pattern in enumerate(self.input['pattern']):
            for col in self.df_actual[cols]:
                # temp_replacements = []
                no_occurrences = self.df_actual[col].value_counts()
                nas = self.df_actual[col].isnull().sum()
                occurrences = no_occurrences.index.to_list()
                intersect = [value for value in occurrences if value in pattern]

                if nas > 0 and np.nan in pattern:
                    no_cell_level.append(f"replaced {nas} 'np.nan' in column '{col}' with '{self.input['value'][idx]}'")
                    self.df_actual[col] = self.df_actual[col].fillna(self.input['value'][idx])

                if len(intersect) > 0:
                    for item in intersect:
                        no_cell_level.append(
                            f"replaced {no_occurrences[item]} '{item}' in column '{col}' with '{self.input['value'][idx]}'")
                        self.df_actual[col] = self.df_actual[col].replace(item, self.input['value'][idx])

        return no_cell_level, no_global


class Validator:
    """
    validates input values and gives back the validated/updated version of the input as an dictionary
    or rises an Exception. Validator methods gets the same parameters as their original method and are returning a
    dictionary with the same updated/validated input parameters
    """

    def __init__(self, obj):
        self.obj = obj
        # self.columns = {}

    def input(self, functionname, **kwargs):
        # get all methods (without dunder-methods) of class Validator
        object_methods = [method_name for method_name in dir(self)
                          if callable(getattr(self, method_name)) and not method_name.endswith('__')]

        if f"_{functionname}" in object_methods:
            return getattr(self, f"_{functionname}")(**kwargs)
        else:
            return {'unvalidated': kwargs}

    @staticmethod
    def _combine_features(**kwargs):
        if not isinstance(kwargs['combine_dict'], dict):
            raise Exception("combine_dict has to be of type dict!")
        for key, value in kwargs['combine_dict'].items():
            if not isinstance(key, str):
                raise Exception("keys in 'combine_dict' have to be of type str")
            if not isinstance(value, list):
                raise Exception("values in 'combine_dict' have to be of type list")
        return {'combine_dict': kwargs['combine_dict'], 'mode': kwargs['mode']}

    @staticmethod
    def _rename_columns(rename_dict, **kwargs):
        if not isinstance(rename_dict, dict):
            raise Exception("rename_dict has to be of type dict!")
        return {'rename_dict': rename_dict}

    @staticmethod
    def _arrange_columns(**kwargs):
        if not isinstance(kwargs['mode'], str):
            if not isinstance(kwargs['mode'], list):
                raise Exception(f"mode has to be of type 'str' or of type 'list'")
        else:
            if kwargs['mode'] not in ['alpha', 'alpha_rev', 'type', 'original']:
                raise Exception(f"mode has to be one out of 'alpha', 'alpha_rev', 'type', 'original'")
        return {'mode': kwargs['mode']}

    @staticmethod
    def _combine_features(**kwargs):
        if not isinstance(kwargs['combine_dict'], dict):
            raise Exception("combine_dict has to be of type dict!")
        for key, value in kwargs['combine_dict'].items():
            if not isinstance(key, str):
                raise Exception("keys in 'combine_dict' have to be of type str")
            if not isinstance(value, list):
                raise Exception("values in 'combine_dict' have to be of type list")
        return {'combine_dict': kwargs['combine_dict'], 'mode': kwargs['mode']}

    @staticmethod
    def _replace_values(pattern, value=np.nan, columns=None, column_type=None, **kwargs):
        if not isinstance(pattern, list) and isinstance(value, list):
            raise Exception(f"'pattern' and 'value' have to be of type list")

        if len(pattern) != len(value):
            raise Exception(f"length of 'pattern' and 'value' does not correspond!")

        pattern_list_of_list = [all(isinstance(i, list) for i in pattern)][0]
        if not pattern_list_of_list:
            raise Exception(f"input does not fit desired format!")
        else:
            return {'pattern': pattern, 'value': value, 'columns': columns, 'column_type': column_type}

    def _convert_column_type(self, columns_dict, **kwargs):
        if not isinstance(columns_dict, dict):
            raise Exception("columns_dict has to be of type dict!")

        update = [(i,) if isinstance(i, str) else i for i in
                  columns_dict.keys()]  # update key to tuple if it's a single string
        columns_dict = dict(zip(update, list(columns_dict.values())))

        for item in columns_dict.values():
            if not isinstance(item, tuple) or len(item) != 2:
                raise Exception("values of 'column_dict' have to be tuples of length 2 "
                                "(exp: ('category', ['1', '2', '3'])")

        # build a new column_dict with 'unsplit' keys
        columns_dict_new = {}
        for key, value in columns_dict.items():
            zipped = zip(key, (value,) * len(key))
            for item in zipped:
                columns_dict_new[item[0]] = item[1]

        return {'columns_dict': columns_dict_new}

    @staticmethod
    def _get_summary(**kwargs):
        sort = kwargs['sort']

        if sort is not None:
            if not isinstance(sort, tuple):
                raise Exception("'sort=' has to by of type 'tuple' ('column-name', True/False) with"
                                " a valid column-name out of ['names', 'types', 'categories', 'min', 'max', 'na']")
            if not (1 <= len(sort) <= 2):
                raise Exception("'sort=' has to be a tuple of length 1 or 2")
            if sort[0] not in ['names', 'types', 'categories', 'min', 'max', 'na']:
                raise Exception("first value in 'sort=' tuple has to be one of ['names', 'types', 'categories', "
                                "'min', 'max', 'na']")
            if len(sort) == 2 and not isinstance(sort[1], bool):
                raise Exception("second value in tuple 'sort=' has to be a boolean for ascending sorting")
        return {'sort': sort}

    @staticmethod
    def _drop_columns(**kwargs):
        counter = 0
        to_drop = {}
        if kwargs:
            for item in list(kwargs.keys()):
                if item in ['startswith', 'endswith', 'contains', 'cols', 'empty', 'tresh']:
                    counter += 1
                    to_drop.update({item: kwargs[item]})
            if counter > 1:
                raise Exception(
                    f"you can only choice one out of ['startswith', 'endswith', 'contains', 'empty', 'cols', 'tresh]")

        if 'tresh' in to_drop:
            if not (isinstance(to_drop['tresh'], int) or isinstance(to_drop['tresh'], float)):
                raise Exception(f"'tresh' has to be of type 'float' or 'int' (given: {type(to_drop['tresh'])})")
            if (isinstance(to_drop['tresh'], float)):
                if not (0 < to_drop['tresh'] < 1):
                    raise Exception(f"'tresh' has to be a float between 0 and 1 (given: {to_drop['tresh']})")
            if (isinstance(to_drop['tresh'], int)):
                if to_drop['tresh'] < 0:
                    raise Exception(f"'tresh' can't be smaller than 0 (given: {to_drop['tresh']})")

        # if 'empty' in to_drop.keys():
        return {'dropping parameter': to_drop}

    def _get_summary(self, type='category', sort=None, **kwargs):
        return {'type': 'category', 'sort': None}


class Logger:

    def __init__(self, obj, log, log_modes, show_no_entries):

        self.valid_modes = ['io', 'files', 'details', 'summary']
        self.obj = obj  # Preprocessor-Object
        self.path = None
        self.file = None
        self.file_counter = 0

        self.log = self.initialize_log(log)
        self.log_modes = self.set_log_modes(log_modes)
        self.show_no_entries = self.set_no_entries(
            show_no_entries)  # how many items should be shown in 'details' if list/dict is long?

    @staticmethod
    def _get_actual_time():
        time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return time

    @staticmethod
    def set_no_entries(show_no_entries):
        if not isinstance(show_no_entries, int):
            if show_no_entries != 'all':
                raise Exception(f"'show_no_entries' have to be a positive integer or 'all' (for all entries)")
        return show_no_entries

    def get_no_entries(self, **kwargs):
        if 'show_no_entries' not in kwargs:
            show_no_entries = self.show_no_entries
        else:
            show_no_entries = self.set_no_entries(kwargs['show_no_entries'])
        return show_no_entries

    def initialize_log(self, log):
        if not isinstance(log, bool):
            raise Exception("log has to be type 'bool'")
        if log:
            self.path = Path(os.getcwd()).joinpath('../modeling.preprocessor/logs')
            self.file = f"{self.path}/modeling.preprocessor.log"
            if not os.path.exists(self.path):
                os.mkdir(self.path)
        return log

    def get_function_log_and_log_modes(self, **kwargs):
        if 'log' not in kwargs:
            log = self.log
        else:
            log = self.initialize_log(kwargs['log'])
        if 'log_modes' not in kwargs:
            log_modes = self.log_modes
        else:
            log_modes = self.set_log_modes(kwargs['log_modes'])
        return log, log_modes

    def set_log_modes(self, log_modes):
        if not isinstance(log_modes, tuple):
            if isinstance(log_modes, str):
                log_modes = (log_modes,)
            else:
                raise Exception("log_modes have to by of type 'tuple'")

        log_modes = tuple([i for i in log_modes if i in self.valid_modes])
        return log_modes

    def _write_files(self, filename):
        self.obj.df_step.to_csv(f"{self.path}/{filename}_{self.file_counter}.csv", index=False)
        self.file_counter += 1
        self.obj.df_actual.to_csv(f"{self.path}/{filename}_{self.file_counter}.csv", index=False)
        self.file_counter += 1
        with open(self.file, 'a+') as f:
            f.write(f"\nlog_mode: 'files': \n"
                    f"\twrote files '{filename}_{self.file_counter - 2}.csv' and "
                    f"'{filename}_{self.file_counter - 1}.csv'\n")

    def logging(self, functionname, log_modes, show_no_entries, **kwargs):

        with open(self.file, 'a+') as f:
            f.write(f"\n{self._get_actual_time()}: {functionname.upper()}\n")

        if 'io' in log_modes:
            with open(self.file, 'a+') as f:
                if show_no_entries != 'all':
                    f.write(f"\nlog_mode: 'io' (only {show_no_entries} items showed): \n")
                else:
                    f.write(f"\nlog_mode: 'io': \n")

                if self.obj.input:  # from preprocessor object
                    for key, value in self.obj.input.items():
                        value = self._shorten_container(value, show_no_entries)
                        f.write(f"\n\t{key}:\n")
                        f.write(f"\t{pformat(value, indent=4, width=120)}\n")

        if 'details' in log_modes:
            with open(self.file, 'a+') as f:
                if show_no_entries != 'all':
                    f.write(f"\nlog_mode: 'details' (only {show_no_entries} items showed): \n")
                else:
                    f.write(f"\nlog_mode: 'details': \n")

                # columns found/not found
                if self.obj.columns:  # from validator object
                    for key, value in self.obj.columns.items():
                        f.write(f"\n\t{key} ({len(value)}):\n")
                        if key == 'columns not found':
                            f.write(f"\t{pformat(value, indent=4)}\n")

                if self.obj.output:  # from preprocessor object
                    for key, value in self.obj.output.items():
                        value = self._shorten_container(value, show_no_entries)
                        f.write(f"\n\t{key}:\n")
                        f.write(f"\t{pformat(value, indent=4, width=120)}\n")

        if 'summary' in log_modes:
            with open(self.file, 'a+') as f:
                f.write(f"\nlog_mode: 'summary': \n"
                        f"\tshape before applying '{functionname}': {self.obj.df_step.shape}\n"
                        f"\tshape after applying '{functionname}': {self.obj.df_actual.shape}\n")

        if 'files' in log_modes:
            self._write_files(functionname)

    @staticmethod
    def _convert_to_string(value):
        if isinstance(value, list):
            str_value = ", ".join(value)
        if isinstance(value, dict):
            str_value = json.dumps(value)
        return str_value

    @staticmethod
    def _shorten_container(container, length):
        if length != 'all':
            if isinstance(container, list):
                container_updated = [item for idx, item in enumerate(container) if idx <= math.floor(length / 2) or
                                     idx > len(container) - math.floor(length / 2)]
                container_updated.insert(math.floor(length / 2), '[...]')
            if isinstance(container, dict):
                container_updated = [(key, value) for idx, (key, value) in enumerate(container.items()) if
                                     idx <= math.floor(length / 2) or idx > len(container) - math.floor(length / 2)]
                container_updated = {key: value for key, value in container_updated}
            return container_updated
        else:
            return container

    # def _logging(self, functionname, log_modes, **kwargs):
    #
    #     with open(self.file, 'a+') as f:
    #         f.write(f"\n{self._get_actual_time()}: {functionname.upper()}\n")
    #
    #     if 'files' in log_modes:
    #         self._write_files(functionname)
    #
    #     if 'summary' in log_modes:
    #         with open(self.file, 'a+') as f:
    #             f.write(f"\nlog_mode: 'summary': \n"
    #                     f"\tshape before applying '{functionname}': {self.df_step.shape}\n"
    #                     f"\tshape after applying '{functionname}': {self.df_actual.shape}\n")
    #
    #     if functionname == 'rename_columns':
    #
    #         rename_dict = kwargs['rename_dict']
    #         cols_found = kwargs['cols_found']
    #         cols_not_found = kwargs['cols_not_found']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\trenaming ['old': 'new'] ({len(rename_dict)}) = {pformat(self._shorten_container(rename_dict, 20))}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 f.write(f"\tcolumn found and renamed [{len(cols_found)}]: {pformat(self.rename_dict_mod)}\n")
    #                 f.write(f"\tcolumn not found [{len(cols_not_found)}]: {pformat(cols_not_found)}\n")
    #
    #     if functionname == 'arrange_columns':
    #         mode = kwargs['mode']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tmode = {mode}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 # TODO: think about it...
    #                 f.write(f"\told arrangement: {pformat(self.df_original.columns.to_list())}\n")  # self.df_step
    #                 f.write(f"\tnew arrangement: {pformat(self.df_actual.columns.to_list())}\n")
    #
    #     if functionname == 'drop_columns':
    #         to_drop = kwargs['to_drop']
    #         not_found = kwargs['not_found']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tmode = {kwargs}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 f.write(f"\tcolumns found and deleted [{len(to_drop)}]: {pformat(to_drop)}\n")
    #                 if 'cols' in kwargs:
    #                     f.write(f"\tcolumns not found [{len(not_found)}]: {pformat(not_found)}\n")
    #
    #     if functionname == 'convert_column_type':
    #         columns_dict = kwargs['columns_dict']
    #         columns_dict_mod = kwargs['columns_dict_mod']
    #         introduced_na = kwargs['introduced_na']
    #         cols_concerned = list(columns_dict_mod.keys())
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tcolumn_dict = {pformat(columns_dict)}\n"
    #                         f"\tmodified column_dict = {pformat(columns_dict_mod)}\n"
    #                         f"\tnot found columns: {pformat('aaa')}\n")  # TODO: replace 'aaa' by correct value
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\tintroduced na: {pformat(introduced_na)}\n")
    #                 f.write(f"\nold column type = \n{pformat(self.df_step[cols_concerned].dtypes)}\n\n"
    #                         f"types after conversion = \n{pformat(self.df_actual[cols_concerned].dtypes)}\n")
    #
    #     if functionname == 'combine_features':
    #         empty = kwargs['empty']
    #         combine_dict = kwargs['combine_dict']
    #         modified_combine_dict = kwargs['modified_combine_dict']
    #         mode = kwargs['mode']
    #         drop = kwargs['drop']
    #         cols_not_found = kwargs['cols_not_found']
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details': \n")
    #                 f.write(f"\tnot found columns in original data: {pformat(cols_not_found)}\n")
    #                 f.write(f"\tdropped new combined_features: {empty}\n")
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tcombine_dict = {pformat(combine_dict)}\n"
    #                         f"\tmodified combine_dict = {pformat(modified_combine_dict)}\n"
    #                         f"\tmode = {mode}\n"
    #                         f"\tdrop = {drop}\n")
    #
    #     if functionname == 'replace_values':
    #         pattern = kwargs['pattern']
    #         value = kwargs['value']
    #         columns = kwargs['columns']
    #         column_type = kwargs['column_type']
    #         cols = kwargs['cols']
    #         no_cell_level = kwargs['no_cell_level']
    #         no_global = kwargs['no_global']
    #
    #         if 'io' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'io': \n"
    #                         f"\tpattern = {pformat(pattern)}\n"
    #                         f"\treplace with = {value}\n"
    #                         f"\tin columns = {pformat(columns)}\n"
    #                         f"\tcolumn_type = {pformat(column_type)}\n"
    #                         f"\tconsidered columns ({len(cols)}) = {self._shorten_container(cols, 20)}\n")
    #
    #         if 'details' in log_modes:
    #             with open(self.file, 'a+') as f:
    #                 f.write(f"\nlog_mode: 'details':\n")
    #                 for item in no_cell_level.values():
    #                     f.write(item[0])
    #                 f.write(f"\n\tsummary:\n{pformat(no_global)}\n")


if __name__ == '__main__':

    file1 = pd.read_csv("../../data/CoV-2_motherdatabase_lab_17_08.csv")
    rename_file1 = pd.read_csv("../../data/renaming_lab_17_08.csv")
    rename_file1['old_colnames'] = file1.columns.to_list()
    rename_dict = {key: value for (key, value) in zip(rename_file1['old_colnames'], rename_file1['working_title'])
                   if not isinstance(value, float)}

    # pp = Preprocessor(df=file1, log=True, log_modes=('summary', 'io'))
    pp = Preprocessor(df=file1, log=True)

    # pp.get_plot(type='TypePlotter', sort="type").show()
    # pp.get_plot(type='MatrixPlotter').show()
    # pp.get_plot(type='MissingValuePlotter', sort='missing').show()
    # print(pp.get_summary())

    # start preprocesing
    pp.drop_columns(empty=True)
    pp.rename_columns(rename_dict=rename_dict, show_no_entries=20)
    pp.replace_values(pattern=[['< 0,10'], ['< 0,02'], ['< 0,3'], ['< 7'], ['< 0.002'], ['< 5'], ['----']],
                      value=[0.05, 0.01, 0.15, 3.5, 0.001, 2.5, np.nan])
    pp.convert_column_type(
        columns_dict={('wbc_2', 'wbc_3', 'wbc_4', 'wbc_6', 'pt_s_1', 'pt_s_2', 'pt_s_3', 'pt_s_4', 'pt_s_6',
                       'saturation_oxygen_sup', 'max_mews', 'aaa'): ('numeric', ''), ('sex',): ('category', '')})
    pp.arrange_columns(mode='alpha_rev')

    print(pp.get_summary())
    pp.get_plot(type='ColumnPlotter', columns=['age', 'final_result', 'crp_1', 'crp_2', 'aptt_7']).show()
    pp.get_plot(type='TypePlotter', sort="type").show()
    pp.get_plot(type='MatrixPlotter').show()
    pp.get_plot(type='MissingValuePlotter', sort='missing').show()

    # pp.arrange_columns(mode='alpha_rev')

    pp.replace_values(pattern=[['< 0,10'], ['< 0,02'], ['< 0,3'], ['< 7'], ['< 0.002'], ['< 5'], ['----']],
                      value=[0.05, 0.01, 0.15, 3.5, 0.001, 2.5, np.nan], log=True, log_modes=('summary'))

    # pp.convert_column_type(
    #     columns_dict={('wbc_2', 'wbc_3', 'wbc_4', 'wbc_6', 'pt_s_1', 'pt_s_2', 'pt_s_3', 'pt_s_4', 'pt_s_6',
    #                    'saturation_oxygen_sup', 'max_mews', 'aaa'): ('numeric', '')})

    # content = {'a': ['a', np.nan, 'c', 'd', 'e', '-', 'g', '2020-10-11'],
    #            'b': [i for i in range(8)],
    #            'c': [i for i in range(8)],
    #            'c_1': [i for i in range(8)],
    #            'c_2': [i for i in range(8)],
    #            'd_hallo_2': [i for i in range(8)],
    #            'd': ['a', 'a', 'b', 'c', 'b', 'a', 'b', 'c'],
    #            'e1': [0,0,np.nan,1,1,0,np.nan,1],
    #            'e2': [0,1,1,0,1,np.nan, np.nan,1]
    #            }
    #
    # content['c'][6] = '-'
    # content['d'][0] = np.nan
    # content['b'][4] = '25.11.1976'
    # content['c_1'][3] = 2.7
    # df = pd.DataFrame(data=content)

    # df = pd.read_csv("../../data/working_data.csv")
    # df = df.iloc[:,0:12]

    # pp = Preprocessor(df=df, log=False)
    # pp = Preprocessor(df=df, log=True)

    # pp.combine_features(combine_dict={'e': ['e1', 'e2'], 'b_new': ['u', 'b']}, mode='binary', drop=True)
    # pp.combine_features(combine_dict={'e': ['e1', 'e2'], 'x': ['u']}, mode='binary', drop=True)

    # pp.rename_columns(rename_dict={'albumin_': 'alb_', 'age': 'age_dist'})
    # # pp.drop_columns(endswith='_mews')
    # pp.arrange_columns(mode='alpha')
    # # pp.replace_values(pattern=['-', 'c'], value=np.nan, columns=['c_2', 'AAA'])
    # pp.replace_values(pattern=['Infected', 'Negative', 'Recovered', 'Symptoms'], value='survived',
    #                   columns=['final_result'])
    # pp.replace_values(pattern=['Death'], value='died', columns=['final_result'])
    #
    # # pp.convert_column_type(columns_dict={('c', 'c_1', 'c_2'): ('numeric', '')})
    # # pp.convert_column_type(columns_dict={'AAA': ('date', '%Y-%m-%d'), 'b': ('date', '%d.%m.%Y')})
    # # pp.convert_column_type(columns_dict={('c_1', 'C'): ('numeric', '')})
    # # pp.convert_column_type(columns_dict={'d': ('category', ["a", "b"])})
    # pp.convert_column_type(columns_dict={('sex', 'group', 'final_result'): ('category', ''),
    #                                      'ward': ('category', ['Ward', 'ICU', 'Isolation'])})

    # df = pp.get_summary(sort=('na', False))
    # print(df)
    #
    # data = pp.get_data()
    # print(data)

    # fig = pp.get_plot(type="ColumnPlotter")
    # fig = pp.get_plot(type="ColumnPlotter", columns=['age_dist', 'lymphocytes_', 'sex', 'group', 'final_result', 'max_mews', 'mpv_'])
    # fig.show()
    #
    # fig = pp.get_plot(type="MissingValuePlotter", sort=('missing'))
    # fig.show()
    # fig = pp.get_plot(type="TypePlotter", sort="missing")
    # fig.show()
