from typing import Dict, Union

import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn import svm
from sklearn.model_selection import GridSearchCV, train_test_split, BaseCrossValidator, cross_val_score
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectKBest
from sklearn.model_selection import ShuffleSplit, KFold
# from sklearn.impute import SimpleImputer
# from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
# from sklearn.feature_selection import VarianceThreshold
from sklearn.compose import make_column_selector  # , ColumnTransformer
from joblib import dump, load
import os
from pathlib import Path
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
import plotly.graph_objects as go
import math
from functools import reduce

# own
from sklearn_custom.feature_selection.VarianceThreshold import VarianceThreshold
from sklearn_custom.imputers.SimpleImputer import SimpleImputer
from sklearn_custom.encoders.OneHotEncoder import OneHotEncoder
from sklearn_custom.encoders.OrdinalEncoder import OrdinalEncoder
from sklearn_custom.transformers.ColumnTransformer import ColumnTransformer
from sklearn_custom.preprocessing.MinMaxScaler import MinMaxScaler
from sklearn_custom.transformers.SAXTransformer import SAX_Transformer
from sklearn_custom.estimators.NullModel import NullClassifier


# classification and regression objects  # TODO
# multiple classifier (u.a. MajorityVoter etc.)  # TODO

# idea: preprocessing will be done with class 'df_proprocessor' (local), modeling will be done by original
# sklearn or sklearn_custom (on server or local) -> no logging (returns object), and evaluation will be done
# local with class 'Evaluator'


class Model:

    def __init__(self, classifiers, parameters, pipe=None, cv=5, n_jobs=-1, verbose=1, scoring='accuracy',
                 feature_selection=None, **kwargs):
        """
        :param classifiers: dictionary of desired classifiers (exp: {'Random Forest': RandomForestClassifier(), 'KNN': KNeighborsClassifier()}
        :param parameters: dictionary {'Random Forest': {'classifier__n_estimators': [200, 500, 1000],...}, 'KNN': {...}}
        :param pipe: Pipeline with steps before classifying
        :param cv: cross-validation object or int with number of splits
        :param n_jobs: number of cores to be used for calculation (-1 (default): use all cores available)
        :param verbose: verbosity (console) as integer
        :param scoring: scoring method for classifier ['accuracy', 'roc_auc', ...] as string or scoring object
        """
        self.classifiers = classifiers
        self.parameters = parameters
        self.pipe = pipe
        self.cv = cv
        self.n_jobs = n_jobs
        self.scoring = scoring
        self.verbose = verbose
        self.models = {}  # TODO: rename to GridSerachCV
        self.best_models = {}
        self.predictions = {}
        self.feature_selection = feature_selection
        self.feature_selection_results = {}
        self.X = None
        self.y = None
        self.random_state = None  # random state to synchronize cross-validation and feature selection
        self._validate_cv()

    def _validate_cv(self):
        """
        cv object has to have and random seed if feature selection is activated. If no seed is set, algorithm will
        take one automatically
        :return: updated cv-object
        """
        if not isinstance(self.cv, BaseCrossValidator):
            raise Exception(f"cv has to by of class 'BaseCrossValidator'")

    def fit(self, X, y):

        self.y = y
        self.X = X

        for classifier_label, classifier in self.classifiers.items():

            if self.pipe is not None:
                kwargs = {}  # get additional parameters like n_jobs or remainder, ...
                for item in [{i: self.pipe[i]} for i in self.pipe.keys()
                             if i not in ['pipeline_names', 'column_selector', 'pipelines']]:
                    kwargs.update(item)
                transformers = self.build_column_transformers()
                preprocessing = ColumnTransformer(transformers, **kwargs)
                steps = [("preprocessing", preprocessing), ("classifier", classifier)]
            else:
                steps = [("classifier", classifier)]

            pipeline = Pipeline(steps=steps)  # here an other preprocess-step could be implemented

            param_grid = self.parameters.get(classifier_label, None)

            # param_grid.update({'preprocessing__sax_pipeline__sax__n_letters': [2, 3]})  # TODO: adjust param_grid with entries not of actual classifier

            # TODO: -> ADJUST BEST_MODELS, MODELS ETC.
            if param_grid is None:  # no hyperparameters
                pipeline.fit(self.X,  np.ravel(self.y))
                self.best_models.update({classifier_label: pipeline})
                score = cross_val_score(pipeline, X=self.X, y=self.y, cv=self.cv)
            else:
                gscv = GridSearchCV(pipeline, param_grid, cv=self.cv, n_jobs=self.n_jobs, verbose=self.verbose,
                                scoring=self.scoring)
                gscv.fit(self.X, np.ravel(self.y))
                self.best_models.update({classifier_label: pipeline})
                self.models.update({classifier_label: gscv})

            # Feature selector
            # raise Exception if self.X is no pandas Dataframe
            if self.feature_selection:
                if not isinstance(self.X, pd.DataFrame):
                    raise Exception(f"data have to be of type pd.Dataframe for 'feature_selection'. Use own"
                                    f"class 'sklearn_custom' for Transformers with option 'df_out'=True")

                # for train, test in self.cv.split(self.X):
                #     print("%s %s" % (train, test))

                steps = [i for i in steps if i[0] != 'classifier']  # remove 'classifiers' to only preprocess data
                pipeline = Pipeline(steps=steps)
                X = pipeline.fit_transform(self.X)
                results = self._fw_bw_feature_selection({classifier_label: gscv.best_estimator_[-1]},
                                                        X, self.y, **self.feature_selection)
                self.feature_selection_results.update(results)

    def predict(self, X):
        for name, model in self.models.items():
            self.predictions.update({name: model.best_estimator_.predict(X=X)})
        return self

    def get_predictions(self, name=None):
        if name is None:
            return self.predictions
        else:
            preds = self.predictions.get(name, None)
            return preds

    def build_column_transformers(self):
        """
            generates a list of ColumnTransformers
            :param X_train: pandas DataFrame with Train data (for fetching colnames)
            :return: list of ColumnsTransformers (exp. [('name_p1', Pipeline(...), ['a','b', 'd']), ('name_p2', Pipeline(...), ['c'])])
            """
        transformers = []
        for idx, item in enumerate(self.pipe['pipeline_names']):

            if list(self.pipe['column_selector'][idx].keys())[0] == 'cols':
                columns = self.pipe['column_selector'][idx]['cols']
            else:
                kwargs = self.pipe['column_selector'][idx]
                sel = make_column_selector(**kwargs)
                columns = sel.__call__(self.X)

            transformers.append((self.pipe['pipeline_names'][idx], self.pipe['pipelines'][idx], columns))
        return transformers

    def store(self, file=None):
        if file is None:
            filename = 'model.joblib'
            file = os.path.join(os.getcwd(), filename)
        else:
            file = Path(file)

        try:
            dump(self, filename=file)
        except FileNotFoundError as e:
            raise Exception(f"could not store model with this path: {e}")

    def _fw_bw_feature_selection(self, fitted_model, X, y, **kwargs):

        algorithm = list(fitted_model.keys())[0]

        if 'k_features' not in kwargs:
            k_features = len(X.columns)
        else:
            k_features = kwargs.pop('k_features')
            if k_features > len(X.columns):
                k_features = len(X.columns)

        results = {}

        # for algorithm in algorithms:
        if algorithm != 'VotingClassifier':
            best_estimator = fitted_model[algorithm]

            # http://rasbt.github.io/mlxtend/user_guide/feature_selection/SequentialFeatureSelector/
            sfs = SFS(estimator=best_estimator, k_features=k_features, **kwargs)
            sfs = sfs.fit(np.array(X), np.ravel(y), custom_feature_names=list(X.columns))
            results[algorithm] = sfs
        return results


if __name__ == '__main__':

    X, y = datasets.load_iris(return_X_y=True)
    X = pd.DataFrame(data=X, columns=['A', 'B', 'C', 'D'])
    y = pd.DataFrame(data=y, columns=['target'])
    y.replace({0: 'died', 1: 'survived', 2: 'survived'}, inplace=True)
    X_new = pd.DataFrame(data=np.random.normal(5, 2, 450).reshape((150, 3)), columns=['sax_1', 'sax_2', 'sax_3'])
    X_new = X_new.mask(np.random.random(X_new.shape) < .1)  # introduce a fraction of 10% missing data
    X_new_2 = pd.DataFrame(data=np.random.normal(0, 1, 450).reshape((150, 3)), columns=['exp_1', 'exp_2', 'exp_3'])
    X_new_2 = X_new_2.mask(np.random.random(X_new_2.shape) < .15)  # introduce a fraction of 10% missing data
    X = X.join(X_new)
    X = X.join((X_new_2))

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=28)

    classifiers = {}
    # classifiers.update({"Null Classifier": NullClassifier()})
    classifiers.update({"Random Forest": RandomForestClassifier()})
    classifiers.update({"KNN": KNeighborsClassifier()})

    # classifiers.update({"AdaBoost": AdaBoostClassifier()})
    # 'VotingClassifier_model': True,
    # 'VotingClassifier_params': {'voting': 'hard'}

    parameters = {}
    parameters.update({"Random Forest": {
        "classifier__n_estimators": [200, 300],
        # "classifier__max_features": ["auto"],
        # "classifier__max_depth": [3, 4],
        # "classifier__min_samples_split": [0.01, 0.05, 0.10],
        # "classifier__criterion": ["gini", "entropy"],
        "classifier__n_jobs": [-1]
    }})
    parameters.update({"KNN": {
        "classifier__n_neighbors": list(range(1, 6)),
        # "classifier__p": [1, 2, 3, 4, 5],
        # "classifier__leaf_size": [5, 10, 15, 20, 25, 30, 35, 40, 45, 50],
        "classifier__n_jobs": [-1]
    }})
    parameters.update({"AdaBoost": {
        "classifier__base_estimator": [DecisionTreeClassifier(max_depth=ii) for ii in range(1, 6)],
        "classifier__n_estimators": [200],
        "classifier__learning_rate": [0.001, 0.01, 0.05, 0.1, 0.25, 0.50, 0.75, 1.0]
    }})

    # cv = ShuffleSplit(n_splits=5, test_size=0.3, random_state=0)
    cv = KFold(n_splits=5, shuffle=True)  # , random_state=0)

    pipe = {
        # 'pipeline_names': ['num_pipeline', 'cat_nom_pipeline'],
        'pipeline_names': ['num_pipeline', 'sax_pipeline'],

        # 'column_selector': [{'dtype_include': np.number}, {'dtype_include': 'category'}],
        'column_selector': [{'cols': ['A', 'B', 'C', 'D']}, {'cols': ['sax_1', 'sax_2', 'sax_3', 'exp_1', 'exp_2', 'exp_3']}],
        'remainder': 'drop',
        # All columns NOT in one of lists will be passed through ('passthrough') or dropped ('drop')
        'n_jobs': -1,

        'pipelines': [
            Pipeline([
                ('imputer', SimpleImputer(strategy='median')),
                ('min_max', MinMaxScaler()),
                ('zero_var', VarianceThreshold(threshold=0.05)),
            ]),
            Pipeline([
                ('sax', SAX_Transformer(n_letters=2, n_length=2, scaler='z_all', thresholds={'exp': [10]}, cat_ordered=False)),
                ('imputer_nom', SimpleImputer(strategy='constant', fill_value='MISSING', df_out=True)),
                ('oh', OneHotEncoder(sparse=False, df_out=True, new_cats=True, fill_value='MISSING', drop='first'))
            ])
        ]}

    feature_selection = None #  {
    #     'k_features': 3,  # the lower the features we want, the longer this will take (for forward=False).
    #     # if parameter is not supported, maximal number of features will be taken
    #     # automatically (take long)
    #     'forward': True,  # False=Backward
    #     'floating': False,
    #     'verbose': 2,
    #     'scoring': 'accuracy',
    #     'cv': 5,
    #     'n_jobs': -1
    # }

    mod = Model(classifiers=classifiers, parameters=parameters, cv=cv, pipe=pipe, return_train_score=True,
                feature_selection=feature_selection)

    mod.fit(X=X_train, y=y_train)
    mod.predict(X=X_train)

    file = "/home/schmidmarco/Documents/CODE/PACKAGES/sklearn_custom/data/models.joblib"
    mod.store(file=file)
