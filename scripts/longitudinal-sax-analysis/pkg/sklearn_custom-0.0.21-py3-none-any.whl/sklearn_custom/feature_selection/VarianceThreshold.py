from sklearn.feature_selection import VarianceThreshold
import pandas as pd
import logging


class VarianceThreshold(VarianceThreshold):

    """
    wraps sklearn.class 'VarianceThreshold'. A pandas DataFrame will be returned if a pandas DataFrame is given as
    argument and if df_out is set to True (default). No missing values are allowed in input data!
    """

    def __init__(self, df_out=True, **kwargs):
        super().__init__(**kwargs)
        self.df_out = df_out

    def fit(self, X, y=None):
        super().fit(X=X, y=y)  # in case of df_out=False, method from original OneHotEncoder will be taken
        return self

    def transform(self, X):
        Xs = super().transform(X)

        if self.df_out and isinstance(X, pd.DataFrame):
            idx = X.index
            cols = X.columns[self.variances_ > self.threshold].to_list()
            Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)

        return Xs