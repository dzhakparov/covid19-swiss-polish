from sklearn.impute import IterativeImputer
from sklearn.linear_model import BayesianRidge
import pandas as pd


class IterativeImputer(IterativeImputer):

    def __init__(self, df_out=True, estimator=None, **kwargs):
        """
        """
        super().__init__(**kwargs)
        if estimator is None:
            self.estimator = BayesianRidge()
        else:
            self.estimator = estimator
        self.df_out = df_out

    def fit(self, X, y=None):
        super().fit(X, y=y)
        return self

    def transform(self, X):
        Xs = super().transform(X)

        if self.df_out:
            idx = X.index
            names = X.columns
            Xs = pd.DataFrame(data=Xs, index=idx, columns=names)

        return Xs