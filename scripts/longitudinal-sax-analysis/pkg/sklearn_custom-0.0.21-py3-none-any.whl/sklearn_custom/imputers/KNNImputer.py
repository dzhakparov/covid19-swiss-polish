from sklearn.impute import KNNImputer
import pandas as pd
import numpy as np


class KNNImputer(KNNImputer):

    def __init__(self, df_out=True, n_neighbors=5, weights='uniform', **kwargs):
        """
        this class does a KNN-imputation of missing values in data
        :param df_out: boolean, should a pandas DataFrame be output?
        :param kwargs:
        """
        super().__init__(**kwargs)
        self.n_neighbors = n_neighbors
        self.weights = weights
        self.df_out = df_out

    def fit(self, X, y=None):
        super().fit(X, y=y)
        return self

    def transform(self, X):
        Xs = super().transform(X)

        if self.df_out:
            idx = X.index
            names = X.columns
            Xs = pd.DataFrame(data=Xs, index=idx, columns=names)

        return Xs