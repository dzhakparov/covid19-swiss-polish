import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
import miceforest as mf
from sklearn.utils.validation import check_is_fitted
import miceforest

# https://github.com/AnotherSamWilson/miceforest


class MiceForest(BaseEstimator, TransformerMixin):

    def __init__(self, df_out=True, datasets=5, iterations = 5, random_state=None, save_all_iterations=False, n_jobs=-1,
                 n_estimators=100, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=1):

        self.df_out = df_out
        self.datasets = datasets
        self.iterations = iterations
        self.random_state = random_state
        self.n_jobs= n_jobs
        self.save_all_iterations = save_all_iterations
        self.n_estimators = n_estimators
        self.criterion = criterion
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf

        self.kernel = None
        self.data = None
        self.imp_data = None

    def fit(self, X, y=None):

        self.kernel = mf.MultipleImputedKernel(
            X,
            datasets=self.datasets,
            save_all_iterations=self.save_all_iterations,
            random_state=self.random_state
        )
        self.kernel.mice(self.iterations,
                         n_jobs=self.n_jobs)
        return self

    def transform(self, X, y=None):

        self.data = X
        self.kernel.impute_new_data(new_data=X)
        self.imp_data = self.kernel.complete_data(dataset=0, iteration=None)

        if self.df_out is False:
            self.imp_data = self.imp_data.values()

        return self.imp_data