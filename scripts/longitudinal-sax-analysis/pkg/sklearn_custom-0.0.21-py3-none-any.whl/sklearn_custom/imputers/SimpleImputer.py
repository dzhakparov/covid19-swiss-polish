from sklearn.impute import SimpleImputer, MissingIndicator
import pandas as pd
import numpy as np


class SimpleImputer(SimpleImputer):

    def __init__(self, df_out=True, strategy='constant', fill_value='MISSING', indicator=False, **kwargs):
        """
        this class imputes missing values in data
        :param df_out: boolean, should a pandas DataFrame be output?
        :param strategy: one out of 'mean', 'median', 'most_frequent' or 'constant'
        :param fill_value: numeric or string, if strategy is 'constant', fill_value will be used to replace these values
        :param indicator: boolean, if True a new binary column (0,1) for each feature will be attached (feature-notna)
        :param kwargs:
        """
        super().__init__(**kwargs)
        self.df_out = df_out
        self.strategy = strategy
        self.fill_value = fill_value
        self.categories = None
        self.indicator = indicator  # will add a column for each feature with 0 (missing) and 1 (not_missing)
        # trial with 'add_indicator' did not work -> only columns with missing values will be added (problem to convert
        # to pandas DataFrame due naming issues)

    def fit(self, X, y=None):
        super().fit(X, y=y)
        self.categories = X.dtypes
        return self

    def transform(self, X):
        Xs = super().transform(X)

        if self.df_out and isinstance(X, pd.DataFrame):
            idx = X.index
            cols = X.columns.to_list()
            no_features = len(cols)

            Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)

            if self.indicator:
                X_indicator = X.notnull().astype('int')
                colnames = [f"{i}-notna" for i in X.columns]
                colnames = [i.replace('_', '-') for i in colnames]
                X_indicator.columns = colnames
                Xs = pd.concat([Xs, X_indicator], axis=1)
                self.categories = pd.concat([self.categories, X_indicator.dtypes], axis=0)  # extend self.categories

            for item in Xs.iloc[:,0:no_features]:
                if self.categories[item].name == 'category':
                    values = list(self.categories[item].categories.values)
                    values.append(self.fill_value)
                    Xs[item] = pd.Categorical(Xs[item], categories=values, ordered = self.categories[item].ordered)
                    Xs[item].fillna(self.fill_value, inplace=True)
            if not self.indicator:
                Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)
        return Xs