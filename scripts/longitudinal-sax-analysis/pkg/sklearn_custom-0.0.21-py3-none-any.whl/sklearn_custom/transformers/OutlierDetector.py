from sklearn.base import BaseEstimator, TransformerMixin
import numpy as np
import pandas as pd
from sklearn.neighbors import LocalOutlierFactor


class OutlierDetector(TransformerMixin, BaseEstimator):

    # TODO: how many values dropped out per feature?
    # TODO: output pandas DataFrame (Feature)
    # TODO: optimize in speed

    def __init__(self, action='drop', threshold=3, sample_strategy=True):
        """ The OutlierDetector is a transformer that drops or transformers potential outliers in data. It can be used in
        sklearn.Pipeline objects as a normal transformer.
        :param action: one out of 'drop' (default), 'set_threshold' or None. 'drop' sets values above/below threshold
        to np.Nan. If 'set_threshold' is used the according value will not be removed but set the the upper/lower
        frontier. 'None' will pass data unmodified. This can be useful in case of hyper-parameter tuning of Pipelines.
        :param threshold: float. Indicates how many times the standard deviation of a features determines it's cut-off
        point.
        :param sample_strategy: boolean. The sample_strategy tries to avoid that en enormous outlier has an impact on
        it's own mean and standard deviation. So 5-times a random sample of 20% of a features data will be taken and
        the median of these 5 means/standard deviations will be taken as estimator.
        """

        self.action = action
        self.threshold = threshold
        self.sample_strategy = sample_strategy
        self.mean = None
        self.median = None
        self.std = None
        self.lower = None
        self.upper = None
        self.mutated_cells = []  # stores number of changed/mutated cells per feature

    def fit(self, X, y=None):

        if self.threshold is None or self.action is None:
            return self
        else:

            if self.sample_strategy:
                mean = []
                std = []
                for item in range(0, 5, 1):
                    Xs = X.sample(frac=0.2)
                    mean.append(np.mean(Xs).tolist())
                    std.append(np.std(Xs).tolist())
                self.mean = np.median(np.array(mean), axis=0)
                self.std = np.median(np.array(std), axis=0)
            else:
                self.mean, self.std = np.array(np.mean(X)), np.array(np.std(X))

            cut_off = self.std * self.threshold
            self.lower, self.upper = self.mean - cut_off, self.mean + cut_off
            return self

    def transform(self, X, y=None):

        if self.threshold is None or self.action is None:
            return X
        else:
            for j, (idx, i) in enumerate(X.items()):
                if self.action == 'drop':
                    mask = (i < self.lower[j]) | (i > self.upper[j])
                    mutated_cells = sum(mask == 1)
                    i[mask] = np.nan
                elif self.action == 'set_threshold':
                    mask_upper = i > self.upper[j]
                    mask_lower = i < self.lower[j]
                    mutated_cells = sum(mask_upper == 1) + sum(mask_lower == 1)
                    i[mask_upper] = self.upper[j]
                    i[mask_lower] = self.lower[j]
                X[j] = i
                self.mutated_cells.append(mutated_cells)
            return X


# # https://stackoverflow.com/questions/52346725/can-i-add-outlier-detection-and-removal-to-scikit-learn-pipeline
# class OutlierExtractor(TransformerMixin):
#
#     def __init__(self, df_out=True, threshold=-3, **kwargs):
#         """
#         Create a transformer to remove outliers. A threshold is set for selection
#         criteria, and further arguments are passed to the LocalOutlierFactor class
#
#         Keyword Args:
#             threshold (float): The threshold for excluding samples with a lower
#                negative outlier factor.
#
#         Returns:
#             object: to be used as a transformer method as part of Pipeline()
#         """
#
#         self.lcf = LocalOutlierFactor(**kwargs)
#         self.df_out = df_out
#         self.threshold = threshold
#         self.y = None
#
#     def transform(self, X):
#         """
#         Uses LocalOutlierFactor class to subselect data based on some threshold
#
#         Returns:
#             ndarray: subsampled data
#
#         Notes:
#             X should be of shape (n_samples, n_features)
#         """
#         # return X
#
#         self.lcf.fit(X)
#         X = np.asarray(X)
#         self.lcf.predict(X)
#
#         if self.y is None:
#             a = X[self.lcf.negative_outlier_factor_ > self.threshold, :]
#             return X[self.lcf.negative_outlier_factor_ > self.threshold, :]
#         else:
#             a = X[self.lcf.negative_outlier_factor_ > self.threshold, :]
#             b = pd.DataFrame(data=a)
#             return b
#             # return X[self.lcf.negative_outlier_factor_ > self.threshold, :]
#             # y = np.asarray(self.y)
#             # return (X[self.lcf.negative_outlier_factor_ > self.threshold, :],
#             #         y[self.lcf.negative_outlier_factor_ > self.threshold])
#
#     def fit(self, X, y=None, *args, **kwargs):
#         self.y = y
#         # self.lcf.fit(X)
#         return self
