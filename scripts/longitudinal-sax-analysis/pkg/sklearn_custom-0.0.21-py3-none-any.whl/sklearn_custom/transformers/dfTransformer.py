import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn_custom.helpers.helpers import _get_column_names


class TransformerDataFrame(BaseEstimator, TransformerMixin):
    """
    wrapper-class which gets a normal estimator and returns a pandas DataFrame as result instead a np.ndarray
    """
    def __init__(self, transformer):
        self.transformer = transformer
        self.data_fitted = None
        self.data_transformed = None
        self.name = self.transformer.__class__.__name__

    def fit(self, X, y=None):
        self.transformer.fit(X)  # standard fit
        return self

    def transform(self, X, y=None):

        idx = X.index
        cols = _get_column_names(self.transformer, X)  # take care of column names (pandas DataFrame)
        self.data_transformed = self.transformer.transform(X)  # standard transform

        self.data_transformed = pd.DataFrame(data=self.data_transformed, index=idx, columns=cols)
        return self.data_transformed


class ColumnTransformerDataFrame(ColumnTransformer, TransformerMixin):
    """
    wrapper for ColumnTransformer, which returns a pandas DataFrame and not a np.ndarray
    """
    def __init__(self, transformers, **kwargs):
        super().__init__(transformers, **kwargs)

    def fit(self, X, y=None):
        super().fit(X, y)
        return self

    def transform(self, X):
        Xs = super().transform(X)
        return Xs

    def _hstack(self, Xs):
        return pd.concat(Xs, axis=1)