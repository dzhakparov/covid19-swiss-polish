from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd
from saxpy.paa import paa
from saxpy.sax import ts_to_string
from saxpy.alphabet import cuts_for_asize
import numpy as np
import math
from pandas.api.types import CategoricalDtype
import string
import scipy.stats as st
import re
import plotly.graph_objects as go
import os

from joblib import Parallel, delayed
import copy
from datetime import datetime
import plotly.express as px
from plotly.subplots import make_subplots


# TODO: abfangen, wenn Kategorien im SAX-Transformer nicht bekannt sind... (z.B. bei wenig Trainingsdaten)

class SAX_Transformer(BaseEstimator, TransformerMixin):
    """
    transforms columns with same column name beginning followed by a certain pattern (exp. sax_1, sax_2, ...)
    to a string representation (exp.: aa, ab, ba, bb) of all same length
    """

    def __init__(self, n_letters=2, n_length=2, scaler='z_all', thresholds=None, split=None, cat_ordered=False,
                 pattern='_'):
        """
        :param n_letters: number of letters to transform a time-series
        :param n_length: length of letter sequence to transform a time-series
        :param scaler: one out of ['z_all', 'z_series' or None]
        :param thresholds: dictionary with name of column as key and its thresholds as values. if thresholds is
               not None but the name of a column to transform the scaler for this columns will be set automatically
               to None and the individual thresholds will be taken for this feature.
               exp: threshold = {'troponin': [0.4]}
        :param split:
        :param cat_ordered:
        :param pattern: string pattern that defines the sax columns. Before pattern equal sax-features have the same
               text and after the pattern there are consequential numbers. exp: crp_1, crp_2 -> '_' is pattern
        """
        self.n_letters = n_letters
        self.n_length = n_length
        self.scaler = scaler
        self.thresholds = thresholds
        self.split = split  # categorical feature
        self.features = set()
        self.stats = {}
        self.cats = []
        self.original_data = []
        self.transformed_data = []
        self.sax_coded_data = []
        self.final_data = None
        self.y = None
        self.X = None
        self.na_coerced = set()
        self.borders = {}
        self.cat_ordered = cat_ordered  # categorical feature (ordered = False or ordered = True)
        self.pattern = pattern

    def fit(self, X, y=None):

        if y is not None:
            self.y = y
        self.X = X

        self._validate_input(X)

        self._get_features(X)

        self._get_all_sax_combinations(list(string.ascii_lowercase[0:self.n_letters]), self.n_length, self.cats)

        if self.scaler == 'z_all':
            for item in list(self.features):
                filter_col = [col for col in X if col.startswith(item)]  # extract specific columns to transform

                if self.split is not None:
                    filter_col.append(self.split)

                data = X[filter_col]

                # na.omit non numerical cells
                data = self._coerce_numerical(data, item)

                data = data.values
                mean = np.nanmean(data)
                sd = math.sqrt(np.nanvar(data))
                self.stats[f"{item}"] = {}
                self.stats[f"{item}"]['mean'] = mean
                self.stats[f"{item}"]['sd'] = sd

        if self.na_coerced:
            print(f"ATTENTION: 'nas' coerced in feature_groups: {self.na_coerced}")

        return self

    def transform(self, X, y=None):

        self.transformed_data = []
        self.sax_coded_data = []

        # normalize (z-transformation) data
        self._normalize_data(X)

        # apply sax-coding
        for data_normalized in self.transformed_data:
            self.sax_coded_data.append(
                data_normalized.apply(self._sax_transformation, args=(self.n_letters, self.n_length), axis=1))

        # concat list of series to one pandas DataFrame
        self.final_data = pd.concat(self.sax_coded_data, axis=1, keys=self.features)

        # convert columns to categorical with all possible combinations
        cat_type = CategoricalDtype(categories=self.cats, ordered=self.cat_ordered)
        self.final_data = self.final_data.astype(cat_type)

        if self.na_coerced:
            print(f"ATTENTION: 'nas' coerced in feature_groups: {self.na_coerced}")

        return self.final_data

    def get_borders(self):
        """
        get border between each pair of letters of each feature
        :return: a dictionary
        """
        if self.scaler != 'z_all':
            self.borders = None
        else:
            for item in self.stats:
                if self.thresholds is None or item not in self.thresholds.keys():
                    self.borders[item] = self._calculate_borders(self.n_letters, mean=self.stats[item]['mean'],
                                                                 sd=self.stats[item]['sd'])
                else:
                    self.borders[item] = self._calculate_borders(self.n_letters, thresholds=self.thresholds, item=item)

        return self.borders

    def get_stats(self):
        return self.stats

    def get_no_observations_per_group(self):
        no_obs = {}
        for name, feature in self.final_data.items():
            values = feature.value_counts().to_dict()
            values.update({'no_missing': feature.isna().sum()})
            values.update({'no_obs': feature.shape[0]-values.get('no_missing')})
            no_obs.update({name: values})
        return no_obs

    def get_features(self):
        return self.features

    def get_transformed_data(self):
        return list(self.final_data)

    @staticmethod
    def _calculate_borders(n_letters, **kwargs):
        if 'mean' in kwargs:
            th = 1 / n_letters
            ptc = [i * th for i in range(n_letters)]
            del ptc[0]

            z_values = [st.norm.ppf(i) for i in ptc]

            borders = [(i * kwargs['sd']) + kwargs['mean'] for i in z_values]

        else:  # manually fixed threshold(s) for this item
            borders = kwargs['thresholds'][kwargs['item']]

        letters = list(string.ascii_lowercase[:n_letters])

        comb = []
        for i in range(n_letters - 1):
            comb.append(letters[i] + letters[i + 1])

        dictionary = dict(zip(comb, borders))
        return dictionary

    def _validate_input(self, X):
        assert self.n_letters > 0
        assert self.n_length > 0
        assert self.scaler in ['z_all', 'z_series', 'None']
        if self.split is not None:
            assert self.split in X.columns.to_list()
            assert X[self.split].dtype.name == 'category'
        if self.thresholds is not None:
            assert all([isinstance(i, list) for i in list(self.thresholds.values())])
            assert all([len(i) + 1 == self.n_letters for i in list(self.thresholds.values())])

    def _normalize_data(self, X):

        for item in list(self.features):
            filter_col = [col for col in X if col.startswith(item)]  # extract specific columns to transform
            data = X[filter_col]

            # na.omit non numerical cells
            data = self._coerce_numerical(data, item)

            if self.scaler == 'None' or self.scaler is None:
                data_normalized = data
            elif self.thresholds is not None and item in list(self.thresholds.keys()):
                data_normalized = data
            elif self.scaler == 'z_all':
                data_normalized = data.apply(self._z_transformation,
                                             mean=self.stats[item]['mean'],
                                             sd=self.stats[item]['sd'],
                                             axis=1)
            elif self.scaler == 'z_series':
                data_normalized = data.apply(self._z_transformation, axis=1)

            self.transformed_data.append(data_normalized)
            self.original_data.append(data)

    def _coerce_numerical(self, data, item):
        no_na = data.isna().sum().sum()
        data = data.apply(lambda s: pd.to_numeric(s, errors='coerce'))  # coerce to numeric
        no_na_after_coerce = data.isna().sum().sum()
        if no_na != no_na_after_coerce:
            self.na_coerced.add(item)
        return data

    def _get_features(self, X):
        """
        extracts feature names by clipping last occurrence of '_xy'
        :param X: pandas DataFrame
        :return: list of unique feature names
        """
        colnames = X.columns.to_list()
        for item in colnames:
            idx = item.rfind(self.pattern)
            if idx != -1:
                self.features.add(item[:idx])

    @staticmethod
    def _z_transformation(x, mean=None, sd=None):
        val = x.dropna().values

        if len(val) >= 2:
            if mean is None:
                mean = val.mean()
                sd = val.std()

            val = pd.Series(list(np.array(
                [(xi - mean) / sd for xi in x if xi is not np.nan])))  # runtime warning...  -> division by ZERO

            val.index = x.index
            x = val
        return x

    # @staticmethod
    def _sax_transformation(self, x, n_letters, n_length):
        item = re.split('_', x.index[0])[0]
        val = x.dropna().values
        if len(val) >= 2:
            dat_paa = paa(val, n_length)

            if self.thresholds is None:
                res = ts_to_string(dat_paa, cuts_for_asize(n_letters))  # cuts from normal z-transformed distribution
            else:
                if item not in list(self.thresholds.keys()):
                    res = ts_to_string(dat_paa,
                                       cuts_for_asize(n_letters))  # cuts from normal z-transformed distribution
                else:
                    cuts = np.array([-np.inf] + [i for i in self.thresholds[item]])  # cuts from manual thresholds
                    res = ts_to_string(dat_paa, cuts)
        else:
            res = np.nan
        return res

    # https://www.geeksforgeeks.org/print-all-combinations-of-given-length/
    def _get_all_sax_combinations_rec(self, set, prefix, n, k, cats):

        if k == 0:
            cats.append(prefix)
            return

        for i in range(n):
            new_prefix = prefix + set[i]
            self._get_all_sax_combinations_rec(set, new_prefix, n, k - 1, cats)

    def _get_all_sax_combinations(self, set, k, cats):
        n = len(set)
        self._get_all_sax_combinations_rec(set, "", n, k, cats)


class SAX_Evaluator:

    def __init__(self, sax_transformer, path=None):
        self.sax_transformer = sax_transformer
        self.path = self._build_path(path)
        self.target_name = self._get_y().columns.values[0]

    def plot_missing_vaules_per_group(self, features=None):
        data = self.sax_transformer.get_transformed_data()
        data = pd.concat([self._get_y(), data], axis=1)

        if features is not None:
            cols_found = [col for col in data.columns if col in features]
            if cols_found:
                cols_found = [self.target_name] + cols_found
                data = data[cols_found]

        summary_data = self._build_summary_data(data)

        fig = go.Figure()
        for name, df in summary_data.groupby(self.target_name):
            fig.add_trace(go.Bar(
                x=df.index.levels[0],
                y=df['na_percentage'],
                name=name,
            ))

        fig = self._update_layout(fig, 'Missing Values per group',
                                  yaxis_title='% missing values', xaxis_title='sax-features')
        fig.update_layout(barmode='group')
        fig.write_html(f"{self.path}/na_per_group")

    def plot_survivalcurve(self, positive_group='survived', features=None):

        path = self._build_subdirectory('survivalcurve')
        y = self._get_y()

        y = y.reset_index()
        x = self.sax_transformer.final_data.reset_index()

        if positive_group not in y.values:
            raise Exception(f"'positive_group' has to be a value of y")

        data = pd.merge(x, y, on='index')

        if features is not None:

            cols_found = [col for col in data.columns if col in features]
            if cols_found:
                cols_found = cols_found + [self.target_name, 'index']
                data = data[cols_found]

        for item in [i for i in data.columns if i not in ['index', self.target_name]]:
            data_filtered = data[[item, self.target_name, 'index']]
            counted_subgroup = data_filtered.groupby([item, self.target_name]).count()
            counted_subgroup = counted_subgroup.replace(np.nan, 0)

            counted_subgroup['index'] = counted_subgroup['index'].astype(int)

            subtitle = ""
            df = counted_subgroup.reset_index(level=1)
            df = df.pivot(columns=self.target_name, values='index')
            dict_for_subtitle = df.to_dict(orient='index')

            header = list(dict_for_subtitle[list(dict_for_subtitle.keys())[0]].keys())
            subtitle = subtitle + '(' + '/'.join(header) + ") -> "
            for k, v in dict_for_subtitle.items():
                subtitle = subtitle + ''.join(f"<b>{k}: </b>")
                values = list(v.values())
                values = [str(i) for i in values]
                subtitle = subtitle + '/'.join(values) + "  "

            counted_subgroup['relative'] = counted_subgroup.groupby(level=0).apply(lambda x: x / float(x.sum()))

            survival_rate = counted_subgroup[
                counted_subgroup.index.get_level_values(self.target_name) == positive_group]
            survival_rate = survival_rate.sort_values('relative', ascending=False)

            fig = go.Figure()
            fig.add_trace(go.Scatter(x=survival_rate.index.get_level_values(item), y=survival_rate['relative'],
                                     mode='lines+markers',
                                     name='rate'))

            title = f"survivalcurve feature <b>'{item}'</b> <br> {subtitle}"
            fig = self._update_layout(fig=fig, title_text=title)
            fig.update_layout(yaxis=dict(range=[0, 1], title_text=f'{positive_group} [%]'))
            fig.update_xaxes(title_text=f"sax-coding '{item}'")
            fig.write_html(f"{path}/{item}.html")

    def plot_timeseries(self, border=True, features=None):
        """
        stores time-series-plots of all desired SAX-Features in folder 'timeseries'
        :param border: boolean. If True (default) borders will be shown in plot as black line
        :param features: list of features. If NOne (default) all available Features will be plotted
        :return:
        """
        path = self._build_subdirectory('timeseries')
        y = self._get_y()

        # add ID to data
        if 'ID' not in self.sax_transformer.X:
            self.sax_transformer.X['ID'] = range(0, self.sax_transformer.X.shape[0])

        self.sax_transformer.get_borders()
        text_border = ""

        if features is None:
            features = list(self.sax_transformer.features)

        for idx, item in enumerate(self.sax_transformer.features):
            if item in features:

                data = self._build_timeseries_data(y, idx)

                fig = px.line(data,
                              x='variable',
                              y='value',
                              color='sax_code',
                              line_dash='target',
                              line_group="ID",
                              facet_row="group")

                if border:
                    if self.sax_transformer.borders is not None:
                        borders = self.sax_transformer.borders[item]
                        borders_rounded = {key: round(value, 3) for key, value in borders.items()}
                        for key, value in borders_rounded.items():
                            fig.add_shape(type='line',
                                          x0=0,
                                          y0=value,
                                          x1=self.sax_transformer.transformed_data[idx].shape[1],
                                          y1=value,
                                          line=dict(
                                              color="black",
                                              width=3),
                                          xref='x',
                                          yref='y',
                                          name=key
                                          )
                        text_border = f"borders: {borders_rounded}"

                title = f"timeseries feature <b>'{item}'</b><br>{text_border}"
                fig = self._update_layout(fig=fig, title_text=title)
                fig.update_yaxes(matches=None)
                fig.write_html(f"{path}/{item}.html")

    def write_borders_to_csv(self):

        self.sax_transformer.get_borders()
        if self.sax_transformer.borders is not None:
            df = pd.DataFrame(self.sax_transformer.borders).T
            df.to_csv(f"{self.path}/borders.csv")

    @staticmethod
    def _build_summary_data(data):
        df = data.groupby(data.iloc[:, 0].name).agg(['size', 'count'])
        df = df.swaplevel(0, 1, axis=1)
        df = df.unstack(level=1)
        df = df.swaplevel(0, 2)
        df = df.unstack(level=2)
        df = df.swaplevel(0, 1)
        df.sort_index(axis=0, level=0, inplace=True)
        df['na_percentage'] = 1 - (df['count'] / df['size'])
        return df

    def _build_timeseries_data(self, y, idx):
        """
        :param y: pandas Series of target (y)
        :param idx: index (int)
        :return: pandas dataFrame
            'target' 'sax_code' 'ID'	'group' 	    'variable'	'value'
            ---------------------------------------------------------------
            died		aa		0	    transformed	    crp_1		-0.84495
            survived	ab		1	    transformed	    crp_1		-0.74295
            died		bb		2	    transformed	    crp_1		 0.52530
            died		bb		3	    transformed	    crp_1		 0.28373
            ...									                        ...
            survived	ab		201	    transformed	    apt_10	    -0.23455
            ...									                        ...
            died		aa		0	    original	    crp_1		 5.84495
            ...									                        ...
            survived	ab		201	    original	    apt_10     230.43257
        """
        data_transformed = pd.concat([y,
                                      self.sax_transformer.sax_coded_data[idx],
                                      self.sax_transformer.X.loc[:, ['ID']],
                                      self.sax_transformer.transformed_data[idx]],
                                     axis=1)
        data_transformed['group'] = 'transformed'
        data_original = pd.concat([y,
                                   self.sax_transformer.sax_coded_data[idx],
                                   self.sax_transformer.X.loc[:, ['ID']],
                                   self.sax_transformer.original_data[idx]],
                                  axis=1)
        data_original['group'] = 'original'
        data = pd.concat([data_transformed, data_original], axis=0)
        data.columns.values[[0, 1]] = ['target', 'sax_code']
        data.dropna(how='all', subset=['sax_code'], inplace=True)  # remove rows which have less than 2 valid values

        non_features_in_data = [i for i in data.columns.to_list() if
                                not i.startswith(list(self.sax_transformer.features)[idx])]
        features_in_data = [i for i in data.columns.to_list() if i.startswith(list(self.sax_transformer.features)[idx])]

        data = pd.melt(data, id_vars=non_features_in_data, value_vars=features_in_data)

        data[['feature', 'idx']] = data.variable.str.split("_", expand=True, )
        data['idx'] = pd.to_numeric(data['idx'])
        data = data.sort_values(['idx', 'ID'], ascending=[True, True])

        return data

    @staticmethod
    def _build_path(path):
        if path is None:
            path = os.path.join(os.getcwd(), 'sax')
        else:
            path = os.path.join(path, 'sax')

        if not os.path.exists(path):
            try:
                os.mkdir(path)
            except OSError:
                raise Exception("can't build this directory" % path)
        return path

    def _build_subdirectory(self, subdirectory):
        path = os.path.join(self.path, subdirectory)
        if not os.path.exists(path):
            os.mkdir(path)
        return path

    def _get_y(self):

        if self.sax_transformer.y is None:
            raise Exception(f"There is no y! Provide y-values in fit method!")

        if isinstance(self.sax_transformer.y, np.ndarray):
            y = pd.DataFrame({'target': self.sax_transformer.y})
        elif isinstance(self.sax_transformer.y, pd.Series):
            y = self.sax_transformer.y.to_frame()
        else:
            y = self.sax_transformer.y
        return y

    @staticmethod
    def _update_layout(fig, title_text, **kwargs):
        fig.update_layout(
            title={
                'text': title_text,
                'font': {'size': 24}
            },
            **kwargs,
            template='plotly_white'
        )
        return fig
