import numpy as np
from sklearn.base import RegressorMixin, ClassifierMixin
from scipy import stats

class NullRegressor(RegressorMixin):
    """
    source: https://towardsdatascience.com/building-a-custom-model-in-scikit-learn-b0da965a1299
    """
    def __init__(self):
        self.y_bar_= None

    def fit(self, X=None, y=None):
        # The prediction will always just be the mean of y
        self.y_bar_ = np.mean(y)

    def predict(self, X=None):
        # Give back the mean of y, in the same
        # length as the number of X observations
        return np.ones(X.shape[0]) * self.y_bar_[0]


class NullClassifier(ClassifierMixin):

    def __init__(self):
        self.y_most_ = None

    def fit(self, X=None, y=None):
        # The prediction will always just be the most occurring value in y
        if isinstance(y, (np.ndarray, np.generic)):
            self.y_most_ = list(stats.mode(y)[0])[0]
        else:
            self.y_most_ = y.mode().iloc[0, 0]  # in case of equal classes, the one earliest in alphabet will be taken

    def predict(self, X=None):
        # Give back the most occurring value of y, in the same
        # length as the number of X observations
        li = [self.y_most_ for i in range(0, X.shape[0])]
        return li
