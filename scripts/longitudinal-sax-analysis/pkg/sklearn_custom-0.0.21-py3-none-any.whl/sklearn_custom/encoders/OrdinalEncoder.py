from sklearn.preprocessing import OrdinalEncoder
from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd
from sklearn_custom.helpers.helpers import _add_new_cats, _apply_new_cats
import pandas as pd


class OrdinalEncoder(OrdinalEncoder):

    """
    wraps sklearn.class 'OrdinalEncoder'. A pandas DataFrame will be returned if a pandas DataFrame is given as argument
    and if df_out is set to True (default). No missing values are allowed in input data!
    """

    def __init__(self, df_out=True, new_cats=False, fill_value='ONLYTESTSET', drop=None, **kwargs):
        super().__init__(**kwargs)
        self.df_out = df_out
        self.new_cats = new_cats
        self.fill_value = fill_value
        self.drop = drop
        self.X = None

    def fit(self, X, y=None):

        self.X = X
        if self.new_cats:
            _add_new_cats(self)  # there will be added new columns with 'fill_value' for every feature
        super().fit(X=self.X, y=y)
        return self

    def transform(self, X):

        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(data=X, columns=['X_' + str(item) for item in range(0, X.shape[1])])

        if self.new_cats:
            X = _apply_new_cats(self, X)

        Xs = super().transform(X)

        if self.df_out and isinstance(X, pd.DataFrame):
            idx = X.index
            cols = X.columns.to_list()
            Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)

        return Xs