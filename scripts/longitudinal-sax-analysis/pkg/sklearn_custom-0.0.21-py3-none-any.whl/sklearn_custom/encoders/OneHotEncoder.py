from sklearn.preprocessing import OneHotEncoder
from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd
from sklearn_custom.helpers.helpers import store_old_names, replace_xN_column_names, _add_new_cats, _apply_new_cats
import pandas as pd


class OneHotEncoder(OneHotEncoder):
    """
    wraps 'OneHotEncoder' class from sklearn 'OnehotEncoder'. Output can be a pandas DataFrame if df_out=True and input
    is a pandas DataFrame as well. If new_cats is set to True, a new feature with name of 'fill_value' is build. Values
    only existing in test-set will automatically be transformed into this new category.
    Missing values in train and/or test-set are not allowed (use imputer first to remove missing values)
    If there are other values in test-set than in training, parameter 'new-cats=True' must be used. There will be build
    new columns for ALL features. If transformer 'VarianceThreshold' is used afterwards, the columns with only Zeros
    in train (and also test) can be removed, without crash of pipeline.
    """

    def __init__(self, df_out=True, new_cats=False, fill_value='ONLYTESTSET', sparse=False, drop=None, **kwargs):

        super().__init__(**kwargs)
        self.sparse = sparse
        self.df_out = df_out
        self.new_cats = new_cats
        self.fill_value = fill_value
        self.drop = drop
        self.X = None

    def fit(self, X, y=None):

        self.X = X
        if self.new_cats:
            _add_new_cats(self)  # there will be added new columns with 'fill_value' for every feature
        super().fit(X=self.X, y=y)
        return self

    def transform(self, X):

        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(data=X, columns=['X_' + str(item) for item in range(0, X.shape[1])])

        if self.new_cats:
            X = _apply_new_cats(self, X)

        Xs = super().transform(X)  # Xs will be of type np.ndarray

        if self.df_out:
            idx = X.index
            old_names = store_old_names(X)
            new_names = list(super().get_feature_names())
            cols = replace_xN_column_names(new_names, dict=old_names)
            Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)

        return Xs