import plotly.graph_objects as go
import math
import numpy as np
from sklearn_custom.modeling.modeling import Models
from joblib import dump, load
import os
import pandas as pd
from functools import reduce
from sklearn.model_selection import train_test_split
from plotly.subplots import make_subplots
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn_custom.transformers.SAXTransformer import SAX_Transformer
from pprint import pformat
import string
from sklearn import datasets

# # TODO: modify evaluation_config for only one metric (exp. ['accuracy_score'])
# evaluation_config = {'scoring_methods': ['accuracy_score', 'f1_score'],
#                      'args': {'f1_score': {'average': 'macro', 'pos_label': 'died'}}}


class Evaluator:
    """
    builds evaluations (plots, summaries,...) from generated class 'Models'
    """
    def __init__(self, obj, path=None):
        self.obj = self._validate_obj(obj)
        self.path = self._validate_path(path)
        self.csv_overall_ranking_feature_selection = None

    @staticmethod
    def _check_scorer_list(scorer):
        if isinstance(scorer, Scorer):
            scorer = [scorer]
        else:
            if isinstance(scorer, list):
                validation = [isinstance(item, Scorer) for item in scorer]
                if not all(validation):
                    raise ValueError('Parameter should be a Scorer or a list of Scorer')
            else:
                raise ValueError('Parameter should be a Scorer or a list of Scorer')
        return scorer

    @staticmethod
    def _validate_path(path):
        if path is None:
            path = os.getcwd()
        else:
            if not os.path.exists(os.path.join(path)):
                raise Exception(f"...")
        return path

    @staticmethod
    def _validate_obj(obj):
        if not isinstance(obj, Models):
            raise Exception(f"obj has to be an instance of class 'Models'")
        else:
            return obj

    @staticmethod
    def _get_data(train_test_scores, l1, l2, x, sort='algorithm'):
        if sort == 'algorithm':
            data = train_test_scores.xs(x, axis=1, level=1, drop_level=False)
            data = list(data.loc[(l1, l2)])
        else:  # sort = 'columns'
            data = train_test_scores.xs(l2, axis=0, level=1, drop_level=False)
            data = list(data.loc[:, (l1, x)])
        return data

    @staticmethod
    def _build_axis(train_test_scores):
        alg = train_test_scores.index.levels[0].to_list()
        scorer = train_test_scores.columns.levels[0].to_list()
        return [alg, scorer]

    def _build_positions(no_plots, **kwargs):
        geometries = [{1: (1, 1)}, {2: (2, 1)}, {3: (2, 2)}, {4: (2, 2)}, {5: (3, 2)}, {6: (3, 2)}, {7: (3, 3)},
                      {8: (3, 3)}, {9: (3, 3)}, {10: (4, 3)}, {11: (4, 3)}, {12: (4, 3)}]

        if 'geometry' not in kwargs:
            geometry = geometries[no_plots - 1].get(no_plots)
        else:
            geometry = kwargs['geometry']
            if geometry[0] + geometry[1] < no_plots:
                geometry = geometries[no_plots - 1].get(no_plots)

        positions = []
        for i in range(geometry[0]):
            for j in range(geometry[1]):
                positions.append((i + 1, j + 1))
        return [positions, geometry]

    def fig_evaluation(self, scorer, sort='algorithm', **kwargs):
        """
        plots one or multiple Scorer-objects
        :param scorer: Object of class Scorer or list of Objects of class Scorer
        :param sort: one of 'algorithm' or 'metric'
        :param kwargs: y_range as list [0,1], geometry as tuple (2,2)
        :return:
        """
        scorer = self._check_scorer_list(scorer)

        # set colors
        COLORS = {'train': '#3D9970', 'cv': '#FF4136', 'test': 'rgb(0, 102, 204)', 'importance': 'rgb(112,112,112)'}
        colors = []
        for item in scorer:
            if item.name.lower() in COLORS.keys():
                colors.append(COLORS[item.name])  # TODO: define colors in case of false

        # define y-range of plot
        if 'y_range' not in kwargs:
            y_range = [0, 1]  # default
        else:
            if (isinstance(kwargs['y_range'], list) and len(
                    kwargs['y_range']) == 2 and 0 <= kwargs['y_range'][0] < kwargs['y_range'][1] <= 1):
                y_range = kwargs['y_range']
            else:
                y_range = [0, 1]

        axis = [scorer[0].scoring_algorithms, scorer[0].scoring_methods]

        if sort == 'metric':
            axis[0], axis[1] = axis[1], axis[0]  # swap

        no_plots = len(axis[0])
        positions, geometry = self._build_positions(no_plots, **kwargs)

        fig = make_subplots(rows=geometry[0],
                            cols=geometry[1],
                            start_cell="top-left",
                            subplot_titles=axis[0])

        for index, value in enumerate(axis[0]):
            for idx, item in enumerate(scorer):
                x = axis[1]
                if sort == 'algorithm':
                    y = list(item.scores[value].values())
                else:
                    y = [item.scores[i][axis[0][index]] for i in item.scores]

                fig.add_trace(go.Bar(name=f"{item.name} {value}", x=x, y=y,
                                     marker_color=colors[idx]),
                              row=positions[index][0], col=positions[index][1])
                fig['layout'][f'yaxis{idx + 1}'].update(range=y_range, autorange=False)

        fig.update_layout(
            title={
                'text': f"<b>Predictions with different Classifiers ({sort})</b>",
                'font': {'size': 25}
            },
            template='plotly_white'
        )

        return fig

    def build_df_overview(self, scorer):
        scorer = self._check_scorer_list(scorer)

        results = []
        algorithms = list(scorer[0].scores.keys())
        columns = [['name'], ['split'], scorer[0].scoring_methods]
        columns = [item for sublist in columns for item in sublist]

        for item in scorer:
            values = []
            for algorithm in algorithms:
                values.append(list(item.scores[algorithm].values()))

            df = pd.DataFrame.from_records(values, columns=scorer[0].scoring_methods)
            df['name'] = algorithms
            df['split'] = item.name
            results.append(df)

        df = pd.concat(results)
        df = df[columns]
        return df

    def build_excel_feature_selection(self, algorithms=None):  # TODO: choose algorithms (list)

        if self.obj.feature_selection_results:
            path = os.path.join(self.path, 'results_feature_selection.xlsx')
            fs = self.obj.feature_selection_results

            with pd.ExcelWriter(path=path) as writer:
                for algorithm in fs:
                    res = pd.DataFrame.from_dict(fs[algorithm].get_metric_dict()).T
                    res.to_excel(writer, sheet_name=algorithm)

    def build_csv_overall_ranking_feature_selection(self, algorithms=None):
        """
        calculates overall importance of each feature
        :param fs: SFS object
        :param algorithms: list of desired algorithm names (None (default) = all available algorithms)
        :return: ranking DataFrame
        """

        if self.obj.feature_selection_results:
            path = os.path.join(self.path, 'feature_overall_ranking.csv')

            if algorithms is None:
                alg = [i for i in self.obj.feature_selection_results.keys()]
            else:
                alg = algorithms

            ranking = []

            for algorithm in self.obj.feature_selection_results:
                if algorithm not in alg:
                    continue
                else:
                    data = self.obj.feature_selection_results[algorithm]
                    feature_order = []
                    for idx in range(2, len(data.subsets_) + 1):
                        f1 = list(data.subsets_[idx - 1]['feature_names'])
                        f2 = list(data.subsets_[idx]['feature_names'])
                        f_new = [x for x in f2 if x not in f1]
                        feature_order.append(f_new[0])
                    feature_order.insert(0, data.subsets_[1]['feature_names'][0])
                    ranking.append(
                        pd.DataFrame(index=feature_order, data=list(range(len(feature_order), 0, -1)),
                                     columns=[algorithm]))

            df = reduce(lambda left, right: left.join(right, how='outer'), ranking)  # join DataFrames of all algorithms
            overall_sum = df.sum(axis=1).sum(axis=0)
            df['sum'] = df.sum(axis=1)
            df['score'] = df.loc[:, "sum"] / overall_sum
            df.sort_values('score', ascending=False, inplace=True)
            self.csv_overall_ranking_feature_selection = df
            df.to_csv(path)

    def plot_train_test_scores(self, train_test_scores, n, sort='algorithm', **kwargs):

        # sort = 'algorithm'
        # sort = 'metric'

        # train_test_scores (multilevel dataframe):
        #                     accuracy_score            ...  f1_score
        #                               mean       std  ...      mean       std
        # name          split                           ...
        # GNB           test        0.758170  0.071955  ...  0.670217  0.108623
        #               train       0.796667  0.035963  ...  0.710133  0.061648
        # KNN           test        0.732026  0.070878  ...  0.577531  0.103617
        #               train       0.813333  0.040661  ...  0.690275  0.083335
        # Random Forest test        0.764706  0.092801  ...  0.617770  0.161349
        #               train       0.837778  0.025531  ...  0.731629  0.040589

        # set train and test colors
        COLORS = {'train': 'rgba(61, 153, 112, 1)', 'cv': '#FF4136', 'test': 'rgba(0, 102, 204, 1)',
                  'importance': 'rgb(112,112,112)'}
        colors = []
        for item in train_test_scores.index.levels[1].to_list():
            if item.lower() in COLORS.keys():
                colors.append(COLORS[item])

        axis = self._build_axis(train_test_scores)

        if sort == 'metric':
            axis[0], axis[1] = axis[1], axis[0]  # swap axis

        no_plots = len(axis[0])
        positions, geometry = self._build_positions(no_plots)  # build geometry for desired number of figures

        fig = make_subplots(rows=geometry[0],
                            cols=geometry[1],
                            start_cell="top-left",
                            subplot_titles=axis[0])

        # define y-range of plot
        if 'y_range' not in kwargs:
            y_range = [0, 1]  # default
        else:
            if (isinstance(kwargs['y_range'], list) and len(
                    kwargs['y_range']) == 2 and 0 <= kwargs['y_range'][0] < kwargs['y_range'][1] <= 1):
                y_range = kwargs['y_range']
            else:
                y_range = [0, 1]

        for index, alg in enumerate(axis[0]):
            x = axis[1]  # list of strings
            for idx, src in enumerate(train_test_scores.index.levels[1].to_list()):
                y = self._get_data(train_test_scores, alg, src, 'mean', sort)  # list of numbers
                error_y = self._get_data(train_test_scores, alg, src, 'std', sort)  # list of numbers

                fig.add_trace(go.Bar(name=f"{src} {alg}", x=x, y=y, error_y=dict(type='data', array=error_y),
                                     marker_color=colors[idx]),
                              row=positions[index][0], col=positions[index][1])
                fig['layout'][f'yaxis{idx + 1}'].update(range=y_range, autorange=False)

        fig.update_layout(
            title={
                'text': f"<b>Predictions with different Classifiers (sort = {sort}) <br> n={n}</b>",
                'font': {'size': 25}
            },
            template='plotly_white'
        )
        return fig

    def plot_feature_selection(self, error_visability=False):

        if not self.obj.feature_selection_results:
            return go.Figure()  # empty figure if no feature_selection was calculated
        else:
            fig = go.Figure()
            for algorithm in self.obj.feature_selection_results:

                data = self.obj.feature_selection_results[algorithm]
                values = [data.subsets_[i]['avg_score'] for i in data.subsets_]
                errors = [np.std(data.subsets_[i]['cv_scores']) / math.sqrt(len(data.subsets_[i]['cv_scores'])) for
                          i in data.subsets_]  # standard error
                features = [list(data.subsets_[i]['feature_names']) for i in data.subsets_]

                # build list with new feature per step (with delta)
                new_feature = []
                new_delta = []
                for idx in range(2, len(data.subsets_) + 1):
                    f1 = list(data.subsets_[idx - 1]['feature_names'])
                    f2 = list(data.subsets_[idx]['feature_names'])
                    f_new = [x for x in f2 if x not in f1]
                    new_feature.append(f_new[0])
                    new_delta.append(round(data.subsets_[idx]['avg_score'] - data.subsets_[idx - 1]['avg_score'], 3))

                new_feature.insert(0, data.subsets_[1]['feature_names'][0])
                new_delta.insert(0, '-')

                text_features = [
                    f"<b>all:  </b> {features[i]} <br><b>new:</b> <i>{new_feature[i]}</i> (delta={new_delta[i]})"
                    for i in range(0, len(features))]

                # Add traces
                fig.add_trace(go.Scatter(x=list(range(1, len(values) + 1)),
                                         y=values,
                                         error_y=dict(
                                             type='data',  # value of error bar given in data coordinates
                                             array=errors,
                                             visible=error_visability),
                                         mode='markers+lines',
                                         name=algorithm,

                                         hovertemplate=
                                         '<br>no features: %{x}<br>' +
                                         'score: %{y} <br>' +
                                         '%{text}',
                                         text=text_features
                                         ))

            if error_visability:
                title = f"<b>Feature Selection (cv-mean and standard error, cv={data.cv})</b>"
            else:
                title = f"<b>Feature Selection (cv-mean)</b>"

            fig.update_layout(
                title={
                    'text': title,
                    'font': {'size': 25}
                },

                yaxis_title=f"{data.scoring}",
                xaxis_title="features",
                template='plotly_white'
            )

            fig.write_html(f"{self.path}/feature_selection.html")
            return fig

    def plot_overall_ranking_feature_selection(self, algorithms=None):

        if not self.obj.feature_selection_results:
            return go.Figure()
        else:
            if algorithms is None:
                alg = [i for i in self.obj.feature_selection_results.keys()]
            else:
                alg = algorithms

            self.build_csv_overall_ranking_feature_selection(algorithms=alg)
            table = self.csv_overall_ranking_feature_selection

            fig = go.Figure([go.Bar(x=table.index, y=table['score'])])

            fig.update_layout(
                title={
                    'text': f"overall feature importance: algorithms = {alg}",
                    'font': {'size': 25}
                },

                yaxis_title=f"average score",
                xaxis_title="features",
                template='plotly_white'
            )

            fig.write_html(f"{self.path}/overall_ranking_feature_selection.html")
            return fig

    def predict(self, X):
        pass

    def __str__(self):
        """
        string representation of object (summary)
        :return:
        """
        return "TODO"


class RegressionEvaluator(Evaluator):
    def __init__(self, obj, path=None):
        super().__init__(obj, path)


class ClassifierEvaluator(Evaluator):

    def __init__(self, obj, path=None):
        super().__init__(obj, path)

    def print_confusion_matrix(self):
        pass

    def evaluate(self, X, Y, names=None, type=None, **evaluation):

        if names is None:
            names = ['train', 'test'][:len(X)]
        if type is None:
            type = ['confusion_matrix', 'metric']

        scorers = []
        for x, y, group_name in zip(X, Y, names):
            preds = Predictions(fitted_models=self.obj.models)
            preds.predict(x)
            sc = Scorer(y, preds, group_name, **evaluation)
            sc.run()
            scorers.append(sc)

            if 'confusion_matrix' in type:
                cm = self.ConfusionMatrix(sc)
                cm.run()
                fig = cm.plot(split=group_name)
                fig.write_html(f"{self.path}/confusion_matrix_{group_name}.html")

        if 'metric' in type:
            for sort in ['algorithm', 'metric']:
                fig = self.fig_evaluation(scorers, sort=sort, y_range=[0, 1])
                fig.write_html(f"{self.path}/metric_{sort}.html")

            df_results = self.build_df_overview(scorers)
            path = os.path.join(self.path, 'metric_overview.csv')
            df_results.to_csv(path)

    class ConfusionMatrix:

        def __init__(self, scorer):
            self.scorer = scorer
            self.matrix = {}

        def run(self, algorithm='all'):
            """
            :param algorithm: string or list of strings with valid algorithm names of which confusion matrix should be calculated
            :return: dict with confusion matrix as pandas DataFrame
            """
            for item in self.scorer.predictions.predictions.keys():
                if item in algorithm or algorithm == 'all':
                    labels = self.scorer.predictions.fitted_models[item].classes_
                    conf_matrix = confusion_matrix(self.scorer.true_values.to_numpy(),
                                                   self.scorer.predictions.predictions[item],
                                                   labels=labels)
                    conf_matrix = pd.DataFrame(conf_matrix, columns=list(labels), index=list(labels))
                    self.matrix.update({item: conf_matrix})

        def __str__(self):
            string = ""
            for item in self.matrix:
                string = string + f"\n{item}:\n{self.matrix[item]}\n"
            return string

        def get_matrix(self):
            return self.matrix

        def _build_subtitles(self):
            subtitles = []
            for item in self.matrix:
                scores = self.scorer.scores[item]
                score_strings = []
                for key, score in scores.items():
                    score_string = f"{key.replace('_score', '')} =  {round(score, 4)}"
                    score_strings.append(score_string)
                score = ', '.join(score_strings)
                subtitle = f"<b>{item}</b> <br> {score}"
                subtitles.append({'text': subtitle})
            return subtitles

        # TODO: refactoring / other class
        # def _build_positions(no_plots, **kwargs):
        #     geometries = [{1: (1, 1)}, {2: (2, 1)}, {3: (2, 2)}, {4: (2, 2)}, {5: (3, 2)}, {6: (3, 2)}, {7: (3, 3)},
        #                   {8: (3, 3)}, {9: (3, 3)}, {10: (4, 3)}, {11: (4, 3)}, {12: (4, 3)}]
        #
        #     if 'geometry' not in kwargs:
        #         geometry = geometries[no_plots - 1].get(no_plots)
        #     else:
        #         geometry = kwargs['geometry']
        #         if geometry[0] + geometry[1] < no_plots:
        #             geometry = geometries[no_plots - 1].get(no_plots)
        #
        #     positions = []
        #     for i in range(geometry[0]):
        #         for j in range(geometry[1]):
        #             positions.append((i + 1, j + 1))
        #     return [positions, geometry]

        def plot(self, split="default", **kwargs):

            no_plots = len(self.matrix)
            positions, geometry = self._build_positions(no_plots, **kwargs)

            fig = make_subplots(rows=geometry[0],
                                cols=geometry[1],
                                start_cell="top-left",
                                subplot_titles=list(self.matrix.keys())
                                )

            for idx, (key, data) in enumerate(self.matrix.items()):
                z = data.values
                labels = data.columns.to_list()

                fig.add_trace(go.Heatmap(
                    z=z,
                    x=labels,
                    y=labels,
                    colorscale='ylgn',
                    showscale=False,
                ),
                    row=positions[idx][0], col=positions[idx][1])

            fig.update_yaxes(dict(title='true value', autorange='reversed'))
            fig.update_xaxes(dict(title='predicted value'))

            fig.update_layout(title_text=f'<i><b>Confusion matrix: {split.upper()}</b></i>')
            subtitles = self._build_subtitles()
            fig.update_layout({'annotations': subtitles})
            return fig


class SAXEvaluator(ClassifierEvaluator):

    def __init__(self, obj, path=None, path_sax=None):
        """
        :param obj:
        :param path_sax: 'way' to SAX_Transformer_Object in pipeline as tuple exp: ('sax_pipeline', 'sax')
        """
        super().__init__(obj, path)
        self.path_sax = path_sax
        self.sax_transformer = None
        self._validate_sax_path()

    def _validate_sax_path(self):
        # pick first classifier (SAX-Transformer is independent of classifier, so always first classifier can be picked)
        classifier = list(self.obj.models.keys())[0]
        path_to_sax = f"self.obj.models['{classifier}'].best_estimator_.named_steps.preprocessing." \
                      f"named_transformers_.{self.path_sax[0]}.named_steps.{self.path_sax[1]}"  # TODO: generalize (for nested path)
        try:
            transformer = eval(path_to_sax)
        except SyntaxError:
            raise Exception(f"this path could not be evaluated!")

        if not isinstance(transformer, SAX_Transformer):
            raise Exception(f"Object is not of class SAX_Transformer")
        else:
            self.sax_transformer = transformer

    def get_borders(self, store=True):
        borders = self.sax_transformer.get_borders()
        if store:
            with open(f"{self.path}/sax_borders.csv", 'w') as f:
                for key in borders.keys():
                    f.write("%s, %s\n" % (key, borders[key]))
        return borders

    def get_transformed_data(self, store=True):
        transformed_data = self.sax_transformer.get_transformed_data()
        if store:
            transformed_data.to_csv(f"{self.path}/transformed_data.csv")
        return transformed_data

    def survivalplot_sax_features(self, **kwargs):
        self.sax_transformer.survivalplot_sax_features(path=self.path, **kwargs)


class Predictions:

    def __init__(self, fitted_models):
        self.fitted_models = fitted_models
        self.type = None
        self.predictions = {}
        self.predictions_short = {}

    def predict(self, X, type=None):
        self.type = type

        for item in self.fitted_models.keys():
            if type == 'proba':
                preds = self.fitted_models[item].predict_proba(X)
            else:
                # preds = self.fitted_models[item].best_estimator_.predict(X)
                preds = self.fitted_models[item].predict(X)
            self.predictions.update({item: preds})

    def get_predictions(self, len=None):
        if len is not None:
            for item in self.predictions:
                short_preds = self.predictions[item][0:len]
                self.predictions_short.update({item: short_preds})
            return self.predictions_short
        else:
            return self.predictions


class Scorer:

    def __init__(self, true_values, predictions, name, scoring_methods=['accuracy_score'], args=None):
        self.true_values = true_values
        self.predictions = predictions
        self.name = name
        self.scoring_methods = scoring_methods
        self.args = args
        self.scores = {}
        self.scoring_algorithms = []

    def run(self):

        for item in self.predictions.predictions.keys():
            self.scoring_algorithms.append(item)
            y_pred = self.predictions.predictions[item]
            result = {}
            add = {}
            for method in self.scoring_methods:
                if method in self.args:
                    add = self.args[method]
                scoring_method = getattr(metrics, method)
                score = scoring_method(self.true_values.to_numpy(), y_pred, **add)
                result.update({method: score})
            self.scores.update({item: result})

    def get_scores(self):
        return self.scores


if __name__ == '__main__':

    path_sim = '/home/schmidmarco/Documents/CODE/PACKAGES/sklearn_custom/data/sim_copy_1'

    if not os.path.isdir(path_sim):
        raise Exception("folder with this timestamp does not exist!")

    sub_dirs = [name for name in os.listdir(path_sim) if os.path.isdir(os.path.join(path_sim, name)) and
                not name.endswith('_cloud')]

    if len(sub_dirs) == 1:
        print(f"only one simulation in folder '{path_sim}', no evaluation is available!")
        exit()

    evaluation_config = {'scoring_methods': ['accuracy_score', 'precision_score', 'recall_score', 'f1_score'],
                         'args': {'precision_score': {'average': 'macro', 'pos_label': 'died'},
                                  'recall_score': {'pos_label': 'died'}}
                         }

    # evaluate each subdir
    for sub_dir in sub_dirs:
        local_path = f"{path_sim}/{sub_dir}"
        mod = load(f"{local_path}/models.joblib")
        X_train = pd.read_pickle(f"{local_path}/X_train.pkl")
        X_test = pd.read_pickle(f"{local_path}/X_test.pkl")
        y_train = pd.read_pickle(f"{local_path}/y_train.pkl")
        y_test = pd.read_pickle(f"{local_path}/y_test.pkl")
        evaluator = SAXEvaluator(mod, path_sax=('sax_pipeline', 'sax'), path=local_path)
        evaluator.build_excel_feature_selection()
        evaluator.build_csv_overall_ranking_feature_selection()
        evaluator.plot_overall_ranking_feature_selection()
        evaluator.survivalplot_sax_features(positive_group='survived', features=None)
        evaluator.get_borders()
        evaluator.get_transformed_data()

        evaluator.evaluate(X=[X_train, X_test], Y=[y_train, y_test], names=None, type=None, **evaluation_config)

    x = [[] for i in range(len(sub_dirs))]

    for idx, item in enumerate(sub_dirs):
        p = os.path.join(path_sim, item)
        for file in ['feature_overall_ranking', 'metric_overview']:
            data = pd.read_csv(f"{p}/{file}.csv", index_col=0)
            data['ts'] = item
            data['idx'] = idx
            x[idx].append(data)

    def Extract(lst, pos):
        return [item[pos] for item in lst]

    feature_importance = pd.concat(Extract(x, 0))
    train_test_scores = pd.concat(Extract(x, 1))

    alg = feature_importance.loc[:, :'sum'].columns.to_list()[:-1]

    # feature importance
    feature_importance.to_csv(path_or_buf=os.path.join(path_sim, "feature_importance_detail.csv"), index=True)
    feature_importance = feature_importance.reset_index().drop(['sum', 'idx'], axis=1)
    feature_importance = feature_importance.groupby(by='index').agg(['mean', 'std'])
    feature_importance.sort_values(('score', 'mean'), ascending=False, inplace=True)
    feature_importance.to_csv(path_or_buf=os.path.join(path_sim, "feature_importance.csv"), index=True)

    # n = len(sub_dirs)
    # fig = plot_feature_importance(feature_importance, n, alg)
    # fig.show()

    # train-test-scores
    train_test_scores.to_csv(path_or_buf=os.path.join(path_sim, "train_test_scores_detail.csv"), index=True)
    train_test_scores = train_test_scores.reset_index().drop(['ts', 'idx'], axis=1)
    train_test_scores = train_test_scores.groupby(by=['name', 'split']).agg(['mean', 'std'])
    train_test_scores.to_csv(path_or_buf=os.path.join(path_sim, "train_test_scores.csv"), index=True)


    # # TODO: remove index!
    # fig = plot_train_test_scores(train_test_scores, n, sort='algorithm')
    # fig.show()
    #
    # # TODO: remove index!
    # fig = plot_train_test_scores(train_test_scores, n, sort='metric')
    # fig.show()

    # def plot_feature_importance(feature_importance, n, alg):
    #
    #     fig = go.Figure([go.Bar(x=feature_importance.index,
    #                             y=feature_importance[('score', 'mean')],
    #                             error_y=dict(type='data', array=feature_importance[('score', 'std')] / np.sqrt(n),
    #                                          visible=True))])
    #
    #     fig.update_layout(
    #         title={
    #             'text': f"overall feature importance with standard error <br> algorithms = {alg}",
    #             'font': {'size': 25}
    #         },
    #
    #         yaxis_title=f"average score",
    #         xaxis_title="features",
    #         template='plotly_white'
    #     )
    #
    #     return fig

    # X, y = datasets.load_iris(return_X_y=True)
    # X = pd.DataFrame(data=X, columns=['A', 'B', 'C', 'D'])
    # y = pd.DataFrame(data=y, columns=['target'])
    # y.replace({0: 'died', 1: 'survived', 2: 'survived'}, inplace=True)
    # X_new = pd.DataFrame(data=np.random.normal(5, 2, 450).reshape((150, 3)), columns=['sax_1', 'sax_2', 'sax_3'])
    # X_new = X_new.mask(np.random.random(X_new.shape) < .1)  # introduce a fraction of 10% missing data
    # X_new_2 = pd.DataFrame(data=np.random.normal(0, 1, 450).reshape((150, 3)), columns=['exp_1', 'exp_2', 'exp_3'])
    # X_new_2 = X_new_2.mask(np.random.random(X_new_2.shape) < .15)  # introduce a fraction of 10% missing data
    # X = X.join(X_new)
    # X = X.join((X_new_2))
    #
    # # Evaluator
    # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=28)
    #
    # mod = load('/home/schmidmarco/Documents/CODE/PACKAGES/sklearn_custom/data/models.joblib')
    #
    # evaluation_config = {'scoring_methods': ['accuracy_score', 'precision_score', 'recall_score', 'f1_score'],
    #                      'args': {'precision_score': {'average': 'macro', 'pos_label': 'died'},
    #                               'recall_score': {'pos_label': 'died'}}
    #                      }
    #
    # evaluator = ClassifierSAXEvaluator(mod, path_sax=('sax_pipeline', 'sax'), path='/home/schmidmarco/Desktop/aaaa')
    # evaluator.plot_feature_selection(error_visability=True)
    # evaluator.build_excel_feature_selection()
    # evaluator.build_csv_overall_ranking_feature_selection()
    # evaluator.plot_overall_ranking_feature_selection()
    # evaluator.evaluate(X=[X_train, X_test], Y=[y_train, y_test], names=None, type=None, **evaluation_config)
    # evaluator.get_borders()
    # evaluator.get_transformed_data()
    # evaluator.survivalplot_sax_features(positive_group='survived', features=None)  # +/- OKAY
    #
    # # Transformator
    # transformator = SAX_Transformer(n_letters=2, n_length=2, scaler='z_all', thresholds={'sax': [4]})
    # transformator.fit_transform(X, y)
    # print(transformator.get_borders())
    # print(transformator.get_transformed_data())
    # transformator.survivalplot_sax_features(positive_group='survived', features=None)  # +/- OKAY
    #
    # e2 = ClassifierEvaluator(mod, path='/home/schmidmarco/Desktop/bbbb')
    # e2.plot_feature_selection(error_visability=True)
    # e2.build_excel_feature_selection()
    # e2.build_csv_overall_ranking_feature_selection()
    # e2.plot_overall_ranking_feature_selection()
    # e2.evaluate(X=[X_train, X_test], Y=[y_train, y_test], names=None, type=None, **evaluation_config)
