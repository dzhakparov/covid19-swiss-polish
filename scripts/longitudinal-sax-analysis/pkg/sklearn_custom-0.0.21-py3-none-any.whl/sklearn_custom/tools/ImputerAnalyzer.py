import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from random import shuffle
from math import ceil, floor, sqrt
from scipy.stats import pearsonr
from sklearn_custom.imputers.KNNImputer import KNNImputer
from sklearn.metrics import mean_squared_error


class ImputerAnalyzer:

    def __init__(self, data, imputer=None):
        """
        Analyzes different imputing methods and shows them graphically.
        :param data: pandas DataFrame to be imputed
        :param imputer: imputer instance like MiceForest(), SimpleImputer(), ...
        """

        self.data = data
        self.imputer = self._set_imputer(imputer)
        self.chunks = None
        self.data_imputed_chunk = None
        self.data_imputed = None
        self.r_2 = None
        self._set_empty_data_imputed()

    def impute(self, frac=0.05):
        """ starts imputing process for given pandas DataFrame
        :param frac: float between 0 and 1, how many missing values should be imputed per iteration. The number of
        iterations are then calculated as 1 / frac
        """
        self._build_position_tuple(frac)

        for chunk in self.chunks:
            df = self._ampute_data(chunk)
            self.imputer.fit(X=df)
            self.data_imputed_chunk = self.imputer.transform(X=df)
            for item in chunk:
                self.data_imputed.iloc[item[0], item[1]] = self.data_imputed_chunk.iloc[item[0], item[1]]

    def plot(self, cols=None, **kwargs):
        """
        plots imputed data versus original data as a scatter-plot
        :param cols: columns as list of strings or None (default). If None all columns will be displayed in plot
        :param kwargs: additional arguments for subplots as figsize or dpi...
        :return:
        """
        self._calc_r2()

        if cols is not None:
            columns = [i for i in self.data.columns if i in cols]
            if columns:
                data = self.data[columns]
                data_imputed = self.data_imputed[columns]
        else:
            data = self.data
            data_imputed = self.data_imputed

        size = ceil(sqrt(data.shape[1]))
        fig, axs = plt.subplots(nrows=size, ncols=size, **kwargs)
        fig.suptitle(f"{self.imputer}", fontsize=16)

        for idx, ax in enumerate(axs.flat):
            if idx < data.shape[1]:
                ax.scatter(data.iloc[:, idx], data_imputed.iloc[:, idx])
                x = np.array(ax.get_xlim())
                y = np.array(ax.get_xlim())
                ax.text(x.min(), y.max() * 0.9, fr'$R^2$={round(self.r_2[data.columns[idx]], 2)}', fontsize=10)
                ax.plot(x, y, 'r-')
                ax.set_title(fr"{data.columns[idx]}")
        plt.tight_layout()
        return fig

    def store(self, path=None):
        """ stores actual data, imputed data, chucks and imputer to restore and proceed (plot) further
        :param path: Full pathname with ending .pkl as string or None (default). If None the model will be stored in
        actual folder as file 'imputed_data.pkl'
        """
        # store = [self.data, self.data_imputed, self.chunks, self.imputer]
        if path is None:
            pd.to_pickle(self, "imputed_data.pkl")
        else:
            try:
                pd.to_pickle(self, path)
            except FileNotFoundError:
                raise Exception(f"file couldn't be stored as {path}. Please check if directory exists!")

    def _set_empty_data_imputed(self):
        self.data_imputed = self.data.copy()
        self.data_imputed.iloc[:, :] = np.NaN

    def _build_position_tuple(self, frac):
        pos_tuple = [(i, j) for i in range(0, self.data.shape[0]) for j in range(self.data.shape[1])]
        shuffle(pos_tuple)
        no_items_per_iteration = floor(len(pos_tuple) * frac)
        self.chunks = [pos_tuple[x:x + no_items_per_iteration] for x in
                       range(0, len(pos_tuple), no_items_per_iteration)]

    def _ampute_data(self, chunk):
        df = self.data.copy()
        for item in chunk:
            df.iloc[item[0], item[1]] = np.NaN
        return df

    def _calc_r2(self):
        self.r_2 = self.data.copy().iloc[0, :]
        for idx, col in enumerate(self.data):
            data = pd.DataFrame({'true': self.data[col], 'pred': self.data_imputed.iloc[:, idx]}).dropna()
            r = pearsonr(data.iloc[:, 0], data.iloc[:, 1])
            self.r_2.iloc[idx] = r[0] * r[0]

    @staticmethod
    def _set_imputer(imputer):
        if imputer is None:
            imputer = KNNImputer()
        return imputer
